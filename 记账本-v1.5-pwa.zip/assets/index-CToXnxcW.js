(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))a(s);new MutationObserver(s=>{for(const r of s)if(r.type==="childList")for(const i of r.addedNodes)i.tagName==="LINK"&&i.rel==="modulepreload"&&a(i)}).observe(document,{childList:!0,subtree:!0});function n(s){const r={};return s.integrity&&(r.integrity=s.integrity),s.referrerPolicy&&(r.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?r.credentials="include":s.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function a(s){if(s.ep)return;s.ep=!0;const r=n(s);fetch(s.href,r)}})();const Pt="jizhang",Ft=1,Ue=["transactions","categories","ledgers","meta"];let de=null;function le(){return de||(de=new Promise((e,t)=>{const n=indexedDB.open(Pt,Ft);n.onupgradeneeded=()=>{const a=n.result;if(!a.objectStoreNames.contains("transactions")){const s=a.createObjectStore("transactions",{keyPath:"id"});s.createIndex("ledgerId","ledgerId"),s.createIndex("ledger_date",["ledgerId","date"])}a.objectStoreNames.contains("categories")||a.createObjectStore("categories",{keyPath:"id"}).createIndex("ledgerId","ledgerId"),a.objectStoreNames.contains("ledgers")||a.createObjectStore("ledgers",{keyPath:"id"}),a.objectStoreNames.contains("meta")||a.createObjectStore("meta",{keyPath:"key"})},n.onsuccess=()=>e(n.result),n.onerror=()=>t(n.error)}),de)}function we(e,t){return le().then(n=>n.transaction(e,t).objectStore(e))}function $e(e){return new Promise((t,n)=>{e.onsuccess=()=>t(e.result),e.onerror=()=>n(e.error)})}const w={async getAll(e){const t=await we(e,"readonly");return $e(t.getAll())},async put(e,t){const n=await we(e,"readwrite");return $e(n.put(t))},async putMany(e,t){if(!t.length)return;const n=await le();return new Promise((a,s)=>{const r=n.transaction(e,"readwrite"),i=r.objectStore(e);t.forEach(o=>i.put(o)),r.oncomplete=()=>a(),r.onerror=()=>s(r.error),r.onabort=()=>s(r.error)})},async remove(e,t){const n=await we(e,"readwrite");return $e(n.delete(t))},async removeMany(e,t){if(!t.length)return;const n=await le();return new Promise((a,s)=>{const r=n.transaction(e,"readwrite"),i=r.objectStore(e);t.forEach(o=>i.delete(o)),r.oncomplete=()=>a(),r.onerror=()=>s(r.error)})},async clearAll(){const e=await le();return new Promise((t,n)=>{const a=e.transaction(Ue,"readwrite");Ue.forEach(s=>a.objectStore(s).clear()),a.oncomplete=()=>t(),a.onerror=()=>n(a.error)})}};function X(){return Date.now().toString(36)+Math.random().toString(36).slice(2,8)}const Ct="1.5";function Ze(e){const t=e<0,n=Math.abs(e),a=Math.floor(n/100),s=n%100;return(t?"-":"")+a+(s?"."+String(s).padStart(2,"0"):"")}function b(e){const t=e<0,n=Math.abs(e),a=Math.floor(n/100),s=n%100,r=a.toLocaleString("en-US"),i=s?`${r}.${String(s).padStart(2,"0")}`:`${r}.00`;return(t?"-":"")+i}function fe(e){const t=String(e).trim();if(!t||!/^\d*(\.\d{0,2})?$/.test(t))return null;const n=Number(t);return Number.isFinite(n)?Math.round(n*100):null}function R(){return Y(new Date)}function Y(e){const t=e.getFullYear(),n=String(e.getMonth()+1).padStart(2,"0"),a=String(e.getDate()).padStart(2,"0");return`${t}-${n}-${a}`}function He(e=0){const t=new Date;return t.setDate(t.getDate()-e),Y(t)}function et(e,t){const n=a=>{const[s,r,i]=String(a).split("-").map(Number);return new Date(s,r-1,i).getTime()};return Math.round((n(t)-n(e))/864e5)}function tt(e){return String(e).slice(0,7)}function ge(){return R().slice(0,7)}function Tt(e,t){const[n,a]=e.split("-").map(Number),s=new Date(n,a-1+t,1);return`${s.getFullYear()}-${String(s.getMonth()+1).padStart(2,"0")}`}function We(e){const[t,n,a]=e.split("-").map(Number),s=new Date(t,n-1,a),r=["周日","周一","周二","周三","周四","周五","周六"][s.getDay()];return`${n}月${a}日 ${r}`}function jt(e){const[t,n]=e.split("-").map(Number),a=new Date().getFullYear();return t===a?`${n}月`:`${t}年${n}月`}const nt=["week","month","year"],at={week:"周",month:"月",year:"年"},At={week:"上周",month:"上月",year:"上年"},Ye={week:"周",month:"个月",year:"年"},st={week:"这一周",month:"这个月",year:"这一年"};function Ae(e,t=R()){return e==="week"?Mt(t):e==="year"?t.slice(0,4):tt(t)}function C(e){return Ae(e,R())}function Mt(e){const[t,n,a]=e.split("-").map(Number),s=new Date(t,n-1,a);return s.setDate(s.getDate()-(s.getDay()+6)%7),Y(s)}function se(e,t){if(e==="week"){const[s,r,i]=t.split("-").map(Number);return{start:t,end:Y(new Date(s,r-1,i+6))}}if(e==="year")return{start:`${t}-01-01`,end:`${t}-12-31`};const[n,a]=t.split("-").map(Number);return{start:`${t}-01`,end:Y(new Date(n,a,0))}}function J(e,t,n){if(e==="week"){const[a,s,r]=t.split("-").map(Number);return Y(new Date(a,s-1,r+n*7))}return e==="year"?String(Number(t)+n):Tt(t,n)}function rt(e,t,n){const{start:a,end:s}=se(e,t),r=R(),i=r>=a&&r<=s?r:a;return Ae(n,i)}function ot(e,t){if(e==="year")return`${t}年`;if(e==="month")return jt(t);const{start:n,end:a}=se("week",t),[s,r,i]=n.split("-").map(Number),[o,d,c]=a.split("-").map(Number),f=new Date().getFullYear(),m=p=>p===f?"":`${p}年`,v=s===o&&r===d?`${c}日`:`${m(o)}${d}月${c}日`;return`${m(s)}${r}月${i}日–${v}`}function Ot(e,t){if(e==="year")return t;if(e==="month")return`${Number(t.slice(5))}月`;const[,n,a]=t.split("-").map(Number);return`${n}/${a}`}function u(e){return String(e??"").replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t])}const Ge=["#3b7dd8","#e0575b","#26a06a","#e0a32e","#8b5cf6","#12a5b8","#e0669a","#7a8b3f","#c2743a","#5a6b8c"];function Ve(e){return Ge[e%Ge.length]}function ue(e,t){return e.reduce((n,a)=>n+t(a),0)}function qt(e){const t=ue(e.filter(a=>a.kind==="income"),a=>a.amountFen),n=ue(e.filter(a=>a.kind==="expense"),a=>a.amountFen);return{incomeFen:t,expenseFen:n,balanceFen:t-n}}const it=[{kind:"expense",name:"餐饮",emoji:"🍚"},{kind:"expense",name:"交通",emoji:"🚌"},{kind:"expense",name:"购物",emoji:"🛒"},{kind:"expense",name:"房租水电",emoji:"🏠"},{kind:"expense",name:"娱乐",emoji:"🎮"},{kind:"expense",name:"医疗",emoji:"💊"},{kind:"expense",name:"学习",emoji:"📚"},{kind:"expense",name:"人情",emoji:"🎁"},{kind:"expense",name:"其他",emoji:"📦"},{kind:"income",name:"工资",emoji:"💰"},{kind:"income",name:"红包",emoji:"🧧"},{kind:"income",name:"理财",emoji:"📈"},{kind:"income",name:"兼职",emoji:"💼"},{kind:"income",name:"其他",emoji:"📦"}],Dt="日常账本",l={ledgers:[],categories:[],transactions:[],meta:{},loaded:!1};async function Me(){const[e,t,n,a]=await Promise.all([w.getAll("ledgers"),w.getAll("categories"),w.getAll("transactions"),w.getAll("meta")]);if(l.ledgers=e.sort(Le),l.categories=t.sort(Le),l.transactions=n,l.meta=Object.fromEntries(a.map(s=>[s.key,s.value])),!l.ledgers.length){const s={id:X(),name:Dt,budgetFen:0,order:0,createdAt:Date.now()};l.ledgers=[s],await w.put("ledgers",s),l.meta.currentLedgerId=s.id,await w.put("meta",{key:"currentLedgerId",value:s.id})}l.categories.length||(l.categories=it.map((s,r)=>({id:X(),kind:s.kind,name:s.name,emoji:s.emoji,order:r})),await w.putMany("categories",l.categories)),(!l.meta.currentLedgerId||!l.ledgers.some(s=>s.id===l.meta.currentLedgerId))&&(l.meta.currentLedgerId=l.ledgers[0].id,await w.put("meta",{key:"currentLedgerId",value:l.meta.currentLedgerId})),await Rt(),l.loaded=!0}async function Rt(){const e=l.categories.filter(t=>t.kind==="income"&&t.name==="红包"&&t.emoji==="💵");for(const t of e)t.emoji="🧧",await w.put("categories",t)}function Le(e,t){return(e.order??0)-(t.order??0)}async function ee(e,t){l.meta[e]=t,await w.put("meta",{key:e,value:t})}function O(){return l.ledgers.find(e=>e.id===l.meta.currentLedgerId)||l.ledgers[0]}const Se=new Set;function Nt(e){return Se.add(e),()=>Se.delete(e)}function ye(){const e=O();Se.forEach(t=>t(e))}async function Oe(e){l.ledgers.some(t=>t.id===e)&&(await ee("currentLedgerId",e),ye())}async function _t(e,t=0){const n={id:X(),name:e.trim(),budgetFen:t,order:l.ledgers.length,createdAt:Date.now()};return l.ledgers.push(n),await w.put("ledgers",n),n}async function Ie(e,t){const n=l.ledgers.find(a=>a.id===e);n&&(Object.assign(n,t),await w.put("ledgers",n),ye())}async function Bt(e){if(l.ledgers.length<=1)throw new Error("至少要保留一个账本");const t=l.transactions.filter(n=>n.ledgerId===e);l.transactions=l.transactions.filter(n=>n.ledgerId!==e),l.ledgers=l.ledgers.filter(n=>n.id!==e),await w.removeMany("transactions",t.map(n=>n.id)),await w.remove("ledgers",e),l.meta.currentLedgerId===e&&await ee("currentLedgerId",l.ledgers[0].id),ye()}function ne(e){return l.categories.filter(t=>t.kind===e).sort(Le)}function V(e){return l.categories.find(t=>t.id===e)}async function Ut(e,t,n,a=0){const s=l.categories.filter(i=>i.kind===e),r={id:X(),kind:e,name:t.trim(),emoji:n||"📦",order:s.reduce((i,o)=>Math.max(i,o.order??0),-1)+1};return e==="expense"&&a>0&&(r.budgetFen=a),l.categories.push(r),await w.put("categories",r),r}async function Ht(e,t){const n=V(e);if(!n)return!1;const a=ne(n.kind),s=a.findIndex(i=>i.id===e),r=s+t;return s<0||r<0||r>=a.length?!1:(a.splice(r,0,a.splice(s,1)[0]),await Promise.all(a.map((i,o)=>(i.order=o,w.put("categories",i)))),!0)}async function Wt(e,t){const n=V(e);n&&(Object.assign(n,t),(n.kind==="income"||!(n.budgetFen>0))&&delete n.budgetFen,await w.put("categories",n))}function ct(e){return l.transactions.filter(t=>t.categoryId===e).length}async function Yt(e){l.categories=l.categories.filter(t=>t.id!==e),await w.remove("categories",e)}function re(e=l.meta.currentLedgerId){return l.transactions.filter(t=>t.ledgerId===e)}async function dt(e){const t=Date.now(),n={id:X(),ledgerId:e.ledgerId,kind:e.kind,amountFen:e.amountFen,categoryId:e.categoryId,date:e.date,note:e.note||"",createdAt:t,updatedAt:t};return l.transactions.push(n),await w.put("transactions",n),n}async function Gt(e,t){const n=l.transactions.find(a=>a.id===e);n&&(Object.assign(n,t,{updatedAt:Date.now()}),await w.put("transactions",n))}async function Vt(e){const t=l.transactions.find(n=>n.id===e)||null;return l.transactions=l.transactions.filter(n=>n.id!==e),await w.remove("transactions",e),t}async function Kt(e){e&&(l.transactions.some(t=>t.id===e.id)||(l.transactions.push(e),await w.put("transactions",e)))}function zt(e,t,n=l.meta.currentLedgerId,{categoryId:a="",keyword:s="",scope:r="period"}={}){const i=s.trim().toLowerCase(),{start:o,end:d}=se(e,t);return re(n).filter(c=>r==="all"||c.date>=o&&c.date<=d).filter(c=>!a||c.categoryId===a).filter(c=>{if(!i)return!0;const f=V(c.categoryId);return(c.note||"").toLowerCase().includes(i)||(f?.name||"").toLowerCase().includes(i)}).sort((c,f)=>c.date===f.date?f.createdAt-c.createdAt:f.date.localeCompare(c.date))}function me(e,t,n=l.meta.currentLedgerId){const{start:a,end:s}=se(e,t),r=re(n).filter(d=>d.date>=a&&d.date<=s),i=r.filter(d=>d.kind==="income").reduce((d,c)=>d+c.amountFen,0),o=r.filter(d=>d.kind==="expense").reduce((d,c)=>d+c.amountFen,0);return{incomeFen:i,expenseFen:o,balanceFen:i-o,count:r.length}}function lt(e,t=l.meta.currentLedgerId){return me("month",e,t)}function ut(e,t,n,a=l.meta.currentLedgerId){const{start:s,end:r}=se(e,t),i=new Map;for(const o of re(a)){if(o.kind!==n||o.date<s||o.date>r)continue;const d=i.get(o.categoryId)||{amountFen:0,count:0};d.amountFen+=o.amountFen,d.count+=1,i.set(o.categoryId,d)}return i}function Jt(e,t,n,a=l.meta.currentLedgerId){const s=ut(e,t,n,a),r=[...s.values()].reduce((i,o)=>i+o.amountFen,0);return{total:r,items:[...s.entries()].map(([i,o])=>{const d=V(i);return{categoryId:i,amountFen:o.amountFen,count:o.count,name:d?.name??"未分类",emoji:d?.emoji??"❓",pct:r?o.amountFen/r:0}}).sort((i,o)=>o.amountFen-i.amountFen)}}const Xt=.8;function mt(e=ge(),t=l.meta.currentLedgerId){const n=ut("month",e,"expense",t),a=new Map;for(const s of l.categories){if(s.kind!=="expense")continue;const r=s.budgetFen||0;if(r<=0)continue;const i=n.get(s.id)?.amountFen??0,o=i/r;a.set(s.id,{budgetFen:r,spentFen:i,leftFen:r-i,ratio:o,level:o>=1?"over":o>=Xt?"warn":"ok"})}return a}function Qt(e,t,n,a=l.meta.currentLedgerId){const s=[];for(let r=n-1;r>=0;r-=1){const i=J(e,t,-r);s.push({key:i,label:Ot(e,i),...me(e,i,a)})}return s}function Zt(e=l.meta.currentLedgerId){const t=re(e);return t.length?t.reduce((n,a)=>a.date<n?a.date:n,t[0].date):R()}function en(){return{app:"jizhang",version:1,exportedAt:new Date().toISOString(),ledgers:l.ledgers,categories:l.categories,transactions:l.transactions,meta:{currentLedgerId:l.meta.currentLedgerId}}}function tn(e=l.meta.currentLedgerId){const t=l.ledgers.find(a=>a.id===e),n=[["日期","类型","分类","金额(元)","备注","账本"]];return re(e).slice().sort((a,s)=>a.date.localeCompare(s.date)||a.createdAt-s.createdAt).forEach(a=>{n.push([a.date,a.kind==="expense"?"支出":"收入",V(a.categoryId)?.name??"未分类",(a.amountFen/100).toFixed(2),a.note||"",t?.name??""])}),n.map(a=>a.map(nn).join(",")).join(`\r
`)}function nn(e){const t=String(e??"");return/[",\r\n]/.test(t)?`"${t.replace(/"/g,'""')}"`:t}async function an(e){if(!e||e.app!=="jizhang")throw new Error("这不是本 App 导出的备份文件");if(!Array.isArray(e.ledgers)||!Array.isArray(e.transactions))throw new Error("备份文件内容不完整，可能传坏了");const t=e.ledgers;if(!t.length)throw new Error("备份文件里没有账本");if(!t.every(rn))throw new Error("备份文件里的账本信息不完整");if(!e.transactions.every(cn))throw new Error("备份文件里有读不懂的记录");const n=Array.isArray(e.categories)?e.categories.filter(on):[],a=n.length?n:sn(),s=e.meta?.currentLedgerId,r=t.some(o=>o.id===s)?s:t[0].id,i={...l.meta};return delete i.currentLedgerId,await w.clearAll(),await w.putMany("ledgers",t),await w.putMany("categories",a),await w.putMany("transactions",e.transactions),await w.put("meta",{key:"currentLedgerId",value:r}),await w.putMany("meta",Object.entries(i).map(([o,d])=>({key:o,value:d}))),await dn(),ye(),e.transactions.length}function sn(){return it.map((e,t)=>({id:X(),kind:e.kind,name:e.name,emoji:e.emoji,order:t}))}function rn(e){return e&&typeof e.id=="string"&&typeof e.name=="string"}function on(e){return e&&typeof e.id=="string"&&typeof e.name=="string"&&(e.kind==="expense"||e.kind==="income")}function cn(e){return e&&typeof e.id=="string"&&typeof e.date=="string"&&Number.isFinite(e.amountFen)}async function dn(){l.loaded=!1,await Me()}const Pe=new Set;let Fe="record";function qe(){return Fe}function ln(e){return Pe.add(e),()=>Pe.delete(e)}function De(e){e!==Fe&&(Fe=e,Pe.forEach(t=>t(e)))}function h(e,{ms:t=2e3,actionLabel:n="",onAction:a=null}={}){const s=document.getElementById("toastRoot");if(!s)return{dismiss(){}};const r=document.createElement("div");r.className="toast";const i=document.createElement("span");i.textContent=e,r.appendChild(i);let o=null;const d=()=>{clearTimeout(o),r.style.transition="opacity .25s",r.style.opacity="0",setTimeout(()=>r.remove(),260)};if(n){const c=document.createElement("button");c.type="button",c.className="toast-action",c.textContent=n,c.addEventListener("click",()=>{d(),a?.()}),r.appendChild(c)}return s.appendChild(r),o=setTimeout(d,t),{dismiss:d}}function _({title:e="",body:t="",actions:n=[]}={}){const a=document.getElementById("sheetRoot"),s=document.createElement("div");s.className="sheet-mask",s.innerHTML=`
    <div class="sheet" role="dialog" aria-modal="true">
      <div class="sheet-grip"></div>
      ${e?`<h3>${u(e)}</h3>`:""}
      <div class="sheet-body"></div>
      ${n.length?'<div class="sheet-actions"></div>':""}
    </div>`;const r=s.querySelector(".sheet-body");typeof t=="string"?r.innerHTML=t:r.appendChild(t);const i={el:s,body:r,close(){s.style.animation="fade .15s reverse",setTimeout(()=>s.remove(),140)}};if(n.length){const o=s.querySelector(".sheet-actions");n.forEach(d=>{const c=document.createElement("button");c.type="button",c.className=`btn ${d.className||""}`,c.textContent=d.label,d.disabled&&(c.disabled=!0),c.addEventListener("click",()=>d.onClick?.(i)),o.appendChild(c)})}return s.addEventListener("click",o=>{o.target===s&&i.close()}),a.appendChild(s),i}function Q({title:e="确认",message:t="",okText:n="确定",cancelText:a="取消",danger:s=!1,onOk:r}={}){return new Promise(i=>{const o=document.getElementById("dialogRoot"),d=document.createElement("div");d.className="dialog-mask",d.innerHTML=`
      <div class="dialog" role="alertdialog" aria-modal="true">
        <h3>${u(e)}</h3>
        <p>${u(t)}</p>
        <div class="dialog-actions">
          <button type="button" class="btn btn-outline" data-act="cancel">${u(a)}</button>
          <button type="button" class="btn ${s?"btn-danger":"btn-primary"}" data-act="ok">${u(n)}</button>
        </div>
      </div>`;const c=f=>{d.remove(),i(f)};d.querySelector('[data-act="cancel"]').addEventListener("click",()=>c(!1)),d.querySelector('[data-act="ok"]').addEventListener("click",()=>{r?.(),c(!0)}),d.addEventListener("click",f=>{f.target===d&&c(!1)}),o.appendChild(d)})}function ke({title:e="提示",message:t=""}={}){return new Promise(n=>{const a=document.getElementById("dialogRoot"),s=document.createElement("div");s.className="dialog-mask",s.innerHTML=`
      <div class="dialog" role="alertdialog" aria-modal="true">
        <h3>${u(e)}</h3>
        <p>${u(t)}</p>
        <div class="dialog-actions">
          <button type="button" class="btn btn-primary" data-act="ok">知道了</button>
        </div>
      </div>`;const r=()=>{s.remove(),n()};s.querySelector('[data-act="ok"]').addEventListener("click",r),s.addEventListener("click",i=>{i.target===s&&r()}),a.appendChild(s)})}function un(e){let t=String(e).replace(/[^\d.]/g,"");const n=t.indexOf(".");if(n!==-1){t=t.slice(0,n+1)+t.slice(n+1).replace(/\./g,"");const[a,s=""]=t.split(".");t=`${a}.${s.slice(0,2)}`}return t}function mn(e,t){return t.level==="over"?`${e.name}：本月已花 ${b(t.spentFen)} 元，超预算 ${b(-t.leftFen)} 元（预算 ${b(t.budgetFen)} 元）`:`${e.name}：本月已花 ${b(t.spentFen)} 元，预算 ${b(t.budgetFen)} 元，还剩 ${b(t.leftFen)} 元（已用 ${(t.ratio*100).toFixed(0)}%）`}function pt(e,t={}){const n=!!t.tx,a=n?{kind:t.tx.kind,amount:(t.tx.amountFen/100).toFixed(2).replace(/\.00$/,""),categoryId:t.tx.categoryId,date:t.tx.date,note:t.tx.note||""}:{kind:"expense",amount:"",categoryId:"",date:R(),note:""};e.innerHTML=`
    <div class="seg" data-role="seg">
      <button type="button" data-kind="expense">支出</button>
      <button type="button" data-kind="income">收入</button>
    </div>

    <div class="amount-box">
      <div class="amount-label">金额</div>
      <div class="amount-row">
        <span class="amount-cur">¥</span>
        <input id="amountInput" type="text" inputmode="decimal" placeholder="0.00"
               autocomplete="off" enterkeyhint="done" />
      </div>
      <div class="amount-hint" data-role="hint"></div>
    </div>

    <div class="card">
      <p class="card-title">分类</p>
      <div class="cat-grid" data-role="cats"></div>
      <p class="cat-legend" data-role="cat-legend" hidden></p>
    </div>

    <div class="card">
      <div class="field-grid">
        <div class="field">
          <span class="field-label">日期</span>
          <input type="date" data-role="date" />
        </div>
        <div class="quick-dates" data-role="quickdates">
          <button type="button" class="chip" data-off="0">今天</button>
          <button type="button" class="chip" data-off="1">昨天</button>
          <button type="button" class="chip" data-off="2">前天</button>
        </div>
        <div class="field">
          <span class="field-label">备注</span>
          <input type="text" data-role="note" maxlength="60" placeholder="选填，例如：和同事聚餐" />
        </div>
      </div>
    </div>

    <button type="button" class="btn btn-primary btn-block" data-role="save">${u(t.submitLabel||(n?"保存修改":"保存这笔"))}</button>
  `;const s=e.querySelector("#amountInput"),r=e.querySelector('[data-role="hint"]'),i=e.querySelector('[data-role="cats"]'),o=e.querySelector('[data-role="cat-legend"]'),d=e.querySelector('[data-role="date"]'),c=e.querySelector('[data-role="note"]'),f=e.querySelector('[data-role="save"]'),m=e.querySelector('[data-role="quickdates"]');s.value=a.amount,d.value=a.date,c.value=a.note;function v(){e.querySelectorAll('[data-role="seg"] button').forEach(g=>{g.classList.toggle("active",g.dataset.kind===a.kind)})}function p(){const g=ne(a.kind);if(!g.length){i.innerHTML='<div class="muted">这个类型下还没有分类，去「设置 → 分类管理」加一个</div>',o.hidden=!0;return}g.some(F=>F.id===a.categoryId)||(a.categoryId=g[0].id);const I=a.kind==="expense"?mt(tt(a.date)):new Map;i.innerHTML=g.map(F=>{const x=I.get(F.id),j=x?mn(F,x):"";return`<button type="button" class="cat-item ${F.id===a.categoryId?"active":""}" data-cat="${F.id}"
            ${x?`title="${u(j)}" aria-label="${u(j)}"`:""}>
          ${x?`<span class="cat-dot ${x.level}"></span>`:""}
          <span class="cat-emoji">${u(F.emoji)}</span>
          <span class="cat-name">${u(F.name)}</span>
        </button>`}).join(""),o.hidden=I.size===0,o.textContent="圆点＝月预算，黄是花到八成，红是超支"}function $(){m.querySelectorAll("[data-off]").forEach(g=>{g.classList.toggle("active",He(Number(g.dataset.off))===a.date)})}function L(){const g=fe(a.amount);return a.amount.trim()===""?(r.className="amount-hint",r.textContent="",null):g===null?(r.className="amount-hint error",r.textContent="金额只能填数字，最多两位小数",null):g<=0?(r.className="amount-hint error",r.textContent="金额要大于 0",null):(r.className="amount-hint",r.textContent=`合计 ${b(g)} 元`,g)}return s.addEventListener("input",()=>{const g=un(s.value);if(g!==s.value){const I=s.selectionStart??g.length;s.value=g;const F=Math.max(0,Math.min(g.length,I-1));s.setSelectionRange(F,F)}a.amount=g,L()}),s.addEventListener("keydown",g=>{g.key==="Enter"&&(g.preventDefault(),f.click())}),e.querySelectorAll('[data-role="seg"] button').forEach(g=>{g.addEventListener("click",()=>{a.kind=g.dataset.kind,a.categoryId="",v(),p()})}),i.addEventListener("click",g=>{const I=g.target.closest("[data-cat]");I&&(a.categoryId=I.dataset.cat,p())}),d.addEventListener("change",()=>{a.date=d.value||R(),$(),p()}),m.addEventListener("click",g=>{const I=g.target.closest("[data-off]");I&&(a.date=He(Number(I.dataset.off)),d.value=a.date,$(),p())}),c.addEventListener("input",()=>{a.note=c.value}),f.addEventListener("click",async()=>{const g=L();if(g===null){a.amount.trim()===""&&h("先填金额"),s.focus();return}if(!a.categoryId){h("先选一个分类");return}f.disabled=!0;try{n?(await Gt(t.tx.id,{kind:a.kind,amountFen:g,categoryId:a.categoryId,date:a.date,note:a.note.trim()}),h("已保存修改")):(await dt({ledgerId:O().id,kind:a.kind,amountFen:g,categoryId:a.categoryId,date:a.date,note:a.note.trim()}),h(`记下了 ${b(g)} 元`)),f.disabled=!1,t.onSaved?.({...a,amountFen:g})}catch(I){f.disabled=!1,h("保存失败："+I.message)}}),v(),p(),$(),L(),n&&setTimeout(()=>{s.focus(),s.select()},150),{draft:a,reset(){a.amount="",a.note="",a.date=R(),a.categoryId="",s.value="",c.value="",d.value=a.date,p(),$(),L()}}}const ft=864e5,pn=30,fn=7;function gt(e){const t=O(),n=lt(ge()),a=t.budgetFen||0;e.innerHTML=`
    ${gn()}
    ${a>0?vn(n.expenseFen,a):""}
    <div data-role="form"></div>
  `,yn(e),pt(e.querySelector('[data-role="form"]'),{onSaved:()=>{gt(e)}})}function gn(){const e=l.meta.lastBackupAt||0,t=l.meta.backupReminderMutedUntil||0;if(Date.now()<t||!l.transactions.length)return"";const n=l.transactions.reduce((i,o)=>Math.min(i,o.createdAt||Date.now()),Date.now());if(Date.now()-(e||n)<pn*ft)return"";const s=e?et(new Date(e).toISOString().slice(0,10),new Date().toISOString().slice(0,10)):null,r=e?`上次备份是 ${s} 天前了。数据只在这台手机里，建议导出一份存到网盘。`:"还没有备份过。数据只在这台手机里，系统云备份也是关的 —— 卸载或者丢手机就全没了。建议导出一份存到网盘。";return`<div class="reminder" data-role="reminder">
    <span class="rem-main">${u(r)}</span>
    <button type="button" class="rem-close" data-act="reminder-close" aria-label="暂时不提醒">×</button>
  </div>`}function yn(e){const t=e.querySelector('[data-role="reminder"]');t&&(t.querySelector('[data-act="reminder-close"]').addEventListener("click",async()=>{await ee("backupReminderMutedUntil",Date.now()+fn*ft),t.remove()}),t.querySelector(".rem-main").addEventListener("click",()=>De("settings")))}function vn(e,t){const n=e/t,a=n>=1?"over":n>=.8?"warn":"",s=t-e,r=n>=1?`已经超支 ${b(-s)} 元`:`还能花 ${b(s)} 元`;return`<div class="card">
    <p class="card-title">本月预算</p>
    <div class="budget-line">
      <span>已花 ${u(b(e))} 元</span>
      <span>预算 ${u(b(t))} 元</span>
    </div>
    <div class="progress ${a}"><i style="width:${Math.min(n*100,100).toFixed(1)}%"></i></div>
    <div class="budget-tip ${a}">${u(r)}（已用 ${(n*100).toFixed(0)}%）</div>
  </div>`}const y={unit:"month",key:C("month"),categoryId:"",keyword:"",scope:"period"};function Re(){y.key=C(y.unit),y.categoryId="",y.keyword="",y.scope="period"}function A(e){const t=y.unit;y.key>C(t)&&(y.key=C(t));const n=O(),a=zt(t,y.key,n.id,{categoryId:y.categoryId,keyword:y.keyword,scope:y.scope}),s=!!(y.categoryId||y.keyword.trim()),r=y.scope==="all",i=qt(a),o=y.key<=Ae(t,Zt(n.id)),d=y.key>=C(t);e.innerHTML=`
    <div class="scope" data-role="scope">
      ${nt.map(p=>`<button type="button" data-scope="${p}" class="${!r&&t===p?"active":""}">${at[p]}</button>`).join("")}
      <button type="button" data-scope="all" class="${r?"active":""}">全部时间</button>
    </div>

    ${r?"":`<div class="month-nav">
      <button type="button" class="m-arrow" data-role="prev" ${o?"disabled":""}>‹</button>
      <span class="m-label">${u(ot(t,y.key))}${s?` · 筛选出 ${a.length} 笔`:""}</span>
      <button type="button" class="m-arrow" data-role="next" ${d?"disabled":""}>›</button>
    </div>`}

    <div class="summary">
      <div><div class="s-val income">${u(b(i.incomeFen))}</div><div class="s-key income">收入</div></div>
      <div><div class="s-val expense">${u(b(i.expenseFen))}</div><div class="s-key expense">支出</div></div>
      <div><div class="s-val balance">${u(b(i.balanceFen))}</div><div class="s-key">结余</div></div>
    </div>

    ${r?`<p class="muted" style="margin:-4px 0 12px 2px">全部时间里${s?"筛选出":"共"} ${a.length} 笔</p>`:""}

    <div class="filters">
      <select data-role="cat">
        <option value="">全部分类</option>
        ${ne("expense").map(p=>`<option value="${p.id}" ${y.categoryId===p.id?"selected":""}>支出 · ${u(p.name)}</option>`).join("")}
        ${ne("income").map(p=>`<option value="${p.id}" ${y.categoryId===p.id?"selected":""}>收入 · ${u(p.name)}</option>`).join("")}
      </select>
      <input type="search" data-role="kw" placeholder="搜备注或分类" value="${u(y.keyword)}" />
    </div>

    <div data-role="list"></div>
  `;const c=e.querySelector('[data-role="list"]');c.innerHTML=a.length?bn(a,r):hn(s,r,t),e.querySelector('[data-role="scope"]').addEventListener("click",p=>{const $=p.target.closest("[data-scope]");if(!$)return;const L=$.dataset.scope;if(L==="all"){if(r)return;y.scope="all",A(e);return}if(!r&&t===L){if(y.key===C(t))return;y.key=C(t),A(e);return}y.key=rt(t,y.key,L),y.unit=L,y.scope="period",A(e)});const f=e.querySelector('[data-role="prev"]');f&&(f.addEventListener("click",()=>{y.key=J(t,y.key,-1),A(e)}),e.querySelector('[data-role="next"]').addEventListener("click",()=>{y.key=J(t,y.key,1),A(e)})),e.querySelector('[data-role="cat"]').addEventListener("change",p=>{y.categoryId=p.target.value,A(e)});const m=e.querySelector('[data-role="kw"]');let v=null;m.addEventListener("input",()=>{clearTimeout(v),v=setTimeout(()=>{y.keyword=m.value,A(e);const p=document.querySelector('[data-role="kw"]');p&&(p.focus(),p.setSelectionRange(p.value.length,p.value.length))},260)}),c.addEventListener("click",p=>{const $=p.target.closest("[data-tx]");$&&wn($.dataset.tx,e)})}function bn(e,t){const n=new Map;for(const s of e)n.has(s.date)||n.set(s.date,[]),n.get(s.date).push(s);const a=String(new Date().getFullYear());return[...n.entries()].map(([s,r])=>{const i=ue(r.filter(m=>m.kind==="income"),m=>m.amountFen),o=ue(r.filter(m=>m.kind==="expense"),m=>m.amountFen),d=[];i&&d.push(`收 ${b(i)}`),o&&d.push(`支 ${b(o)}`);const c=s.slice(0,4),f=t&&c!==a?`${c}年${We(s)}`:We(s);return`<div class="day-group">
        <div class="day-head">
          <span>${u(f)}</span>
          <span class="d-sub">${u(d.join("　"))}</span>
        </div>
        <div class="tx-list">
          ${r.map(m=>{const v=V(m.categoryId);return`<div class="tx" data-tx="${m.id}">
                <span class="tx-emoji">${u(v?.emoji??"❓")}</span>
                <span class="tx-main">
                  <div class="tx-cat">${u(v?.name??"未分类")}</div>
                  ${m.note?`<div class="tx-note">${u(m.note)}</div>`:""}
                </span>
                <span class="tx-amt ${m.kind}">${m.kind==="expense"?"-":"+"}${u(b(m.amountFen))}</span>
              </div>`}).join("")}
        </div>
      </div>`}).join("")}function hn(e,t,n){const a=e?"没有符合条件的记录":t?"还没有任何记录":`${st[n]}还没有记账`;return`<div class="empty">
    <span class="empty-ico">${e?"🔍":"🗒️"}</span>
    ${a}
  </div>`}function wn(e,t){const n=l.transactions.find(r=>r.id===e);if(!n)return;const a=V(n.categoryId),s=_({title:"这笔记录",body:`
      <div class="set-list">
        <div class="set-row" style="cursor:default">
          <span class="sr-ico">${u(a?.emoji??"❓")}</span>
          <span class="sr-main">
            <div style="font-size:16px;font-weight:600">${u(b(n.amountFen))} 元</div>
            <div class="sr-sub">${u(a?.name??"未分类")} · ${u(n.date)}${n.note?" · "+u(n.note):""}</div>
          </span>
        </div>
        <button type="button" class="set-row" data-act="edit"><span class="sr-ico">✏️</span><span class="sr-main">修改</span></button>
        <button type="button" class="set-row" data-act="dup"><span class="sr-ico">📋</span><span class="sr-main">再记一笔一样的<span class="sr-sub">复制到今天</span></span></button>
        <button type="button" class="set-row" data-act="del"><span class="sr-ico">🗑️</span><span class="sr-main" style="color:var(--danger)">删除</span></button>
      </div>`,actions:[{label:"取消",className:"btn-outline",onClick:r=>r.close()}]});s.body.addEventListener("click",async r=>{const i=r.target.closest("[data-act]");if(!i)return;const o=i.dataset.act;if(s.close(),o==="edit")return kn(n,t);if(o==="del"){if(!await Q({title:"删除这笔记录？",message:`${n.date}　${a?.name??"未分类"}　${b(n.amountFen)} 元
删掉之后可以马上点提示里的「撤销」找回。`,okText:"删除",danger:!0}))return;const c=await Vt(n.id);A(t),h("已删除 1 笔记录",{ms:6e3,actionLabel:"撤销",onAction:async()=>{await Kt(c),h("已恢复"),A(t)}});return}o==="dup"&&await $n(n,t)})}async function $n(e,t){await dt({ledgerId:O().id,kind:e.kind,amountFen:e.amountFen,categoryId:e.categoryId,date:R(),note:e.note}),h("已复制到今天"),y.scope!=="all"&&y.key!==C(y.unit)&&(y.key=C(y.unit)),A(t)}function kn(e,t){const n=_({title:"修改记录",body:'<div data-role="form"></div>'});pt(n.body.querySelector('[data-role="form"]'),{tx:e,submitLabel:"保存修改",onSaved:()=>{n.close(),A(t)}})}function xn({unit:e,key:t,categoryId:n}={}){e&&(y.unit=e),t&&(y.key=t),n!==void 0&&(y.categoryId=n),t&&(y.scope="period")}const yt=320;function En(e,{size:t=yt,thickness:n=48,emptyText:a="这段时间还没有记录"}={}){const s=e.reduce((m,v)=>m+v.amountFen,0);if(!s)return`<div class="empty">${u(a)}</div>`;const r=(t-n)/2,i=t/2,o=t/2;let d=-Math.PI/2;const c=e.map((m,v)=>{const p=m.amountFen/s*Math.PI*2,$=p>=Math.PI*2-1e-6?Ke(i,o,r,n,0,Math.PI*2-1e-4):Ke(i,o,r,n,d,d+p);return d+=p,`<path d="${$}" fill="${Ve(v)}" />`}),f=e[0];return`<div class="chart-wrap">
    <svg viewBox="0 0 ${t} ${t}" width="${t}" height="${t}" role="img"
         aria-label="分类占比环形图，合计 ${u(b(s))} 元">
      ${c.join("")}
      <text x="${i}" y="${o-8}" text-anchor="middle" font-size="13" fill="var(--text-3)">合计</text>
      <text x="${i}" y="${o+16}" text-anchor="middle" font-size="18" font-weight="600" fill="var(--text)">${u(b(s))}</text>
    </svg>
  </div>
  <div class="legend">
    ${e.slice(0,8).map((m,v)=>`<div class="legend-row">
          <span class="legend-dot" style="background:${Ve(v)}"></span>
          <span class="legend-name">${u(m.emoji+" "+m.name)}</span>
          <span class="legend-amt">${u(b(m.amountFen))}</span>
          <span class="legend-pct">${(m.pct*100).toFixed(1)}%</span>
        </div>`).join("")}
    ${e.length>8?`<div class="muted">还有 ${e.length-8} 个分类没显示</div>`:""}
  </div>
  <div class="muted" style="margin-top:10px">占比最大：${u(f.name)}，${(f.pct*100).toFixed(1)}%</div>`}function Ke(e,t,n,a,s,r){const i=n+a/2,o=n-a/2,d=r-s>Math.PI?1:0,c=e+i*Math.cos(s),f=t+i*Math.sin(s),m=e+i*Math.cos(r),v=t+i*Math.sin(r),p=e+o*Math.cos(r),$=t+o*Math.sin(r),L=e+o*Math.cos(s),g=t+o*Math.sin(s);return`M ${c} ${f} A ${i} ${i} 0 ${d} 1 ${m} ${v} L ${p} ${$} A ${o} ${o} 0 ${d} 0 ${L} ${g} Z`}function Ln(e,{height:t=190,emptyText:n="这段时间还没有记录",ariaLabel:a="收支趋势柱状图"}={}){const s=yt,r=t,i=42,o=8,d=16,c=30,f=s-i-o,m=r-d-c,v=Math.max(...e.map(x=>Math.max(x.incomeFen,x.expenseFen)),1),p=f/e.length,$=Math.min(12,p/3.2),L=d+m,g=e.map((x,j)=>{const B=i+p*j+p/2,oe=Math.round(x.incomeFen/v*m),E=Math.round(x.expenseFen/v*m),S=L-oe,U=L-E;return`
        <rect x="${(B-$-2).toFixed(1)}" y="${U}" width="${$}" height="${Math.max(E,x.expenseFen?2:0)}" rx="2.5" fill="var(--expense)" />
        <rect x="${(B+2).toFixed(1)}" y="${S}" width="${$}" height="${Math.max(oe,x.incomeFen?2:0)}" rx="2.5" fill="var(--income)" />
        <text x="${B.toFixed(1)}" y="${r-10}" text-anchor="middle" font-size="13" fill="var(--text-3)">${u(x.label)}</text>`}).join(""),I=[1,.5,0].map(x=>{const j=d+m*(1-x),B=x===0;return`
        <line x1="${i}" y1="${j.toFixed(1)}" x2="${s-o}" y2="${j.toFixed(1)}"
              stroke="var(--border)" stroke-width="${B?1:.5}"
              ${B?"":'stroke-dasharray="3 3"'} />
        <text x="${i-8}" y="${j.toFixed(1)}" text-anchor="end" dominant-baseline="central"
              font-size="12" fill="var(--text-3)">${u(Sn(v*x))}</text>`}).join(""),F=e.some(x=>x.incomeFen||x.expenseFen);return`<div class="chart-wrap">
    <svg viewBox="0 0 ${s} ${r}" role="img" aria-label="${u(a)}">
      ${I}
      ${g}
    </svg>
  </div>
  <div class="legend-group" style="margin-top:8px">
    <span class="legend-item"><i class="legend-dot" style="background:var(--income)"></i>收入</span>
    <span class="legend-item"><i class="legend-dot" style="background:var(--expense)"></i>支出</span>
  </div>
  ${F?"":`<div class="muted" style="margin-top:8px">${u(n)}</div>`}`}function Sn(e){if(!e)return"0";const t=e/100;if(t>=1e4){const n=t/1e4;return`${n>=10?String(Math.round(n)):n.toFixed(1).replace(/\.0$/,"")}万`}return String(Math.round(t))}const xe=6,k={unit:"month",key:C("month"),kind:"expense"};function z(e){const t=k.unit;k.key>C(t)&&(k.key=C(t));const n=O(),a=me(t,k.key,n.id),s=me(t,J(t,k.key,-1),n.id),r=Jt(t,k.key,k.kind,n.id),i=Qt(t,k.key,xe,n.id),o=k.key>=C(t),d=ot(t,k.key);e.innerHTML=`
    <div class="scope" data-role="scope">
      ${nt.map(c=>`<button type="button" data-scope="${c}" class="${t===c?"active":""}">${at[c]}</button>`).join("")}
    </div>

    <div class="month-nav">
      <button type="button" class="m-arrow" data-role="prev">‹</button>
      <span class="m-label">${u(d)}</span>
      <button type="button" class="m-arrow" data-role="next" ${o?"disabled":""}>›</button>
    </div>

    <div class="card">
      <p class="card-title">${u(d)}总结</p>
      <div class="summary summary-plain">
        <div><div class="s-val income">${u(b(a.incomeFen))}</div><div class="s-key income">收入</div></div>
        <div><div class="s-val expense">${u(b(a.expenseFen))}</div><div class="s-key expense">支出</div></div>
        <div><div class="s-val balance">${u(b(a.balanceFen))}</div><div class="s-key">结余</div></div>
      </div>
      ${In(a,s,t)}
      ${a.count?"":`<div class="muted" style="margin-top:10px">${u(st[t])}还没有记录</div>`}
    </div>

    <div class="card">
      <div class="seg" data-role="kindseg" style="margin-bottom:12px">
        <button type="button" data-kind="expense">支出构成</button>
        <button type="button" data-kind="income">收入构成</button>
      </div>
      <div data-role="pie"></div>
    </div>

    <div class="card">
      <p class="card-title">最近 ${xe} ${Ye[t]}趋势</p>
      <div data-role="trend"></div>
    </div>
  `,e.querySelector('[data-role="pie"]').innerHTML=En(r.items,{emptyText:`这段时间还没有${k.kind==="income"?"收入":"支出"}记录`}),e.querySelector('[data-role="trend"]').innerHTML=Ln(i,{ariaLabel:`最近 ${xe} ${Ye[t]}的收支趋势柱状图`,emptyText:"这段时间还没有记录"}),e.querySelector('[data-role="scope"]').addEventListener("click",c=>{const f=c.target.closest("[data-scope]");if(!f)return;const m=f.dataset.scope;if(m===k.unit){if(k.key===C(t))return;k.key=C(t),z(e);return}k.key=rt(k.unit,k.key,m),k.unit=m,z(e)}),e.querySelectorAll('[data-role="kindseg"] button').forEach(c=>{c.classList.toggle("active",c.dataset.kind===k.kind),c.addEventListener("click",()=>{k.kind=c.dataset.kind,z(e)})}),e.querySelector('[data-role="prev"]').addEventListener("click",()=>{k.key=J(t,k.key,-1),z(e)}),e.querySelector('[data-role="next"]').addEventListener("click",()=>{k.key=J(t,k.key,1),z(e)}),e.querySelectorAll('[data-role="pie"] .legend-row').forEach((c,f)=>{const m=r.items[f];m&&(c.style.cursor="pointer",c.title="点一下看这个分类的明细",c.addEventListener("click",()=>{xn({unit:k.unit,key:k.key,categoryId:m.categoryId}),De("list")}))})}function In(e,t,n){const a=At[n];if(!e.count)return"";if(!t.count)return`<div class="delta">${a}没有记录，没法比</div>`;const s=e.expenseFen-t.expenseFen;if(s===0)return`<div class="delta">支出和${a}持平</div>`;const r=s>0,i=r?"up":"down",o=`支出比${a}${r?"多":"少"}花 <b>${u(b(Math.abs(s)))}</b> 元`;if(!t.expenseFen)return`<div class="delta ${i}">${o}</div>`;const d=Math.round(Math.abs(s/t.expenseFen)*100);return`<div class="delta ${i}">${o} <b>(${r?"+":"-"}${d}%)</b></div>`}const Pn="modulepreload",Fn=function(e,t){return new URL(e,t).href},ze={},vt=function(t,n,a){let s=Promise.resolve();if(n&&n.length>0){const i=document.getElementsByTagName("link"),o=document.querySelector("meta[property=csp-nonce]"),d=o?.nonce||o?.getAttribute("nonce");s=Promise.allSettled(n.map(c=>{if(c=Fn(c,a),c in ze)return;ze[c]=!0;const f=c.endsWith(".css"),m=f?'[rel="stylesheet"]':"";if(!!a)for(let $=i.length-1;$>=0;$--){const L=i[$];if(L.href===c&&(!f||L.rel==="stylesheet"))return}else if(document.querySelector(`link[href="${c}"]${m}`))return;const p=document.createElement("link");if(p.rel=f?"stylesheet":Pn,f||(p.as="script"),p.crossOrigin="",p.href=c,d&&p.setAttribute("nonce",d),document.head.appendChild(p),f)return new Promise(($,L)=>{p.addEventListener("load",$),p.addEventListener("error",()=>L(new Error(`Unable to preload CSS for ${c}`)))})}))}function r(i){const o=new Event("vite:preloadError",{cancelable:!0});if(o.payload=i,window.dispatchEvent(o),!o.defaultPrevented)throw i}return s.then(i=>{for(const o of i||[])o.status==="rejected"&&r(o.reason);return t().catch(r)})};/*! Capacitor: https://capacitorjs.com/ - MIT License */const Cn=e=>{const t=new Map;t.set("web",{name:"web"});const n=e.CapacitorPlatforms||{currentPlatform:{name:"web"},platforms:t},a=(r,i)=>{n.platforms.set(r,i)},s=r=>{n.platforms.has(r)&&(n.currentPlatform=n.platforms.get(r))};return n.addPlatform=a,n.setPlatform=s,n},Tn=e=>e.CapacitorPlatforms=Cn(e),bt=Tn(typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});bt.addPlatform;bt.setPlatform;var Z;(function(e){e.Unimplemented="UNIMPLEMENTED",e.Unavailable="UNAVAILABLE"})(Z||(Z={}));class Ee extends Error{constructor(t,n,a){super(t),this.message=t,this.code=n,this.data=a}}const jn=e=>{var t,n;return e?.androidBridge?"android":!((n=(t=e?.webkit)===null||t===void 0?void 0:t.messageHandlers)===null||n===void 0)&&n.bridge?"ios":"web"},An=e=>{var t,n,a,s,r;const i=e.CapacitorCustomPlatform||null,o=e.Capacitor||{},d=o.Plugins=o.Plugins||{},c=e.CapacitorPlatforms,f=()=>i!==null?i.name:jn(e),m=((t=c?.currentPlatform)===null||t===void 0?void 0:t.getPlatform)||f,v=()=>m()!=="web",p=((n=c?.currentPlatform)===null||n===void 0?void 0:n.isNativePlatform)||v,$=E=>{const S=j.get(E);return!!(S?.platforms.has(m())||I(E))},L=((a=c?.currentPlatform)===null||a===void 0?void 0:a.isPluginAvailable)||$,g=E=>{var S;return(S=o.PluginHeaders)===null||S===void 0?void 0:S.find(U=>U.name===E)},I=((s=c?.currentPlatform)===null||s===void 0?void 0:s.getPluginHeader)||g,F=E=>e.console.error(E),x=(E,S,U)=>Promise.reject(`${U} does not have an implementation of "${S}".`),j=new Map,B=(E,S={})=>{const U=j.get(E);if(U)return console.warn(`Capacitor plugin "${E}" already registered. Cannot register plugins twice.`),U.proxy;const G=m(),K=I(E);let D;const Lt=async()=>(!D&&G in S?D=typeof S[G]=="function"?D=await S[G]():D=S[G]:i!==null&&!D&&"web"in S&&(D=typeof S.web=="function"?D=await S.web():D=S.web),D),St=(P,T)=>{var q,H;if(K){const W=K?.methods.find(M=>T===M.name);if(W)return W.rtype==="promise"?M=>o.nativePromise(E,T.toString(),M):(M,ie)=>o.nativeCallback(E,T.toString(),M,ie);if(P)return(q=P[T])===null||q===void 0?void 0:q.bind(P)}else{if(P)return(H=P[T])===null||H===void 0?void 0:H.bind(P);throw new Ee(`"${E}" plugin is not implemented on ${G}`,Z.Unimplemented)}},be=P=>{let T;const q=(...H)=>{const W=Lt().then(M=>{const ie=St(M,P);if(ie){const ce=ie(...H);return T=ce?.remove,ce}else throw new Ee(`"${E}.${P}()" is not implemented on ${G}`,Z.Unimplemented)});return P==="addListener"&&(W.remove=async()=>T()),W};return q.toString=()=>`${P.toString()}() { [capacitor code] }`,Object.defineProperty(q,"name",{value:P,writable:!1,configurable:!1}),q},_e=be("addListener"),Be=be("removeListener"),It=(P,T)=>{const q=_e({eventName:P},T),H=async()=>{const M=await q;Be({eventName:P,callbackId:M},T)},W=new Promise(M=>q.then(()=>M({remove:H})));return W.remove=async()=>{console.warn("Using addListener() without 'await' is deprecated."),await H()},W},he=new Proxy({},{get(P,T){switch(T){case"$$typeof":return;case"toJSON":return()=>({});case"addListener":return K?It:_e;case"removeListener":return Be;default:return be(T)}}});return d[E]=he,j.set(E,{name:E,proxy:he,platforms:new Set([...Object.keys(S),...K?[G]:[]])}),he},oe=((r=c?.currentPlatform)===null||r===void 0?void 0:r.registerPlugin)||B;return o.convertFileSrc||(o.convertFileSrc=E=>E),o.getPlatform=m,o.handleError=F,o.isNativePlatform=p,o.isPluginAvailable=L,o.pluginMethodNoop=x,o.registerPlugin=oe,o.Exception=Ee,o.DEBUG=!!o.DEBUG,o.isLoggingEnabled=!!o.isLoggingEnabled,o.platform=o.getPlatform(),o.isNative=o.isNativePlatform(),o},Mn=e=>e.Capacitor=An(e),pe=Mn(typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{}),ve=pe.registerPlugin;pe.Plugins;class ht{constructor(t){this.listeners={},this.retainedEventArguments={},this.windowListeners={},t&&(console.warn(`Capacitor WebPlugin "${t.name}" config object was deprecated in v3 and will be removed in v4.`),this.config=t)}addListener(t,n){let a=!1;this.listeners[t]||(this.listeners[t]=[],a=!0),this.listeners[t].push(n);const r=this.windowListeners[t];r&&!r.registered&&this.addWindowListener(r),a&&this.sendRetainedArgumentsForEvent(t);const i=async()=>this.removeListener(t,n);return Promise.resolve({remove:i})}async removeAllListeners(){this.listeners={};for(const t in this.windowListeners)this.removeWindowListener(this.windowListeners[t]);this.windowListeners={}}notifyListeners(t,n,a){const s=this.listeners[t];if(!s){if(a){let r=this.retainedEventArguments[t];r||(r=[]),r.push(n),this.retainedEventArguments[t]=r}return}s.forEach(r=>r(n))}hasListeners(t){return!!this.listeners[t].length}registerWindowListener(t,n){this.windowListeners[n]={registered:!1,windowEventName:t,pluginEventName:n,handler:a=>{this.notifyListeners(n,a)}}}unimplemented(t="not implemented"){return new pe.Exception(t,Z.Unimplemented)}unavailable(t="not available"){return new pe.Exception(t,Z.Unavailable)}async removeListener(t,n){const a=this.listeners[t];if(!a)return;const s=a.indexOf(n);this.listeners[t].splice(s,1),this.listeners[t].length||this.removeWindowListener(this.windowListeners[t])}addWindowListener(t){window.addEventListener(t.windowEventName,t.handler),t.registered=!0}removeWindowListener(t){t&&(window.removeEventListener(t.windowEventName,t.handler),t.registered=!1)}sendRetainedArgumentsForEvent(t){const n=this.retainedEventArguments[t];n&&(delete this.retainedEventArguments[t],n.forEach(a=>{this.notifyListeners(t,a)}))}}const Je=e=>encodeURIComponent(e).replace(/%(2[346B]|5E|60|7C)/g,decodeURIComponent).replace(/[()]/g,escape),Xe=e=>e.replace(/(%[\dA-F]{2})+/gi,decodeURIComponent);class On extends ht{async getCookies(){const t=document.cookie,n={};return t.split(";").forEach(a=>{if(a.length<=0)return;let[s,r]=a.replace(/=/,"CAP_COOKIE").split("CAP_COOKIE");s=Xe(s).trim(),r=Xe(r).trim(),n[s]=r}),n}async setCookie(t){try{const n=Je(t.key),a=Je(t.value),s=`; expires=${(t.expires||"").replace("expires=","")}`,r=(t.path||"/").replace("path=",""),i=t.url!=null&&t.url.length>0?`domain=${t.url}`:"";document.cookie=`${n}=${a||""}${s}; path=${r}; ${i};`}catch(n){return Promise.reject(n)}}async deleteCookie(t){try{document.cookie=`${t.key}=; Max-Age=0`}catch(n){return Promise.reject(n)}}async clearCookies(){try{const t=document.cookie.split(";")||[];for(const n of t)document.cookie=n.replace(/^ +/,"").replace(/=.*/,`=;expires=${new Date().toUTCString()};path=/`)}catch(t){return Promise.reject(t)}}async clearAllCookies(){try{await this.clearCookies()}catch(t){return Promise.reject(t)}}}ve("CapacitorCookies",{web:()=>new On});const qn=async e=>new Promise((t,n)=>{const a=new FileReader;a.onload=()=>{const s=a.result;t(s.indexOf(",")>=0?s.split(",")[1]:s)},a.onerror=s=>n(s),a.readAsDataURL(e)}),Dn=(e={})=>{const t=Object.keys(e);return Object.keys(e).map(s=>s.toLocaleLowerCase()).reduce((s,r,i)=>(s[r]=e[t[i]],s),{})},Rn=(e,t=!0)=>e?Object.entries(e).reduce((a,s)=>{const[r,i]=s;let o,d;return Array.isArray(i)?(d="",i.forEach(c=>{o=t?encodeURIComponent(c):c,d+=`${r}=${o}&`}),d.slice(0,-1)):(o=t?encodeURIComponent(i):i,d=`${r}=${o}`),`${a}&${d}`},"").substr(1):null,Nn=(e,t={})=>{const n=Object.assign({method:e.method||"GET",headers:e.headers},t),s=Dn(e.headers)["content-type"]||"";if(typeof e.data=="string")n.body=e.data;else if(s.includes("application/x-www-form-urlencoded")){const r=new URLSearchParams;for(const[i,o]of Object.entries(e.data||{}))r.set(i,o);n.body=r.toString()}else if(s.includes("multipart/form-data")||e.data instanceof FormData){const r=new FormData;if(e.data instanceof FormData)e.data.forEach((o,d)=>{r.append(d,o)});else for(const o of Object.keys(e.data))r.append(o,e.data[o]);n.body=r;const i=new Headers(n.headers);i.delete("content-type"),n.headers=i}else(s.includes("application/json")||typeof e.data=="object")&&(n.body=JSON.stringify(e.data));return n};class _n extends ht{async request(t){const n=Nn(t,t.webFetchExtra),a=Rn(t.params,t.shouldEncodeUrlParams),s=a?`${t.url}?${a}`:t.url,r=await fetch(s,n),i=r.headers.get("content-type")||"";let{responseType:o="text"}=r.ok?t:{};i.includes("application/json")&&(o="json");let d,c;switch(o){case"arraybuffer":case"blob":c=await r.blob(),d=await qn(c);break;case"json":d=await r.json();break;case"document":case"text":default:d=await r.text()}const f={};return r.headers.forEach((m,v)=>{f[v]=m}),{data:d,headers:f,status:r.status,url:r.url}}async get(t){return this.request(Object.assign(Object.assign({},t),{method:"GET"}))}async post(t){return this.request(Object.assign(Object.assign({},t),{method:"POST"}))}async put(t){return this.request(Object.assign(Object.assign({},t),{method:"PUT"}))}async patch(t){return this.request(Object.assign(Object.assign({},t),{method:"PATCH"}))}async delete(t){return this.request(Object.assign(Object.assign({},t),{method:"DELETE"}))}}ve("CapacitorHttp",{web:()=>new _n});var Ce;(function(e){e.Documents="DOCUMENTS",e.Data="DATA",e.Library="LIBRARY",e.Cache="CACHE",e.External="EXTERNAL",e.ExternalStorage="EXTERNAL_STORAGE"})(Ce||(Ce={}));var Te;(function(e){e.UTF8="utf8",e.ASCII="ascii",e.UTF16="utf16"})(Te||(Te={}));const Bn=ve("Filesystem",{web:()=>vt(()=>import("./web-BA96bVja.js"),[],import.meta.url).then(e=>new e.FilesystemWeb)}),Un=ve("Share",{web:()=>vt(()=>import("./web-BGCqr6Ok.js"),[],import.meta.url).then(e=>new e.ShareWeb)});function Hn(){return!!window.Capacitor?.isNativePlatform?.()}async function wt(e,t,n="text/plain"){if(Hn()){const i=await Bn.writeFile({path:e,data:t,directory:Ce.Cache,encoding:Te.UTF8});try{return await Un.share({title:e,text:e,url:i.uri,dialogTitle:"保存或发送这个文件"}),{mode:"share"}}catch(o){return{mode:"share-failed",uri:i.uri,message:o?.message||""}}}const a=new Blob([t],{type:`${n};charset=utf-8`}),s=URL.createObjectURL(a),r=document.createElement("a");return r.href=s,r.download=e,document.body.appendChild(r),r.click(),r.remove(),setTimeout(()=>URL.revokeObjectURL(s),1e3),{mode:"download"}}function Wn(e=".json,application/json"){return new Promise(t=>{const n=document.createElement("input");n.type="file",n.accept=e,n.style.display="none";let a=!1;const s=r=>{a||(a=!0,n.remove(),t(r))};n.addEventListener("change",()=>{const r=n.files?.[0];if(!r)return s(null);const i=new FileReader;i.onload=()=>s(String(i.result)),i.onerror=()=>s(null),i.readAsText(r,"utf-8")}),window.addEventListener("focus",()=>setTimeout(()=>{n.files?.length||s(null)},800),{once:!0}),document.body.appendChild(n),n.click()})}function $t(){const e=new Date,t=n=>String(n).padStart(2,"0");return`${e.getFullYear()}${t(e.getMonth()+1)}${t(e.getDate())}-${t(e.getHours())}${t(e.getMinutes())}`}const Yn=["🍚","🍜","🍔","🍰","☕","🍺","🚌","🚇","🚕","⛽","🛒","👕","💄","🏠","💡","📱","🎮","🎬","✈️","🏨","💊","🏥","📚","✏️","🎓","🎁","💵","💰","💼","📈","🐱","👶","🔧","🚿","🛁","🏋️","🎵","📷","🌸","📦","💳","🏦","💎","🎯","📄","💉","🍎","🚗","🛵","🎨","🧧"];function N(e){const t=document.createElement("div");e.replaceChildren(t);const n=O(),a=lt(ge(),n.id),s=n.budgetFen||0,r=l.meta.lastBackupAt||0;t.innerHTML=`
    <div class="set-group">
      <h2>账本</h2>
      <div class="set-list">
        <button type="button" class="set-row" data-act="ledgers">
          <span class="sr-ico">📒</span>
          <span class="sr-main">${u(n.name)}<span class="sr-sub">共 ${l.ledgers.length} 个账本，点这里切换</span></span>
          <span class="sr-arrow">›</span>
        </button>
        <button type="button" class="set-row" data-act="budget">
          <span class="sr-ico">🎯</span>
          <span class="sr-main">本月预算<span class="sr-sub">本月已花 ${u(b(a.expenseFen))} 元</span></span>
          <span class="sr-val">${s?u(b(s))+" 元":"未设置"}</span>
          <span class="sr-arrow">›</span>
        </button>
        <button type="button" class="set-row" data-act="rename">
          <span class="sr-ico">✏️</span>
          <span class="sr-main">重命名当前账本</span>
          <span class="sr-arrow">›</span>
        </button>
        <button type="button" class="set-row" data-act="newledger">
          <span class="sr-ico">➕</span>
          <span class="sr-main">新建账本<span class="sr-sub">比如「装修」「旅行」，数据各算各的</span></span>
          <span class="sr-arrow">›</span>
        </button>
      </div>
    </div>

    <div class="set-group">
      <h2>分类</h2>
      <div class="set-list">
        <button type="button" class="set-row" data-act="cats">
          <span class="sr-ico">🏷️</span>
          <span class="sr-main">分类管理<span class="sr-sub">新增、改名、换图标、调顺序、删除</span></span>
          <span class="sr-val">${l.categories.length} 个</span>
          <span class="sr-arrow">›</span>
        </button>
      </div>
    </div>

    <div class="set-group">
      <h2>数据</h2>
      <div class="set-list">
        <button type="button" class="set-row" data-act="csv">
          <span class="sr-ico">📊</span>
          <span class="sr-main">导出当前账本为 CSV<span class="sr-sub">Excel / WPS 能直接打开</span></span>
          <span class="sr-arrow">›</span>
        </button>
        <button type="button" class="set-row" data-act="backup">
          <span class="sr-ico">💾</span>
          <span class="sr-main">导出完整备份<span class="sr-sub">所有账本、分类、预算，一个文件全带走</span></span>
          <span class="sr-val">${u(Gn(r))}</span>
          <span class="sr-arrow">›</span>
        </button>
        <button type="button" class="set-row" data-act="restore">
          <span class="sr-ico">📥</span>
          <span class="sr-main">从备份恢复<span class="sr-sub" style="color:var(--danger)">会覆盖现在的全部数据</span></span>
          <span class="sr-arrow">›</span>
        </button>
        <button type="button" class="set-row" data-act="wipe">
          <span class="sr-ico">🗑️</span>
          <span class="sr-main" style="color:var(--danger)">清空所有数据</span>
          <span class="sr-arrow">›</span>
        </button>
      </div>
      <p class="muted" style="margin:10px 6px 0">
        数据全部存在这台手机里，不联网、不上传。换手机或者怕丢，记得定期「导出完整备份」，把文件存到网盘或发给自己。
      </p>
    </div>

    <div class="set-group">
      <h2>关于</h2>
      <div class="set-list">
        <div class="set-row" style="cursor:default">
          <span class="sr-ico">ℹ️</span>
          <span class="sr-main">记账本<span class="sr-sub">本地版 v${u(Ct)} · 记录 ${l.transactions.length} 笔</span></span>
        </div>
      </div>
    </div>
  `,t.addEventListener("click",async i=>{const o=i.target.closest("[data-act]");if(!o)return;const d=o.dataset.act,c=()=>N(e);if(d==="ledgers")return Vn(e);if(d==="budget")return Jn(e);if(d==="rename")return zn(e);if(d==="newledger")return Kn(e);if(d==="cats")return Qn(e);if(d==="csv")return Zn();if(d==="backup")return ea(c);if(d==="restore")return ta(c);if(d==="wipe")return na(c)})}function Gn(e){if(!e)return"还没有备份";const t=et(Y(new Date(e)),Y(new Date));return t<=0?"今天刚备份":t===1?"昨天备份":`${t} 天前备份`}function Vn(e){const t=l.ledgers.map(a=>`<button type="button" class="set-row" data-id="${a.id}">
        <span class="sr-ico">${a.id===l.meta.currentLedgerId?"✅":"📒"}</span>
        <span class="sr-main">${u(a.name)}
          <span class="sr-sub">${l.transactions.filter(s=>s.ledgerId===a.id).length} 笔${a.budgetFen?" · 预算 "+u(b(a.budgetFen)):""}</span>
        </span>
        ${l.ledgers.length>1?`<span class="sr-val" data-del="${a.id}">删除</span>`:""}
      </button>`).join(""),n=_({title:"选择账本",body:`<div class="set-list">${t}</div>
      <p class="muted" style="margin-top:12px">每个账本的记录和统计互相独立，切换后首页、账单、统计都会跟着变。</p>`});n.body.addEventListener("click",async a=>{const s=a.target.closest("[data-del]");if(s){a.stopPropagation();const i=l.ledgers.find(c=>c.id===s.dataset.del),o=l.transactions.filter(c=>c.ledgerId===i.id).length;if(!await Q({title:`删除「${i.name}」？`,message:o?`这个账本里有 ${o} 笔记录，会一起删掉，删了没法恢复。`:"这个账本还是空的，删掉不影响别的账本。",okText:"删除",danger:!0}))return;try{await Bt(i.id),h("已删除账本"),n.close(),N(e)}catch(c){h(c.message)}return}const r=a.target.closest("[data-id]");r&&(await Oe(r.dataset.id),h("已切换账本"),n.close(),N(e))})}function Kn(e){const t=_({title:"新建账本",body:`<div class="field-grid">
      <div class="field"><span class="field-label">名字</span>
        <input type="text" data-role="name" maxlength="12" placeholder="例如：装修" /></div>
      <div class="field"><span class="field-label">预算</span>
        <input type="text" inputmode="decimal" data-role="budget" placeholder="选填，每月支出上限" /></div>
    </div>
    <p class="muted" style="margin-top:10px">预算可以以后再设，先建账本也行。</p>`,actions:[{label:"取消",className:"btn-outline",onClick:n=>n.close()},{label:"创建",className:"btn-primary",onClick:async n=>{const a=n.body.querySelector('[data-role="name"]').value.trim(),s=n.body.querySelector('[data-role="budget"]').value.trim();if(!a)return h("给账本起个名字");let r=0;if(s){const o=fe(s);if(o===null||o<0)return h("预算填个数字就行，比如 3000");r=o}const i=await _t(a,r);await Oe(i.id),h(`已创建「${a}」并切过去了`),n.close(),N(e)}}]});setTimeout(()=>t.body.querySelector('[data-role="name"]')?.focus(),120)}function zn(e){const t=O(),n=_({title:"重命名账本",body:`<div class="field-grid">
      <div class="field"><span class="field-label">名字</span>
        <input type="text" data-role="name" maxlength="12" value="${u(t.name)}" /></div>
    </div>`,actions:[{label:"取消",className:"btn-outline",onClick:a=>a.close()},{label:"保存",className:"btn-primary",onClick:async a=>{const s=a.body.querySelector('[data-role="name"]').value.trim();if(!s)return h("名字不能是空的");await Ie(t.id,{name:s}),h("已改名"),a.close(),N(e)}}]});setTimeout(()=>n.body.querySelector('[data-role="name"]')?.select(),120)}function Jn(e){const t=O(),n=_({title:"本月预算",body:`<div class="field-grid">
      <div class="field"><span class="field-label">金额</span>
        <input type="text" inputmode="decimal" data-role="amount"
               placeholder="比如 3000，填 0 表示不设预算"
               value="${t.budgetFen?u(Ze(t.budgetFen)):""}" /></div>
    </div>
    <p class="muted" style="margin-top:10px">这是每个月总的支出上限，花到 80% 会提醒你。</p>`,actions:[{label:"取消",className:"btn-outline",onClick:a=>a.close()},{label:"保存",className:"btn-primary",onClick:async a=>{const s=a.body.querySelector('[data-role="amount"]').value.trim();if(!s)return await Ie(t.id,{budgetFen:0}),h("已取消预算"),a.close(),N(e);const r=fe(s);if(r===null)return h("填数字就行，比如 3000");await Ie(t.id,{budgetFen:r}),h(r?`预算设为 ${b(r)} 元`:"已取消预算"),a.close(),N(e)}}]});setTimeout(()=>n.body.querySelector('[data-role="amount"]')?.focus(),120)}function Xn(e,t){const n=`${e} 笔记录在用`;if(!t)return n;const a=(t.ratio*100).toFixed(0);return`${n} · 本月 ${b(t.spentFen)} / ${b(t.budgetFen)} 元（${a}%）`}function Qn(e,t="expense"){const n=_({title:"分类管理",body:`
      <div class="seg" data-role="seg" style="margin-bottom:12px">
        <button type="button" data-kind="expense">支出分类</button>
        <button type="button" data-kind="income">收入分类</button>
      </div>
      <div data-role="list"></div>
      <button type="button" class="btn btn-outline btn-block" data-role="add" style="margin-top:14px">➕ 新增分类</button>
      <p class="muted" style="margin-top:12px">↑↓ 调整分类在记账页的排列顺序。点分类可以改名、换图标，也可以给支出分类设月预算。删掉分类不会删掉记录，那些记录会显示成「未分类」。</p>`});function a(){const s=ne(t),r=t==="expense"?mt(ge()):new Map;n.body.querySelectorAll('[data-role="seg"] button').forEach(o=>{o.classList.toggle("active",o.dataset.kind===t)});const i=n.body.querySelector('[data-role="list"]');i.innerHTML=`<div class="set-list">${s.map((o,d)=>{const c=ct(o.id),f=r.get(o.id);return`<div class="cat-row">
          <button type="button" class="cat-row-main" data-cat="${o.id}">
            <span class="cm-emoji">${u(o.emoji)}</span>
            <span class="cm-body">
              <div class="cm-name">${u(o.name)}</div>
              <div class="cm-sub ${f?f.level:""}">${Xn(c,f)}</div>
            </span>
          </button>
          <span class="cm-tools">
            <button type="button" class="mini-btn" data-up="${o.id}" ${d===0?"disabled":""} aria-label="上移">↑</button>
            <button type="button" class="mini-btn" data-down="${o.id}" ${d===s.length-1?"disabled":""} aria-label="下移">↓</button>
          </span>
        </div>`}).join("")}</div>`,i.querySelectorAll("[data-cat]").forEach(o=>{o.addEventListener("click",()=>Qe(l.categories.find(d=>d.id===o.dataset.cat),()=>a()))}),i.querySelectorAll("[data-up], [data-down]").forEach(o=>{o.addEventListener("click",async()=>{const d=o.dataset.up?-1:1,c=o.dataset.up||o.dataset.down;await Ht(c,d)&&a()})})}n.body.querySelectorAll('[data-role="seg"] button').forEach(s=>{s.addEventListener("click",()=>{t=s.dataset.kind,a()})}),n.body.querySelector('[data-role="add"]').addEventListener("click",()=>{Qe(null,()=>{n.close(),N(e)},e,t)}),a()}function Qe(e,t,n,a="expense"){const s=!e;let r=e?.emoji??"📦",i=e?.kind??a;const o=_({title:s?"新增分类":"编辑分类",body:`
      <div class="field-grid">
        <div class="field"><span class="field-label">名称</span>
          <input type="text" data-role="name" maxlength="6" value="${u(e?.name??"")}" placeholder="最多 6 个字" /></div>
        <div class="field"><span class="field-label">类型</span>
          <select data-role="kind">
            <option value="expense" ${i==="expense"?"selected":""}>支出</option>
            <option value="income" ${i==="income"?"selected":""}>收入</option>
          </select></div>
        <div class="field" data-role="budget-field" ${i==="expense"?"":"hidden"}>
          <span class="field-label">月预算</span>
          <input type="text" inputmode="decimal" data-role="budget" placeholder="选填，比如 1000"
                 value="${e?.budgetFen?u(Ze(e.budgetFen)):""}" /></div>
      </div>
      <p class="muted" data-role="budget-hint" style="margin-top:10px" ${i==="expense"?"":"hidden"}>
        月预算是这个分类每月的支出上限。记账页的分类格上会显示进度，花到八成变黄、超支变红。留空或填 0 就是不设。
      </p>
      <p class="card-title" style="margin:16px 0 8px">选个图标</p>
      <div class="emoji-grid" data-role="emojis">
        ${Yn.map(d=>`<button type="button" data-e="${d}" class="${d===r?"active":""}">${d}</button>`).join("")}
      </div>
      ${s?"":'<div class="divider"></div><button type="button" class="btn btn-danger btn-block" data-role="del">删除这个分类</button>'}`,actions:[{label:"取消",className:"btn-outline",onClick:d=>d.close()},{label:s?"创建":"保存",className:"btn-primary",onClick:async d=>{const c=d.body.querySelector('[data-role="name"]').value.trim();if(!c)return h("给分类起个名字");const f=d.body.querySelector('[data-role="kind"]').value,m=d.body.querySelector('[data-role="budget"]').value.trim();let v=0;if(f==="expense"&&m){const p=fe(m);if(p===null||p<0)return h("月预算填个数字就行，比如 1000");v=p}s?(await Ut(f,c,r,v),h(v?`分类已添加，月预算 ${b(v)} 元`:"分类已添加")):(await Wt(e.id,{name:c,emoji:r,kind:f,budgetFen:v}),h(v?`已保存，月预算 ${b(v)} 元`:"已保存")),d.close(),t?.()}}]});o.body.querySelector('[data-role="kind"]').addEventListener("change",d=>{const c=d.target.value==="expense";o.body.querySelector('[data-role="budget-field"]').hidden=!c,o.body.querySelector('[data-role="budget-hint"]').hidden=!c}),o.body.querySelector('[data-role="emojis"]').addEventListener("click",d=>{const c=d.target.closest("[data-e]");c&&(r=c.dataset.e,o.body.querySelectorAll("[data-e]").forEach(f=>f.classList.toggle("active",f===c)))}),o.body.querySelector('[data-role="del"]')?.addEventListener("click",async()=>{const d=ct(e.id);await Q({title:`删除「${e.name}」？`,message:d?`有 ${d} 笔记录在用这个分类。删掉分类不会删记录，但那些记录会变成「未分类」。`:"这个分类还没被用过，可以放心删。",okText:"删除",danger:!0})&&(await Yt(e.id),h("已删除"),o.close(),t?.())}),setTimeout(()=>o.body.querySelector('[data-role="name"]')?.focus(),120)}function kt(e){return e.mode==="download"?"已导出，去「下载」或「文件」里找":e.mode==="share-failed"?"文件已生成，但发送面板没弹出来："+(e.message||"系统限制"):"已导出，选个地方保存吧"}async function Zn(){const e=O(),t=tn(e.id),n=t.split(`\r
`).length-1;if(!n)return h("这个账本还没有记录，导出来是空的");const a=`${e.name}-${$t()}.csv`;try{const s=await wt(a,"\uFEFF"+t,"text/csv");h(`${s.mode==="download"?`已导出 ${n} 条，`:""}${kt(s)}`)}catch(s){h("导出失败："+(s.message||"未知原因"))}}async function ea(e){if(!l.transactions.length)return h("还没有数据可以备份");const t=`记账备份-${$t()}.json`;try{const n=await wt(t,JSON.stringify(en(),null,2),"application/json");await ee("lastBackupAt",Date.now()),h(kt(n)),e?.()}catch(n){h("导出失败："+(n.message||"未知原因"))}}async function ta(e){let t=null;if(!await Q({title:"从备份恢复？",message:`导入后，现在手机里的所有记录、账本、分类都会被备份文件里的内容替换掉，换不回来。

建议先「导出完整备份」存一份再操作。`,okText:"继续选择文件",danger:!0,onOk:()=>{t=Wn()}})||!t)return;const a=await t;if(a==null)return;let s;try{s=JSON.parse(a)}catch{return ke({title:"这个文件读不了",message:`它看起来不是备份文件，可能选错了。
请选之前用「导出完整备份」生成的那个 .json 文件。`})}try{const r=await an(s);await ee("lastBackupAt",Date.now()),await ke({title:"恢复完成",message:`成功导入 ${r} 笔记录。`}),e()}catch(r){await ke({title:"恢复失败",message:r.message})}}async function na(e){!await Q({title:"清空所有数据？",message:`现在一共有 ${l.transactions.length} 笔记录、${l.ledgers.length} 个账本。
清空之后全部消失，没法恢复。`,okText:"我确定",danger:!0})||!await Q({title:"最后确认一次",message:"真的要清空吗？建议先在电脑上导出一份备份放着。",okText:"清空",danger:!0})||(await w.clearAll(),await Me(),h("已清空"),e())}const aa={record:"记账",list:"账单",stats:"统计",settings:"设置"},xt=document.getElementById("view"),sa=document.getElementById("pageTitle"),ra=document.getElementById("ledgerName"),oa={record:gt,list:A,stats:z,settings:N},je={};let te=null;function Et(){ra.textContent=O()?.name??""}function ae(){const e=qe();te&&te!==e&&(je[te]=window.scrollY);const t=te===e?window.scrollY:je[e]||0;te=e,sa.textContent=aa[e],Et(),document.querySelectorAll(".tab").forEach(n=>n.classList.toggle("active",n.dataset.tab===e)),oa[e](xt),window.scrollTo(0,t)}Nt(Et);document.addEventListener("touchstart",()=>{},{passive:!0});function Ne(){const e=l.meta.theme,t=e?e==="dark":window.matchMedia("(prefers-color-scheme: dark)").matches;document.documentElement.dataset.theme=t?"dark":"light",document.querySelector('meta[name="theme-color"]')?.setAttribute("content",t?"#1d2027":"#3b7dd8")}document.getElementById("themeToggle").addEventListener("click",async()=>{const e=document.documentElement.dataset.theme==="dark"?"light":"dark";await ee("theme",e),Ne()});window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change",()=>{l.meta.theme||Ne()});document.getElementById("ledgerSwitch").addEventListener("click",()=>{const e=l.ledgers.map(n=>({value:n.id,label:n.name,emoji:n.id===l.meta.currentLedgerId?"✅":"📒",sub:`${l.transactions.filter(a=>a.ledgerId===n.id).length} 笔`})),t=_({title:"切换账本",body:`<div class="set-list">${e.map(n=>`<button type="button" class="set-row" data-id="${n.value}">
          <span class="sr-ico">${n.emoji}</span>
          <span class="sr-main">${u(n.label)}<span class="sr-sub">${n.sub}</span></span>
        </button>`).join("")}</div>
    <p class="muted" style="margin-top:12px">要新建或删除账本，去「设置 → 账本」。</p>`});t.body.addEventListener("click",async n=>{const a=n.target.closest("[data-id]");a&&(await Oe(a.dataset.id),t.close(),h("已切换账本"),Re(),ae())})});document.querySelectorAll(".tab").forEach(e=>{e.addEventListener("click",()=>{const t=e.dataset.tab;t==="list"&&Re(),t===qe()?(je[t]=0,ae()):De(t)})});ln(ae);const ia=!!window.Capacitor?.isNativePlatform?.();"serviceWorker"in navigator&&(ia?navigator.serviceWorker.getRegistrations?.().then(e=>e.forEach(t=>t.unregister())).catch(()=>{}):window.addEventListener("load",()=>{navigator.serviceWorker.register("./sw.js").catch(()=>{})}));async function ca(){try{await Me()}catch(e){xt.innerHTML=`<div class="empty"><span class="empty-ico">😵</span>
      数据打不开了：${u(e.message)}<br /><br />
      可以试试刷新页面。如果还是不行，可能是浏览器禁用了本地存储。</div>`;return}Ne(),Re(),ae(),window.addEventListener("focus",()=>{qe()==="list"&&ae()})}ca();export{Te as E,ht as W,Nn as b};
