(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))a(s);new MutationObserver(s=>{for(const r of s)if(r.type==="childList")for(const o of r.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&a(o)}).observe(document,{childList:!0,subtree:!0});function n(s){const r={};return s.integrity&&(r.integrity=s.integrity),s.referrerPolicy&&(r.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?r.credentials="include":s.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function a(s){if(s.ep)return;s.ep=!0;const r=n(s);fetch(s.href,r)}})();const ft="jizhang",vt=1,Be=["transactions","categories","ledgers","meta"];let ie=null;function ce(){return ie||(ie=new Promise((e,t)=>{const n=indexedDB.open(ft,vt);n.onupgradeneeded=()=>{const a=n.result;if(!a.objectStoreNames.contains("transactions")){const s=a.createObjectStore("transactions",{keyPath:"id"});s.createIndex("ledgerId","ledgerId"),s.createIndex("ledger_date",["ledgerId","date"])}a.objectStoreNames.contains("categories")||a.createObjectStore("categories",{keyPath:"id"}).createIndex("ledgerId","ledgerId"),a.objectStoreNames.contains("ledgers")||a.createObjectStore("ledgers",{keyPath:"id"}),a.objectStoreNames.contains("meta")||a.createObjectStore("meta",{keyPath:"key"})},n.onsuccess=()=>e(n.result),n.onerror=()=>t(n.error)}),ie)}function he(e,t){return ce().then(n=>n.transaction(e,t).objectStore(e))}function we(e){return new Promise((t,n)=>{e.onsuccess=()=>t(e.result),e.onerror=()=>n(e.error)})}const h={async getAll(e){const t=await he(e,"readonly");return we(t.getAll())},async put(e,t){const n=await he(e,"readwrite");return we(n.put(t))},async putMany(e,t){if(!t.length)return;const n=await ce();return new Promise((a,s)=>{const r=n.transaction(e,"readwrite"),o=r.objectStore(e);t.forEach(i=>o.put(i)),r.oncomplete=()=>a(),r.onerror=()=>s(r.error),r.onabort=()=>s(r.error)})},async remove(e,t){const n=await he(e,"readwrite");return we(n.delete(t))},async removeMany(e,t){if(!t.length)return;const n=await ce();return new Promise((a,s)=>{const r=n.transaction(e,"readwrite"),o=r.objectStore(e);t.forEach(i=>o.delete(i)),r.oncomplete=()=>a(),r.onerror=()=>s(r.error)})},async clearAll(){const e=await ce();return new Promise((t,n)=>{const a=e.transaction(Be,"readwrite");Be.forEach(s=>a.objectStore(s).clear()),a.oncomplete=()=>t(),a.onerror=()=>n(a.error)})}};function V(){return Date.now().toString(36)+Math.random().toString(36).slice(2,8)}function yt(e){const t=e<0,n=Math.abs(e),a=Math.floor(n/100),s=n%100;return(t?"-":"")+a+(s?"."+String(s).padStart(2,"0"):"")}function w(e){const t=e<0,n=Math.abs(e),a=Math.floor(n/100),s=n%100,r=a.toLocaleString("en-US"),o=s?`${r}.${String(s).padStart(2,"0")}`:`${r}.00`;return(t?"-":"")+o}function je(e){const t=String(e).trim();if(!t||!/^\d*(\.\d{0,2})?$/.test(t))return null;const n=Number(t);return Number.isFinite(n)?Math.round(n*100):null}function Z(){return le(new Date)}function le(e){const t=e.getFullYear(),n=String(e.getMonth()+1).padStart(2,"0"),a=String(e.getDate()).padStart(2,"0");return`${t}-${n}-${a}`}function Ue(e=0){const t=new Date;return t.setDate(t.getDate()-e),le(t)}function Je(e,t){const n=a=>{const[s,r,o]=String(a).split("-").map(Number);return new Date(s,r-1,o).getTime()};return Math.round((n(t)-n(e))/864e5)}function G(e){return String(e).slice(0,7)}function C(){return Z().slice(0,7)}function K(e,t){const[n,a]=e.split("-").map(Number),s=new Date(n,a-1+t,1);return`${s.getFullYear()}-${String(s.getMonth()+1).padStart(2,"0")}`}function _e(e){const[t,n,a]=e.split("-").map(Number),s=new Date(t,n-1,a),r=["周日","周一","周二","周三","周四","周五","周六"][s.getDay()];return`${n}月${a}日 ${r}`}function ue(e){const[t,n]=e.split("-").map(Number),a=new Date().getFullYear();return t===a?`${n}月`:`${t}年${n}月`}function u(e){return String(e??"").replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t])}const He=["#3b7dd8","#e0575b","#26a06a","#e0a32e","#8b5cf6","#12a5b8","#e0669a","#7a8b3f","#c2743a","#5a6b8c"];function We(e){return He[e%He.length]}function me(e,t){return e.reduce((n,a)=>n+t(a),0)}function bt(e){const t=me(e.filter(a=>a.kind==="income"),a=>a.amountFen),n=me(e.filter(a=>a.kind==="expense"),a=>a.amountFen);return{incomeFen:t,expenseFen:n,balanceFen:t-n}}const Xe=[{kind:"expense",name:"餐饮",emoji:"🍚"},{kind:"expense",name:"交通",emoji:"🚌"},{kind:"expense",name:"购物",emoji:"🛒"},{kind:"expense",name:"房租水电",emoji:"🏠"},{kind:"expense",name:"娱乐",emoji:"🎮"},{kind:"expense",name:"医疗",emoji:"💊"},{kind:"expense",name:"学习",emoji:"📚"},{kind:"expense",name:"人情",emoji:"🎁"},{kind:"expense",name:"其他",emoji:"📦"},{kind:"income",name:"工资",emoji:"💰"},{kind:"income",name:"红包",emoji:"💵"},{kind:"income",name:"理财",emoji:"📈"},{kind:"income",name:"兼职",emoji:"💼"},{kind:"income",name:"其他",emoji:"📦"}],ht="日常账本",l={ledgers:[],categories:[],transactions:[],meta:{},loaded:!1};async function Ae(){const[e,t,n,a]=await Promise.all([h.getAll("ledgers"),h.getAll("categories"),h.getAll("transactions"),h.getAll("meta")]);if(l.ledgers=e.sort(xe),l.categories=t.sort(xe),l.transactions=n,l.meta=Object.fromEntries(a.map(s=>[s.key,s.value])),!l.ledgers.length){const s={id:V(),name:ht,budgetFen:0,order:0,createdAt:Date.now()};l.ledgers=[s],await h.put("ledgers",s),l.meta.currentLedgerId=s.id,await h.put("meta",{key:"currentLedgerId",value:s.id})}l.categories.length||(l.categories=Xe.map((s,r)=>({id:V(),kind:s.kind,name:s.name,emoji:s.emoji,order:r})),await h.putMany("categories",l.categories)),(!l.meta.currentLedgerId||!l.ledgers.some(s=>s.id===l.meta.currentLedgerId))&&(l.meta.currentLedgerId=l.ledgers[0].id,await h.put("meta",{key:"currentLedgerId",value:l.meta.currentLedgerId})),l.loaded=!0}function xe(e,t){return(e.order??0)-(t.order??0)}async function X(e,t){l.meta[e]=t,await h.put("meta",{key:e,value:t})}function j(){return l.ledgers.find(e=>e.id===l.meta.currentLedgerId)||l.ledgers[0]}const Ee=new Set;function wt(e){return Ee.add(e),()=>Ee.delete(e)}function ge(){const e=j();Ee.forEach(t=>t(e))}async function Me(e){l.ledgers.some(t=>t.id===e)&&(await X("currentLedgerId",e),ge())}async function $t(e,t=0){const n={id:V(),name:e.trim(),budgetFen:t,order:l.ledgers.length,createdAt:Date.now()};return l.ledgers.push(n),await h.put("ledgers",n),n}async function Le(e,t){const n=l.ledgers.find(a=>a.id===e);n&&(Object.assign(n,t),await h.put("ledgers",n),ge())}async function kt(e){if(l.ledgers.length<=1)throw new Error("至少要保留一个账本");const t=l.transactions.filter(n=>n.ledgerId===e);l.transactions=l.transactions.filter(n=>n.ledgerId!==e),l.ledgers=l.ledgers.filter(n=>n.id!==e),await h.removeMany("transactions",t.map(n=>n.id)),await h.remove("ledgers",e),l.meta.currentLedgerId===e&&await X("currentLedgerId",l.ledgers[0].id),ge()}function ee(e){return l.categories.filter(t=>t.kind===e).sort(xe)}function _(e){return l.categories.find(t=>t.id===e)}async function xt(e,t,n){const a=l.categories.filter(r=>r.kind===e),s={id:V(),kind:e,name:t.trim(),emoji:n||"📦",order:a.reduce((r,o)=>Math.max(r,o.order??0),-1)+1};return l.categories.push(s),await h.put("categories",s),s}async function Et(e,t){const n=_(e);if(!n)return!1;const a=ee(n.kind),s=a.findIndex(o=>o.id===e),r=s+t;return s<0||r<0||r>=a.length?!1:(a.splice(r,0,a.splice(s,1)[0]),await Promise.all(a.map((o,i)=>(o.order=i,h.put("categories",o)))),!0)}async function Lt(e,t){const n=_(e);n&&(Object.assign(n,t),await h.put("categories",n))}function Qe(e){return l.transactions.filter(t=>t.categoryId===e).length}async function St(e){l.categories=l.categories.filter(t=>t.id!==e),await h.remove("categories",e)}function ae(e=l.meta.currentLedgerId){return l.transactions.filter(t=>t.ledgerId===e)}async function Ze(e){const t=Date.now(),n={id:V(),ledgerId:e.ledgerId,kind:e.kind,amountFen:e.amountFen,categoryId:e.categoryId,date:e.date,note:e.note||"",createdAt:t,updatedAt:t};return l.transactions.push(n),await h.put("transactions",n),n}async function It(e,t){const n=l.transactions.find(a=>a.id===e);n&&(Object.assign(n,t,{updatedAt:Date.now()}),await h.put("transactions",n))}async function Pt(e){const t=l.transactions.find(n=>n.id===e)||null;return l.transactions=l.transactions.filter(n=>n.id!==e),await h.remove("transactions",e),t}async function Ct(e){e&&(l.transactions.some(t=>t.id===e.id)||(l.transactions.push(e),await h.put("transactions",e)))}function Ft(e,t=l.meta.currentLedgerId,{categoryId:n="",keyword:a="",scope:s="month"}={}){const r=a.trim().toLowerCase();return ae(t).filter(o=>s==="all"||G(o.date)===e).filter(o=>!n||o.categoryId===n).filter(o=>{if(!r)return!0;const i=_(o.categoryId);return(o.note||"").toLowerCase().includes(r)||(i?.name||"").toLowerCase().includes(r)}).sort((o,i)=>o.date===i.date?i.createdAt-o.createdAt:i.date.localeCompare(o.date))}function te(e,t=l.meta.currentLedgerId){const n=ae(t).filter(r=>G(r.date)===e),a=n.filter(r=>r.kind==="income").reduce((r,o)=>r+o.amountFen,0),s=n.filter(r=>r.kind==="expense").reduce((r,o)=>r+o.amountFen,0);return{incomeFen:a,expenseFen:s,balanceFen:a-s,count:n.length}}function jt(e,t,n=l.meta.currentLedgerId){const a=ae(n).filter(o=>o.kind===t&&G(o.date)===e),s=new Map;for(const o of a){const i=o.categoryId,c=s.get(i)||{categoryId:i,amountFen:0,count:0};c.amountFen+=o.amountFen,c.count+=1,s.set(i,c)}const r=[...s.values()].reduce((o,i)=>o+i.amountFen,0);return{total:r,items:[...s.values()].map(o=>{const i=_(o.categoryId);return{...o,name:i?.name??"未分类",emoji:i?.emoji??"❓",pct:r?o.amountFen/r:0}}).sort((o,i)=>i.amountFen-o.amountFen)}}function At(e,t=l.meta.currentLedgerId){return e.map(n=>({month:n,...te(n,t)}))}function Mt(e=l.meta.currentLedgerId){const t=ae(e);return t.length?t.reduce((n,a)=>G(a.date)<n?G(a.date):n,G(t[0].date)):C()}function Tt(){return{app:"jizhang",version:1,exportedAt:new Date().toISOString(),ledgers:l.ledgers,categories:l.categories,transactions:l.transactions,meta:{currentLedgerId:l.meta.currentLedgerId}}}function qt(e=l.meta.currentLedgerId){const t=l.ledgers.find(a=>a.id===e),n=[["日期","类型","分类","金额(元)","备注","账本"]];return ae(e).slice().sort((a,s)=>a.date.localeCompare(s.date)||a.createdAt-s.createdAt).forEach(a=>{n.push([a.date,a.kind==="expense"?"支出":"收入",_(a.categoryId)?.name??"未分类",(a.amountFen/100).toFixed(2),a.note||"",t?.name??""])}),n.map(a=>a.map(Ot).join(",")).join(`\r
`)}function Ot(e){const t=String(e??"");return/[",\r\n]/.test(t)?`"${t.replace(/"/g,'""')}"`:t}async function Dt(e){if(!e||e.app!=="jizhang")throw new Error("这不是本 App 导出的备份文件");if(!Array.isArray(e.ledgers)||!Array.isArray(e.transactions))throw new Error("备份文件内容不完整，可能传坏了");const t=e.ledgers;if(!t.length)throw new Error("备份文件里没有账本");if(!t.every(Nt))throw new Error("备份文件里的账本信息不完整");if(!e.transactions.every(Ut))throw new Error("备份文件里有读不懂的记录");const n=Array.isArray(e.categories)?e.categories.filter(Bt):[],a=n.length?n:Rt(),s=e.meta?.currentLedgerId,r=t.some(i=>i.id===s)?s:t[0].id,o={...l.meta};return delete o.currentLedgerId,await h.clearAll(),await h.putMany("ledgers",t),await h.putMany("categories",a),await h.putMany("transactions",e.transactions),await h.put("meta",{key:"currentLedgerId",value:r}),await h.putMany("meta",Object.entries(o).map(([i,c])=>({key:i,value:c}))),await _t(),ge(),e.transactions.length}function Rt(){return Xe.map((e,t)=>({id:V(),kind:e.kind,name:e.name,emoji:e.emoji,order:t}))}function Nt(e){return e&&typeof e.id=="string"&&typeof e.name=="string"}function Bt(e){return e&&typeof e.id=="string"&&typeof e.name=="string"&&(e.kind==="expense"||e.kind==="income")}function Ut(e){return e&&typeof e.id=="string"&&typeof e.date=="string"&&Number.isFinite(e.amountFen)}async function _t(){l.loaded=!1,await Ae()}const Se=new Set;let Ie="record";function Te(){return Ie}function Ht(e){return Se.add(e),()=>Se.delete(e)}function qe(e){e!==Ie&&(Ie=e,Se.forEach(t=>t(e)))}function y(e,{ms:t=2e3,actionLabel:n="",onAction:a=null}={}){const s=document.getElementById("toastRoot");if(!s)return{dismiss(){}};const r=document.createElement("div");r.className="toast";const o=document.createElement("span");o.textContent=e,r.appendChild(o);let i=null;const c=()=>{clearTimeout(i),r.style.transition="opacity .25s",r.style.opacity="0",setTimeout(()=>r.remove(),260)};if(n){const d=document.createElement("button");d.type="button",d.className="toast-action",d.textContent=n,d.addEventListener("click",()=>{c(),a?.()}),r.appendChild(d)}return s.appendChild(r),i=setTimeout(c,t),{dismiss:c}}function O({title:e="",body:t="",actions:n=[]}={}){const a=document.getElementById("sheetRoot"),s=document.createElement("div");s.className="sheet-mask",s.innerHTML=`
    <div class="sheet" role="dialog" aria-modal="true">
      <div class="sheet-grip"></div>
      ${e?`<h3>${u(e)}</h3>`:""}
      <div class="sheet-body"></div>
      ${n.length?'<div class="sheet-actions"></div>':""}
    </div>`;const r=s.querySelector(".sheet-body");typeof t=="string"?r.innerHTML=t:r.appendChild(t);const o={el:s,body:r,close(){s.style.animation="fade .15s reverse",setTimeout(()=>s.remove(),140)}};if(n.length){const i=s.querySelector(".sheet-actions");n.forEach(c=>{const d=document.createElement("button");d.type="button",d.className=`btn ${c.className||""}`,d.textContent=c.label,c.disabled&&(d.disabled=!0),d.addEventListener("click",()=>c.onClick?.(o)),i.appendChild(d)})}return s.addEventListener("click",i=>{i.target===s&&o.close()}),a.appendChild(s),o}function z({title:e="确认",message:t="",okText:n="确定",cancelText:a="取消",danger:s=!1,onOk:r}={}){return new Promise(o=>{const i=document.getElementById("dialogRoot"),c=document.createElement("div");c.className="dialog-mask",c.innerHTML=`
      <div class="dialog" role="alertdialog" aria-modal="true">
        <h3>${u(e)}</h3>
        <p>${u(t)}</p>
        <div class="dialog-actions">
          <button type="button" class="btn btn-outline" data-act="cancel">${u(a)}</button>
          <button type="button" class="btn ${s?"btn-danger":"btn-primary"}" data-act="ok">${u(n)}</button>
        </div>
      </div>`;const d=p=>{c.remove(),o(p)};c.querySelector('[data-act="cancel"]').addEventListener("click",()=>d(!1)),c.querySelector('[data-act="ok"]').addEventListener("click",()=>{r?.(),d(!0)}),c.addEventListener("click",p=>{p.target===c&&d(!1)}),i.appendChild(c)})}function $e({title:e="提示",message:t=""}={}){return new Promise(n=>{const a=document.getElementById("dialogRoot"),s=document.createElement("div");s.className="dialog-mask",s.innerHTML=`
      <div class="dialog" role="alertdialog" aria-modal="true">
        <h3>${u(e)}</h3>
        <p>${u(t)}</p>
        <div class="dialog-actions">
          <button type="button" class="btn btn-primary" data-act="ok">知道了</button>
        </div>
      </div>`;const r=()=>{s.remove(),n()};s.querySelector('[data-act="ok"]').addEventListener("click",r),s.addEventListener("click",o=>{o.target===s&&r()}),a.appendChild(s)})}function Wt(e){let t=String(e).replace(/[^\d.]/g,"");const n=t.indexOf(".");if(n!==-1){t=t.slice(0,n+1)+t.slice(n+1).replace(/\./g,"");const[a,s=""]=t.split(".");t=`${a}.${s.slice(0,2)}`}return t}function et(e,t={}){const n=!!t.tx,a=n?{kind:t.tx.kind,amount:(t.tx.amountFen/100).toFixed(2).replace(/\.00$/,""),categoryId:t.tx.categoryId,date:t.tx.date,note:t.tx.note||""}:{kind:"expense",amount:"",categoryId:"",date:Z(),note:""};e.innerHTML=`
    <div class="seg" data-role="seg">
      <button type="button" data-kind="expense">支出</button>
      <button type="button" data-kind="income">收入</button>
    </div>

    <div class="amount-box">
      <div class="amount-label">金额</div>
      <div class="amount-row">
        <span class="amount-cur">¥</span>
        <input id="amountInput" type="text" inputmode="decimal" placeholder="0.00"
               autocomplete="off" enterkeyhint="done" />
      </div>
      <div class="amount-hint" data-role="hint"></div>
    </div>

    <div class="card">
      <p class="card-title">分类</p>
      <div class="cat-grid" data-role="cats"></div>
    </div>

    <div class="card">
      <div class="field-grid">
        <div class="field">
          <span class="field-label">日期</span>
          <input type="date" data-role="date" />
        </div>
        <div class="quick-dates" data-role="quickdates">
          <button type="button" class="chip" data-off="0">今天</button>
          <button type="button" class="chip" data-off="1">昨天</button>
          <button type="button" class="chip" data-off="2">前天</button>
        </div>
        <div class="field">
          <span class="field-label">备注</span>
          <input type="text" data-role="note" maxlength="60" placeholder="选填，例如：和同事聚餐" />
        </div>
      </div>
    </div>

    <button type="button" class="btn btn-primary btn-block" data-role="save">${u(t.submitLabel||(n?"保存修改":"保存这笔"))}</button>
  `;const s=e.querySelector("#amountInput"),r=e.querySelector('[data-role="hint"]'),o=e.querySelector('[data-role="cats"]'),i=e.querySelector('[data-role="date"]'),c=e.querySelector('[data-role="note"]'),d=e.querySelector('[data-role="save"]'),p=e.querySelector('[data-role="quickdates"]');s.value=a.amount,i.value=a.date,c.value=a.note;function g(){e.querySelectorAll('[data-role="seg"] button').forEach(m=>{m.classList.toggle("active",m.dataset.kind===a.kind)})}function f(){const m=ee(a.kind);if(!m.length){o.innerHTML='<div class="muted">这个类型下还没有分类，去「设置 → 分类管理」加一个</div>';return}m.some($=>$.id===a.categoryId)||(a.categoryId=m[0].id),o.innerHTML=m.map($=>`<button type="button" class="cat-item ${$.id===a.categoryId?"active":""}" data-cat="${$.id}">
          <span class="cat-emoji">${u($.emoji)}</span>
          <span class="cat-name">${u($.name)}</span>
        </button>`).join("")}function b(){p.querySelectorAll("[data-off]").forEach(m=>{m.classList.toggle("active",Ue(Number(m.dataset.off))===a.date)})}function S(){const m=je(a.amount);return a.amount.trim()===""?(r.className="amount-hint",r.textContent="",null):m===null?(r.className="amount-hint error",r.textContent="金额只能填数字，最多两位小数",null):m<=0?(r.className="amount-hint error",r.textContent="金额要大于 0",null):(r.className="amount-hint",r.textContent=`合计 ${w(m)} 元`,m)}return s.addEventListener("input",()=>{const m=Wt(s.value);if(m!==s.value){const $=s.selectionStart??m.length;s.value=m;const x=Math.max(0,Math.min(m.length,$-1));s.setSelectionRange(x,x)}a.amount=m,S()}),s.addEventListener("keydown",m=>{m.key==="Enter"&&(m.preventDefault(),d.click())}),e.querySelectorAll('[data-role="seg"] button').forEach(m=>{m.addEventListener("click",()=>{a.kind=m.dataset.kind,a.categoryId="",g(),f()})}),o.addEventListener("click",m=>{const $=m.target.closest("[data-cat]");$&&(a.categoryId=$.dataset.cat,f())}),i.addEventListener("change",()=>{a.date=i.value||Z(),b()}),p.addEventListener("click",m=>{const $=m.target.closest("[data-off]");$&&(a.date=Ue(Number($.dataset.off)),i.value=a.date,b())}),c.addEventListener("input",()=>{a.note=c.value}),d.addEventListener("click",async()=>{const m=S();if(m===null){a.amount.trim()===""&&y("先填金额"),s.focus();return}if(!a.categoryId){y("先选一个分类");return}d.disabled=!0;try{n?(await It(t.tx.id,{kind:a.kind,amountFen:m,categoryId:a.categoryId,date:a.date,note:a.note.trim()}),y("已保存修改")):(await Ze({ledgerId:j().id,kind:a.kind,amountFen:m,categoryId:a.categoryId,date:a.date,note:a.note.trim()}),y(`记下了 ${w(m)} 元`)),d.disabled=!1,t.onSaved?.({...a,amountFen:m})}catch($){d.disabled=!1,y("保存失败："+$.message)}}),g(),f(),b(),S(),n&&setTimeout(()=>{s.focus(),s.select()},150),{draft:a,reset(){a.amount="",a.note="",a.date=Z(),a.categoryId="",s.value="",c.value="",i.value=a.date,f(),b(),S()}}}const tt=864e5,Yt=30,Gt=7;function nt(e){const t=j(),n=te(C()),a=t.budgetFen||0;e.innerHTML=`
    ${Kt()}
    ${a>0?zt(n.expenseFen,a):""}
    <div data-role="form"></div>
  `,Vt(e),et(e.querySelector('[data-role="form"]'),{onSaved:()=>{nt(e)}})}function Kt(){const e=l.meta.lastBackupAt||0,t=l.meta.backupReminderMutedUntil||0;if(Date.now()<t||!l.transactions.length)return"";const n=l.transactions.reduce((o,i)=>Math.min(o,i.createdAt||Date.now()),Date.now());if(Date.now()-(e||n)<Yt*tt)return"";const s=e?Je(new Date(e).toISOString().slice(0,10),new Date().toISOString().slice(0,10)):null,r=e?`上次备份是 ${s} 天前了。数据只在这台手机里，建议导出一份存到网盘。`:"还没有备份过。数据只在这台手机里，系统云备份也是关的 —— 卸载或者丢手机就全没了。建议导出一份存到网盘。";return`<div class="reminder" data-role="reminder">
    <span class="rem-main">${u(r)}</span>
    <button type="button" class="rem-close" data-act="reminder-close" aria-label="暂时不提醒">×</button>
  </div>`}function Vt(e){const t=e.querySelector('[data-role="reminder"]');t&&(t.querySelector('[data-act="reminder-close"]').addEventListener("click",async()=>{await X("backupReminderMutedUntil",Date.now()+Gt*tt),t.remove()}),t.querySelector(".rem-main").addEventListener("click",()=>qe("settings")))}function zt(e,t){const n=e/t,a=n>=1?"over":n>=.8?"warn":"",s=t-e,r=n>=1?`已经超支 ${w(-s)} 元`:`还能花 ${w(s)} 元`;return`<div class="card">
    <p class="card-title">本月预算</p>
    <div class="budget-line">
      <span>已花 ${u(w(e))} 元</span>
      <span>预算 ${u(w(t))} 元</span>
    </div>
    <div class="progress ${a}"><i style="width:${Math.min(n*100,100).toFixed(1)}%"></i></div>
    <div class="budget-tip ${a}">${u(r)}（已用 ${(n*100).toFixed(0)}%）</div>
  </div>`}const v={month:C(),categoryId:"",keyword:"",scope:"month"};function Oe(){v.month=C(),v.categoryId="",v.keyword="",v.scope="month"}function M(e){v.month>C()&&(v.month=C());const t=j(),n=Ft(v.month,t.id,{categoryId:v.categoryId,keyword:v.keyword,scope:v.scope}),a=!!(v.categoryId||v.keyword.trim()),s=v.scope==="all",r=bt(n),o=v.month<=Mt(t.id),i=v.month>=C();e.innerHTML=`
    <div class="scope" data-role="scope">
      <button type="button" data-scope="month" class="${s?"":"active"}">按月</button>
      <button type="button" data-scope="all" class="${s?"active":""}">全部时间</button>
    </div>

    ${s?"":`<div class="month-nav">
      <button type="button" class="m-arrow" data-role="prev" ${o?"disabled":""}>‹</button>
      <span class="m-label">${u(ue(v.month))}${a?` · 筛选出 ${n.length} 笔`:""}</span>
      <button type="button" class="m-arrow" data-role="next" ${i?"disabled":""}>›</button>
    </div>`}

    <div class="summary">
      <div><div class="s-val income">${u(w(r.incomeFen))}</div><div class="s-key">收入</div></div>
      <div><div class="s-val expense">${u(w(r.expenseFen))}</div><div class="s-key">支出</div></div>
      <div><div class="s-val balance">${u(w(r.balanceFen))}</div><div class="s-key">结余</div></div>
    </div>

    ${s?`<p class="muted" style="margin:-4px 0 12px 2px">全部时间里${a?"筛选出":"共"} ${n.length} 笔</p>`:""}

    <div class="filters">
      <select data-role="cat">
        <option value="">全部分类</option>
        ${ee("expense").map(f=>`<option value="${f.id}" ${v.categoryId===f.id?"selected":""}>支出 · ${u(f.name)}</option>`).join("")}
        ${ee("income").map(f=>`<option value="${f.id}" ${v.categoryId===f.id?"selected":""}>收入 · ${u(f.name)}</option>`).join("")}
      </select>
      <input type="search" data-role="kw" placeholder="搜备注或分类" value="${u(v.keyword)}" />
    </div>

    <div data-role="list"></div>
  `;const c=e.querySelector('[data-role="list"]');c.innerHTML=n.length?Jt(n,s):Xt(a,s),e.querySelector('[data-role="scope"]').addEventListener("click",f=>{const b=f.target.closest("[data-scope]");!b||b.dataset.scope===v.scope||(v.scope=b.dataset.scope,M(e))});const d=e.querySelector('[data-role="prev"]');d&&(d.addEventListener("click",()=>{v.month=K(v.month,-1),M(e)}),e.querySelector('[data-role="next"]').addEventListener("click",()=>{v.month=K(v.month,1),M(e)})),e.querySelector('[data-role="cat"]').addEventListener("change",f=>{v.categoryId=f.target.value,M(e)});const p=e.querySelector('[data-role="kw"]');let g=null;p.addEventListener("input",()=>{clearTimeout(g),g=setTimeout(()=>{v.keyword=p.value,M(e);const f=document.querySelector('[data-role="kw"]');f&&(f.focus(),f.setSelectionRange(f.value.length,f.value.length))},260)}),c.addEventListener("click",f=>{const b=f.target.closest("[data-tx]");b&&Qt(b.dataset.tx,e)})}function Jt(e,t){const n=new Map;for(const s of e)n.has(s.date)||n.set(s.date,[]),n.get(s.date).push(s);const a=String(new Date().getFullYear());return[...n.entries()].map(([s,r])=>{const o=me(r.filter(g=>g.kind==="income"),g=>g.amountFen),i=me(r.filter(g=>g.kind==="expense"),g=>g.amountFen),c=[];o&&c.push(`收 ${w(o)}`),i&&c.push(`支 ${w(i)}`);const d=s.slice(0,4),p=t&&d!==a?`${d}年${_e(s)}`:_e(s);return`<div class="day-group">
        <div class="day-head">
          <span>${u(p)}</span>
          <span class="d-sub">${u(c.join("　"))}</span>
        </div>
        <div class="tx-list">
          ${r.map(g=>{const f=_(g.categoryId);return`<div class="tx" data-tx="${g.id}">
                <span class="tx-emoji">${u(f?.emoji??"❓")}</span>
                <span class="tx-main">
                  <div class="tx-cat">${u(f?.name??"未分类")}</div>
                  ${g.note?`<div class="tx-note">${u(g.note)}</div>`:""}
                </span>
                <span class="tx-amt ${g.kind}">${g.kind==="expense"?"-":"+"}${u(w(g.amountFen))}</span>
              </div>`}).join("")}
        </div>
      </div>`}).join("")}function Xt(e,t){return`<div class="empty">
    <span class="empty-ico">${e?"🔍":"🗒️"}</span>
    ${e?"没有符合条件的记录":t?"还没有任何记录":"这个月还没有记账"}
  </div>`}function Qt(e,t){const n=l.transactions.find(r=>r.id===e);if(!n)return;const a=_(n.categoryId),s=O({title:"这笔记录",body:`
      <div class="set-list">
        <div class="set-row" style="cursor:default">
          <span class="sr-ico">${u(a?.emoji??"❓")}</span>
          <span class="sr-main">
            <div style="font-size:16px;font-weight:600">${u(w(n.amountFen))} 元</div>
            <div class="sr-sub">${u(a?.name??"未分类")} · ${u(n.date)}${n.note?" · "+u(n.note):""}</div>
          </span>
        </div>
        <button type="button" class="set-row" data-act="edit"><span class="sr-ico">✏️</span><span class="sr-main">修改</span></button>
        <button type="button" class="set-row" data-act="dup"><span class="sr-ico">📋</span><span class="sr-main">再记一笔一样的<span class="sr-sub">复制到今天</span></span></button>
        <button type="button" class="set-row" data-act="del"><span class="sr-ico">🗑️</span><span class="sr-main" style="color:var(--danger)">删除</span></button>
      </div>`,actions:[{label:"取消",className:"btn-outline",onClick:r=>r.close()}]});s.body.addEventListener("click",async r=>{const o=r.target.closest("[data-act]");if(!o)return;const i=o.dataset.act;if(s.close(),i==="edit")return en(n,t);if(i==="del"){if(!await z({title:"删除这笔记录？",message:`${n.date}　${a?.name??"未分类"}　${w(n.amountFen)} 元
删掉之后可以马上点提示里的「撤销」找回。`,okText:"删除",danger:!0}))return;const d=await Pt(n.id);M(t),y("已删除 1 笔记录",{ms:6e3,actionLabel:"撤销",onAction:async()=>{await Ct(d),y("已恢复"),M(t)}});return}i==="dup"&&await Zt(n,t)})}async function Zt(e,t){await Ze({ledgerId:j().id,kind:e.kind,amountFen:e.amountFen,categoryId:e.categoryId,date:Z(),note:e.note}),y("已复制到今天"),v.scope!=="all"&&v.month!==C()&&(v.month=C()),M(t)}function en(e,t){const n=O({title:"修改记录",body:'<div data-role="form"></div>'});et(n.body.querySelector('[data-role="form"]'),{tx:e,submitLabel:"保存修改",onSaved:()=>{n.close(),M(t)}})}function tn({month:e,categoryId:t}={}){e&&(v.month=e),t!==void 0&&(v.categoryId=t),e&&(v.scope="month")}const at=320;function nn(e,{size:t=at,thickness:n=48}={}){const a=e.reduce((p,g)=>p+g.amountFen,0);if(!a)return'<div class="empty">还没有支出记录</div>';const s=(t-n)/2,r=t/2,o=t/2;let i=-Math.PI/2;const c=e.map((p,g)=>{const f=p.amountFen/a*Math.PI*2,b=f>=Math.PI*2-1e-6?Ye(r,o,s,n,0,Math.PI*2-1e-4):Ye(r,o,s,n,i,i+f);return i+=f,`<path d="${b}" fill="${We(g)}" />`}),d=e[0];return`<div class="chart-wrap">
    <svg viewBox="0 0 ${t} ${t}" width="${t}" height="${t}" role="img"
         aria-label="分类占比环形图，合计 ${u(w(a))} 元">
      ${c.join("")}
      <text x="${r}" y="${o-8}" text-anchor="middle" font-size="13" fill="var(--text-3)">合计</text>
      <text x="${r}" y="${o+16}" text-anchor="middle" font-size="18" font-weight="600" fill="var(--text)">${u(w(a))}</text>
    </svg>
  </div>
  <div class="legend">
    ${e.slice(0,8).map((p,g)=>`<div class="legend-row">
          <span class="legend-dot" style="background:${We(g)}"></span>
          <span class="legend-name">${u(p.emoji+" "+p.name)}</span>
          <span class="legend-amt">${u(w(p.amountFen))}</span>
          <span class="legend-pct">${(p.pct*100).toFixed(1)}%</span>
        </div>`).join("")}
    ${e.length>8?`<div class="muted">还有 ${e.length-8} 个分类没显示</div>`:""}
  </div>
  <div class="muted" style="margin-top:10px">占比最大：${u(d.name)}，${(d.pct*100).toFixed(1)}%</div>`}function Ye(e,t,n,a,s,r){const o=n+a/2,i=n-a/2,c=r-s>Math.PI?1:0,d=e+o*Math.cos(s),p=t+o*Math.sin(s),g=e+o*Math.cos(r),f=t+o*Math.sin(r),b=e+i*Math.cos(r),S=t+i*Math.sin(r),m=e+i*Math.cos(s),$=t+i*Math.sin(s);return`M ${d} ${p} A ${o} ${o} 0 ${c} 1 ${g} ${f} L ${b} ${S} A ${i} ${i} 0 ${c} 0 ${m} ${$} Z`}function an(e,{height:t=190}={}){const n=at,a=t,s=42,r=8,o=16,i=30,c=n-s-r,d=a-o-i,p=Math.max(...e.map(x=>Math.max(x.incomeFen,x.expenseFen)),1),g=c/e.length,f=Math.min(12,g/3.2),b=o+d,S=e.map((x,B)=>{const D=s+g*B+g/2,H=Math.round(x.incomeFen/p*d),se=Math.round(x.expenseFen/p*d),ve=b-H,k=b-se;return`
        <rect x="${(D-f-2).toFixed(1)}" y="${k}" width="${f}" height="${Math.max(se,x.expenseFen?2:0)}" rx="2.5" fill="var(--expense)" />
        <rect x="${(D+2).toFixed(1)}" y="${ve}" width="${f}" height="${Math.max(H,x.incomeFen?2:0)}" rx="2.5" fill="var(--income)" />
        <text x="${D.toFixed(1)}" y="${a-10}" text-anchor="middle" font-size="13" fill="var(--text-3)">${u(ue(x.month))}</text>`}).join(""),m=[1,.5,0].map(x=>{const B=o+d*(1-x),D=x===0;return`
        <line x1="${s}" y1="${B.toFixed(1)}" x2="${n-r}" y2="${B.toFixed(1)}"
              stroke="var(--border)" stroke-width="${D?1:.5}"
              ${D?"":'stroke-dasharray="3 3"'} />
        <text x="${s-8}" y="${B.toFixed(1)}" text-anchor="end" dominant-baseline="central"
              font-size="12" fill="var(--text-3)">${u(sn(p*x))}</text>`}).join(""),$=e.some(x=>x.incomeFen||x.expenseFen);return`<div class="chart-wrap">
    <svg viewBox="0 0 ${n} ${a}" role="img" aria-label="最近几个月收支趋势柱状图">
      ${m}
      ${S}
    </svg>
  </div>
  <div class="legend-group" style="margin-top:8px">
    <span class="legend-item"><i class="legend-dot" style="background:var(--income)"></i>收入</span>
    <span class="legend-item"><i class="legend-dot" style="background:var(--expense)"></i>支出</span>
  </div>
  ${$?"":'<div class="muted" style="margin-top:8px">这几个月还没有记录</div>'}`}function sn(e){if(!e)return"0";const t=e/100;if(t>=1e4){const n=t/1e4;return`${n>=10?String(Math.round(n)):n.toFixed(1).replace(/\.0$/,"")}万`}return String(Math.round(t))}const L={month:C(),kind:"expense"};function de(e){L.month>C()&&(L.month=C());const t=j(),n=on(L.month,6),a=At(n,t.id),s=te(L.month,t.id),r=te(K(L.month,-1),t.id),o=jt(L.month,L.kind,t.id),i=L.month>=C();e.innerHTML=`
    <div class="month-nav">
      <button type="button" class="m-arrow" data-role="prev">‹</button>
      <span class="m-label">${u(ue(L.month))}</span>
      <button type="button" class="m-arrow" data-role="next" ${i?"disabled":""}>›</button>
    </div>

    <div class="card">
      <p class="card-title">${u(ue(L.month))}总结</p>
      <div class="summary summary-plain">
        <div><div class="s-val income">${u(w(s.incomeFen))}</div><div class="s-key">收入</div></div>
        <div><div class="s-val expense">${u(w(s.expenseFen))}</div><div class="s-key">支出</div></div>
        <div><div class="s-val balance">${u(w(s.balanceFen))}</div><div class="s-key">结余</div></div>
      </div>
      ${rn(s,r)}
      ${s.count?"":'<div class="muted" style="margin-top:10px">这个月还没有记录</div>'}
    </div>

    <div class="card">
      <div class="seg" data-role="kindseg" style="margin-bottom:12px">
        <button type="button" data-kind="expense">支出构成</button>
        <button type="button" data-kind="income">收入构成</button>
      </div>
      <div data-role="pie"></div>
    </div>

    <div class="card">
      <p class="card-title">最近 6 个月趋势</p>
      <div data-role="trend"></div>
    </div>
  `,e.querySelector('[data-role="pie"]').innerHTML=nn(o.items),e.querySelector('[data-role="trend"]').innerHTML=an(a),e.querySelectorAll('[data-role="kindseg"] button').forEach(c=>{c.classList.toggle("active",c.dataset.kind===L.kind),c.addEventListener("click",()=>{L.kind=c.dataset.kind,de(e)})}),e.querySelector('[data-role="prev"]').addEventListener("click",()=>{L.month=K(L.month,-1),de(e)}),e.querySelector('[data-role="next"]').addEventListener("click",()=>{L.month=K(L.month,1),de(e)}),e.querySelectorAll('[data-role="pie"] .legend-row').forEach((c,d)=>{const p=o.items[d];p&&(c.style.cursor="pointer",c.title="点一下看这个分类的明细",c.addEventListener("click",()=>{tn({month:L.month,categoryId:p.categoryId}),qe("list")}))})}function rn(e,t){if(!e.count)return"";if(!t.count)return'<div class="delta">上月没有记录，没法比</div>';const n=e.expenseFen-t.expenseFen;if(n===0)return'<div class="delta">支出和上月持平</div>';const a=Math.round(Math.abs(n/t.expenseFen)*100),s=n>0;return`<div class="delta ${s?"up":"down"}">
    支出比上月${s?"多":"少"}花 <b>${u(w(Math.abs(n)))}</b> 元
    <b>(${s?"+":"-"}${a}%)</b>
  </div>`}function on(e,t){const n=[];for(let a=t-1;a>=0;a-=1)n.push(K(e,-a));return n}const cn="modulepreload",dn=function(e,t){return new URL(e,t).href},Ge={},st=function(t,n,a){let s=Promise.resolve();if(n&&n.length>0){const o=document.getElementsByTagName("link"),i=document.querySelector("meta[property=csp-nonce]"),c=i?.nonce||i?.getAttribute("nonce");s=Promise.allSettled(n.map(d=>{if(d=dn(d,a),d in Ge)return;Ge[d]=!0;const p=d.endsWith(".css"),g=p?'[rel="stylesheet"]':"";if(!!a)for(let S=o.length-1;S>=0;S--){const m=o[S];if(m.href===d&&(!p||m.rel==="stylesheet"))return}else if(document.querySelector(`link[href="${d}"]${g}`))return;const b=document.createElement("link");if(b.rel=p?"stylesheet":cn,p||(b.as="script"),b.crossOrigin="",b.href=d,c&&b.setAttribute("nonce",c),document.head.appendChild(b),p)return new Promise((S,m)=>{b.addEventListener("load",S),b.addEventListener("error",()=>m(new Error(`Unable to preload CSS for ${d}`)))})}))}function r(o){const i=new Event("vite:preloadError",{cancelable:!0});if(i.payload=o,window.dispatchEvent(i),!i.defaultPrevented)throw o}return s.then(o=>{for(const i of o||[])i.status==="rejected"&&r(i.reason);return t().catch(r)})};/*! Capacitor: https://capacitorjs.com/ - MIT License */const ln=e=>{const t=new Map;t.set("web",{name:"web"});const n=e.CapacitorPlatforms||{currentPlatform:{name:"web"},platforms:t},a=(r,o)=>{n.platforms.set(r,o)},s=r=>{n.platforms.has(r)&&(n.currentPlatform=n.platforms.get(r))};return n.addPlatform=a,n.setPlatform=s,n},un=e=>e.CapacitorPlatforms=ln(e),rt=un(typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});rt.addPlatform;rt.setPlatform;var J;(function(e){e.Unimplemented="UNIMPLEMENTED",e.Unavailable="UNAVAILABLE"})(J||(J={}));class ke extends Error{constructor(t,n,a){super(t),this.message=t,this.code=n,this.data=a}}const mn=e=>{var t,n;return e?.androidBridge?"android":!((n=(t=e?.webkit)===null||t===void 0?void 0:t.messageHandlers)===null||n===void 0)&&n.bridge?"ios":"web"},pn=e=>{var t,n,a,s,r;const o=e.CapacitorCustomPlatform||null,i=e.Capacitor||{},c=i.Plugins=i.Plugins||{},d=e.CapacitorPlatforms,p=()=>o!==null?o.name:mn(e),g=((t=d?.currentPlatform)===null||t===void 0?void 0:t.getPlatform)||p,f=()=>g()!=="web",b=((n=d?.currentPlatform)===null||n===void 0?void 0:n.isNativePlatform)||f,S=k=>{const E=H.get(k);return!!(E?.platforms.has(g())||x(k))},m=((a=d?.currentPlatform)===null||a===void 0?void 0:a.isPluginAvailable)||S,$=k=>{var E;return(E=i.PluginHeaders)===null||E===void 0?void 0:E.find(W=>W.name===k)},x=((s=d?.currentPlatform)===null||s===void 0?void 0:s.getPluginHeader)||$,B=k=>e.console.error(k),D=(k,E,W)=>Promise.reject(`${W} does not have an implementation of "${E}".`),H=new Map,se=(k,E={})=>{const W=H.get(k);if(W)return console.warn(`Capacitor plugin "${k}" already registered. Cannot register plugins twice.`),W.proxy;const U=g(),Y=x(k);let T;const mt=async()=>(!T&&U in E?T=typeof E[U]=="function"?T=await E[U]():T=E[U]:o!==null&&!T&&"web"in E&&(T=typeof E.web=="function"?T=await E.web():T=E.web),T),pt=(I,P)=>{var A,R;if(Y){const N=Y?.methods.find(F=>P===F.name);if(N)return N.rtype==="promise"?F=>i.nativePromise(k,P.toString(),F):(F,re)=>i.nativeCallback(k,P.toString(),F,re);if(I)return(A=I[P])===null||A===void 0?void 0:A.bind(I)}else{if(I)return(R=I[P])===null||R===void 0?void 0:R.bind(I);throw new ke(`"${k}" plugin is not implemented on ${U}`,J.Unimplemented)}},ye=I=>{let P;const A=(...R)=>{const N=mt().then(F=>{const re=pt(F,I);if(re){const oe=re(...R);return P=oe?.remove,oe}else throw new ke(`"${k}.${I}()" is not implemented on ${U}`,J.Unimplemented)});return I==="addListener"&&(N.remove=async()=>P()),N};return A.toString=()=>`${I.toString()}() { [capacitor code] }`,Object.defineProperty(A,"name",{value:I,writable:!1,configurable:!1}),A},Re=ye("addListener"),Ne=ye("removeListener"),gt=(I,P)=>{const A=Re({eventName:I},P),R=async()=>{const F=await A;Ne({eventName:I,callbackId:F},P)},N=new Promise(F=>A.then(()=>F({remove:R})));return N.remove=async()=>{console.warn("Using addListener() without 'await' is deprecated."),await R()},N},be=new Proxy({},{get(I,P){switch(P){case"$$typeof":return;case"toJSON":return()=>({});case"addListener":return Y?gt:Re;case"removeListener":return Ne;default:return ye(P)}}});return c[k]=be,H.set(k,{name:k,proxy:be,platforms:new Set([...Object.keys(E),...Y?[U]:[]])}),be},ve=((r=d?.currentPlatform)===null||r===void 0?void 0:r.registerPlugin)||se;return i.convertFileSrc||(i.convertFileSrc=k=>k),i.getPlatform=g,i.handleError=B,i.isNativePlatform=b,i.isPluginAvailable=m,i.pluginMethodNoop=D,i.registerPlugin=ve,i.Exception=ke,i.DEBUG=!!i.DEBUG,i.isLoggingEnabled=!!i.isLoggingEnabled,i.platform=i.getPlatform(),i.isNative=i.isNativePlatform(),i},gn=e=>e.Capacitor=pn(e),pe=gn(typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{}),fe=pe.registerPlugin;pe.Plugins;class ot{constructor(t){this.listeners={},this.retainedEventArguments={},this.windowListeners={},t&&(console.warn(`Capacitor WebPlugin "${t.name}" config object was deprecated in v3 and will be removed in v4.`),this.config=t)}addListener(t,n){let a=!1;this.listeners[t]||(this.listeners[t]=[],a=!0),this.listeners[t].push(n);const r=this.windowListeners[t];r&&!r.registered&&this.addWindowListener(r),a&&this.sendRetainedArgumentsForEvent(t);const o=async()=>this.removeListener(t,n);return Promise.resolve({remove:o})}async removeAllListeners(){this.listeners={};for(const t in this.windowListeners)this.removeWindowListener(this.windowListeners[t]);this.windowListeners={}}notifyListeners(t,n,a){const s=this.listeners[t];if(!s){if(a){let r=this.retainedEventArguments[t];r||(r=[]),r.push(n),this.retainedEventArguments[t]=r}return}s.forEach(r=>r(n))}hasListeners(t){return!!this.listeners[t].length}registerWindowListener(t,n){this.windowListeners[n]={registered:!1,windowEventName:t,pluginEventName:n,handler:a=>{this.notifyListeners(n,a)}}}unimplemented(t="not implemented"){return new pe.Exception(t,J.Unimplemented)}unavailable(t="not available"){return new pe.Exception(t,J.Unavailable)}async removeListener(t,n){const a=this.listeners[t];if(!a)return;const s=a.indexOf(n);this.listeners[t].splice(s,1),this.listeners[t].length||this.removeWindowListener(this.windowListeners[t])}addWindowListener(t){window.addEventListener(t.windowEventName,t.handler),t.registered=!0}removeWindowListener(t){t&&(window.removeEventListener(t.windowEventName,t.handler),t.registered=!1)}sendRetainedArgumentsForEvent(t){const n=this.retainedEventArguments[t];n&&(delete this.retainedEventArguments[t],n.forEach(a=>{this.notifyListeners(t,a)}))}}const Ke=e=>encodeURIComponent(e).replace(/%(2[346B]|5E|60|7C)/g,decodeURIComponent).replace(/[()]/g,escape),Ve=e=>e.replace(/(%[\dA-F]{2})+/gi,decodeURIComponent);class fn extends ot{async getCookies(){const t=document.cookie,n={};return t.split(";").forEach(a=>{if(a.length<=0)return;let[s,r]=a.replace(/=/,"CAP_COOKIE").split("CAP_COOKIE");s=Ve(s).trim(),r=Ve(r).trim(),n[s]=r}),n}async setCookie(t){try{const n=Ke(t.key),a=Ke(t.value),s=`; expires=${(t.expires||"").replace("expires=","")}`,r=(t.path||"/").replace("path=",""),o=t.url!=null&&t.url.length>0?`domain=${t.url}`:"";document.cookie=`${n}=${a||""}${s}; path=${r}; ${o};`}catch(n){return Promise.reject(n)}}async deleteCookie(t){try{document.cookie=`${t.key}=; Max-Age=0`}catch(n){return Promise.reject(n)}}async clearCookies(){try{const t=document.cookie.split(";")||[];for(const n of t)document.cookie=n.replace(/^ +/,"").replace(/=.*/,`=;expires=${new Date().toUTCString()};path=/`)}catch(t){return Promise.reject(t)}}async clearAllCookies(){try{await this.clearCookies()}catch(t){return Promise.reject(t)}}}fe("CapacitorCookies",{web:()=>new fn});const vn=async e=>new Promise((t,n)=>{const a=new FileReader;a.onload=()=>{const s=a.result;t(s.indexOf(",")>=0?s.split(",")[1]:s)},a.onerror=s=>n(s),a.readAsDataURL(e)}),yn=(e={})=>{const t=Object.keys(e);return Object.keys(e).map(s=>s.toLocaleLowerCase()).reduce((s,r,o)=>(s[r]=e[t[o]],s),{})},bn=(e,t=!0)=>e?Object.entries(e).reduce((a,s)=>{const[r,o]=s;let i,c;return Array.isArray(o)?(c="",o.forEach(d=>{i=t?encodeURIComponent(d):d,c+=`${r}=${i}&`}),c.slice(0,-1)):(i=t?encodeURIComponent(o):o,c=`${r}=${i}`),`${a}&${c}`},"").substr(1):null,hn=(e,t={})=>{const n=Object.assign({method:e.method||"GET",headers:e.headers},t),s=yn(e.headers)["content-type"]||"";if(typeof e.data=="string")n.body=e.data;else if(s.includes("application/x-www-form-urlencoded")){const r=new URLSearchParams;for(const[o,i]of Object.entries(e.data||{}))r.set(o,i);n.body=r.toString()}else if(s.includes("multipart/form-data")||e.data instanceof FormData){const r=new FormData;if(e.data instanceof FormData)e.data.forEach((i,c)=>{r.append(c,i)});else for(const i of Object.keys(e.data))r.append(i,e.data[i]);n.body=r;const o=new Headers(n.headers);o.delete("content-type"),n.headers=o}else(s.includes("application/json")||typeof e.data=="object")&&(n.body=JSON.stringify(e.data));return n};class wn extends ot{async request(t){const n=hn(t,t.webFetchExtra),a=bn(t.params,t.shouldEncodeUrlParams),s=a?`${t.url}?${a}`:t.url,r=await fetch(s,n),o=r.headers.get("content-type")||"";let{responseType:i="text"}=r.ok?t:{};o.includes("application/json")&&(i="json");let c,d;switch(i){case"arraybuffer":case"blob":d=await r.blob(),c=await vn(d);break;case"json":c=await r.json();break;case"document":case"text":default:c=await r.text()}const p={};return r.headers.forEach((g,f)=>{p[f]=g}),{data:c,headers:p,status:r.status,url:r.url}}async get(t){return this.request(Object.assign(Object.assign({},t),{method:"GET"}))}async post(t){return this.request(Object.assign(Object.assign({},t),{method:"POST"}))}async put(t){return this.request(Object.assign(Object.assign({},t),{method:"PUT"}))}async patch(t){return this.request(Object.assign(Object.assign({},t),{method:"PATCH"}))}async delete(t){return this.request(Object.assign(Object.assign({},t),{method:"DELETE"}))}}fe("CapacitorHttp",{web:()=>new wn});var Pe;(function(e){e.Documents="DOCUMENTS",e.Data="DATA",e.Library="LIBRARY",e.Cache="CACHE",e.External="EXTERNAL",e.ExternalStorage="EXTERNAL_STORAGE"})(Pe||(Pe={}));var Ce;(function(e){e.UTF8="utf8",e.ASCII="ascii",e.UTF16="utf16"})(Ce||(Ce={}));const $n=fe("Filesystem",{web:()=>st(()=>import("./web-LrEP1tkg.js"),[],import.meta.url).then(e=>new e.FilesystemWeb)}),kn=fe("Share",{web:()=>st(()=>import("./web-BmOAOrN3.js"),[],import.meta.url).then(e=>new e.ShareWeb)});function xn(){return!!window.Capacitor?.isNativePlatform?.()}async function it(e,t,n="text/plain"){if(xn()){const o=await $n.writeFile({path:e,data:t,directory:Pe.Cache,encoding:Ce.UTF8});try{return await kn.share({title:e,text:e,url:o.uri,dialogTitle:"保存或发送这个文件"}),{mode:"share"}}catch(i){return{mode:"share-failed",uri:o.uri,message:i?.message||""}}}const a=new Blob([t],{type:`${n};charset=utf-8`}),s=URL.createObjectURL(a),r=document.createElement("a");return r.href=s,r.download=e,document.body.appendChild(r),r.click(),r.remove(),setTimeout(()=>URL.revokeObjectURL(s),1e3),{mode:"download"}}function En(e=".json,application/json"){return new Promise(t=>{const n=document.createElement("input");n.type="file",n.accept=e,n.style.display="none";let a=!1;const s=r=>{a||(a=!0,n.remove(),t(r))};n.addEventListener("change",()=>{const r=n.files?.[0];if(!r)return s(null);const o=new FileReader;o.onload=()=>s(String(o.result)),o.onerror=()=>s(null),o.readAsText(r,"utf-8")}),window.addEventListener("focus",()=>setTimeout(()=>{n.files?.length||s(null)},800),{once:!0}),document.body.appendChild(n),n.click()})}function ct(){const e=new Date,t=n=>String(n).padStart(2,"0");return`${e.getFullYear()}${t(e.getMonth()+1)}${t(e.getDate())}-${t(e.getHours())}${t(e.getMinutes())}`}const Ln=["🍚","🍜","🍔","🍰","☕","🍺","🚌","🚇","🚕","⛽","🛒","👕","💄","🏠","💡","📱","🎮","🎬","✈️","🏨","💊","🏥","📚","✏️","🎓","🎁","💵","💰","💼","📈","🐱","👶","🔧","🚿","🛁","🏋️","🎵","📷","🌸","📦","💳","🏦","💎","🎯","📄","💉","🍎","🚗","🛵","🎨"];function q(e){const t=document.createElement("div");e.replaceChildren(t);const n=j(),a=te(C(),n.id),s=n.budgetFen||0,r=l.meta.lastBackupAt||0;t.innerHTML=`
    <div class="set-group">
      <h2>账本</h2>
      <div class="set-list">
        <button type="button" class="set-row" data-act="ledgers">
          <span class="sr-ico">📒</span>
          <span class="sr-main">${u(n.name)}<span class="sr-sub">共 ${l.ledgers.length} 个账本，点这里切换</span></span>
          <span class="sr-arrow">›</span>
        </button>
        <button type="button" class="set-row" data-act="budget">
          <span class="sr-ico">🎯</span>
          <span class="sr-main">本月预算<span class="sr-sub">本月已花 ${u(w(a.expenseFen))} 元</span></span>
          <span class="sr-val">${s?u(w(s))+" 元":"未设置"}</span>
          <span class="sr-arrow">›</span>
        </button>
        <button type="button" class="set-row" data-act="rename">
          <span class="sr-ico">✏️</span>
          <span class="sr-main">重命名当前账本</span>
          <span class="sr-arrow">›</span>
        </button>
        <button type="button" class="set-row" data-act="newledger">
          <span class="sr-ico">➕</span>
          <span class="sr-main">新建账本<span class="sr-sub">比如「装修」「旅行」，数据各算各的</span></span>
          <span class="sr-arrow">›</span>
        </button>
      </div>
    </div>

    <div class="set-group">
      <h2>分类</h2>
      <div class="set-list">
        <button type="button" class="set-row" data-act="cats">
          <span class="sr-ico">🏷️</span>
          <span class="sr-main">分类管理<span class="sr-sub">新增、改名、换图标、调顺序、删除</span></span>
          <span class="sr-val">${l.categories.length} 个</span>
          <span class="sr-arrow">›</span>
        </button>
      </div>
    </div>

    <div class="set-group">
      <h2>数据</h2>
      <div class="set-list">
        <button type="button" class="set-row" data-act="csv">
          <span class="sr-ico">📊</span>
          <span class="sr-main">导出当前账本为 CSV<span class="sr-sub">Excel / WPS 能直接打开</span></span>
          <span class="sr-arrow">›</span>
        </button>
        <button type="button" class="set-row" data-act="backup">
          <span class="sr-ico">💾</span>
          <span class="sr-main">导出完整备份<span class="sr-sub">所有账本、分类、预算，一个文件全带走</span></span>
          <span class="sr-val">${u(Sn(r))}</span>
          <span class="sr-arrow">›</span>
        </button>
        <button type="button" class="set-row" data-act="restore">
          <span class="sr-ico">📥</span>
          <span class="sr-main">从备份恢复<span class="sr-sub" style="color:var(--danger)">会覆盖现在的全部数据</span></span>
          <span class="sr-arrow">›</span>
        </button>
        <button type="button" class="set-row" data-act="wipe">
          <span class="sr-ico">🗑️</span>
          <span class="sr-main" style="color:var(--danger)">清空所有数据</span>
          <span class="sr-arrow">›</span>
        </button>
      </div>
      <p class="muted" style="margin:10px 6px 0">
        数据全部存在这台手机里，不联网、不上传。换手机或者怕丢，记得定期「导出完整备份」，把文件存到网盘或发给自己。
      </p>
    </div>

    <div class="set-group">
      <h2>关于</h2>
      <div class="set-list">
        <div class="set-row" style="cursor:default">
          <span class="sr-ico">ℹ️</span>
          <span class="sr-main">记账本<span class="sr-sub">本地版 v1.0 · 记录 ${l.transactions.length} 笔</span></span>
        </div>
      </div>
    </div>
  `,t.addEventListener("click",async o=>{const i=o.target.closest("[data-act]");if(!i)return;const c=i.dataset.act,d=()=>q(e);if(c==="ledgers")return In(e);if(c==="budget")return Fn(e);if(c==="rename")return Cn(e);if(c==="newledger")return Pn(e);if(c==="cats")return jn(e);if(c==="csv")return An();if(c==="backup")return Mn(d);if(c==="restore")return Tn(d);if(c==="wipe")return qn(d)})}function Sn(e){if(!e)return"还没有备份";const t=Je(le(new Date(e)),le(new Date));return t<=0?"今天刚备份":t===1?"昨天备份":`${t} 天前备份`}function In(e){const t=l.ledgers.map(a=>`<button type="button" class="set-row" data-id="${a.id}">
        <span class="sr-ico">${a.id===l.meta.currentLedgerId?"✅":"📒"}</span>
        <span class="sr-main">${u(a.name)}
          <span class="sr-sub">${l.transactions.filter(s=>s.ledgerId===a.id).length} 笔${a.budgetFen?" · 预算 "+u(w(a.budgetFen)):""}</span>
        </span>
        ${l.ledgers.length>1?`<span class="sr-val" data-del="${a.id}">删除</span>`:""}
      </button>`).join(""),n=O({title:"选择账本",body:`<div class="set-list">${t}</div>
      <p class="muted" style="margin-top:12px">每个账本的记录和统计互相独立，切换后首页、账单、统计都会跟着变。</p>`});n.body.addEventListener("click",async a=>{const s=a.target.closest("[data-del]");if(s){a.stopPropagation();const o=l.ledgers.find(d=>d.id===s.dataset.del),i=l.transactions.filter(d=>d.ledgerId===o.id).length;if(!await z({title:`删除「${o.name}」？`,message:i?`这个账本里有 ${i} 笔记录，会一起删掉，删了没法恢复。`:"这个账本还是空的，删掉不影响别的账本。",okText:"删除",danger:!0}))return;try{await kt(o.id),y("已删除账本"),n.close(),q(e)}catch(d){y(d.message)}return}const r=a.target.closest("[data-id]");r&&(await Me(r.dataset.id),y("已切换账本"),n.close(),q(e))})}function Pn(e){const t=O({title:"新建账本",body:`<div class="field-grid">
      <div class="field"><span class="field-label">名字</span>
        <input type="text" data-role="name" maxlength="12" placeholder="例如：装修" /></div>
      <div class="field"><span class="field-label">预算</span>
        <input type="text" inputmode="decimal" data-role="budget" placeholder="选填，每月支出上限" /></div>
    </div>
    <p class="muted" style="margin-top:10px">预算可以以后再设，先建账本也行。</p>`,actions:[{label:"取消",className:"btn-outline",onClick:n=>n.close()},{label:"创建",className:"btn-primary",onClick:async n=>{const a=n.body.querySelector('[data-role="name"]').value.trim(),s=n.body.querySelector('[data-role="budget"]').value.trim();if(!a)return y("给账本起个名字");let r=0;if(s){const i=je(s);if(i===null||i<0)return y("预算填个数字就行，比如 3000");r=i}const o=await $t(a,r);await Me(o.id),y(`已创建「${a}」并切过去了`),n.close(),q(e)}}]});setTimeout(()=>t.body.querySelector('[data-role="name"]')?.focus(),120)}function Cn(e){const t=j(),n=O({title:"重命名账本",body:`<div class="field-grid">
      <div class="field"><span class="field-label">名字</span>
        <input type="text" data-role="name" maxlength="12" value="${u(t.name)}" /></div>
    </div>`,actions:[{label:"取消",className:"btn-outline",onClick:a=>a.close()},{label:"保存",className:"btn-primary",onClick:async a=>{const s=a.body.querySelector('[data-role="name"]').value.trim();if(!s)return y("名字不能是空的");await Le(t.id,{name:s}),y("已改名"),a.close(),q(e)}}]});setTimeout(()=>n.body.querySelector('[data-role="name"]')?.select(),120)}function Fn(e){const t=j(),n=O({title:"本月预算",body:`<div class="field-grid">
      <div class="field"><span class="field-label">金额</span>
        <input type="text" inputmode="decimal" data-role="amount"
               placeholder="比如 3000，填 0 表示不设预算"
               value="${t.budgetFen?u(yt(t.budgetFen)):""}" /></div>
    </div>
    <p class="muted" style="margin-top:10px">这是每个月总的支出上限，花到 80% 会提醒你。</p>`,actions:[{label:"取消",className:"btn-outline",onClick:a=>a.close()},{label:"保存",className:"btn-primary",onClick:async a=>{const s=a.body.querySelector('[data-role="amount"]').value.trim();if(!s)return await Le(t.id,{budgetFen:0}),y("已取消预算"),a.close(),q(e);const r=je(s);if(r===null)return y("填数字就行，比如 3000");await Le(t.id,{budgetFen:r}),y(r?`预算设为 ${w(r)} 元`:"已取消预算"),a.close(),q(e)}}]});setTimeout(()=>n.body.querySelector('[data-role="amount"]')?.focus(),120)}function jn(e,t="expense"){const n=O({title:"分类管理",body:`
      <div class="seg" data-role="seg" style="margin-bottom:12px">
        <button type="button" data-kind="expense">支出分类</button>
        <button type="button" data-kind="income">收入分类</button>
      </div>
      <div data-role="list"></div>
      <button type="button" class="btn btn-outline btn-block" data-role="add" style="margin-top:14px">➕ 新增分类</button>
      <p class="muted" style="margin-top:12px">↑↓ 调整分类在记账页的排列顺序。删掉分类不会删掉记录，那些记录会显示成「未分类」。</p>`});function a(){const s=ee(t);n.body.querySelectorAll('[data-role="seg"] button').forEach(o=>{o.classList.toggle("active",o.dataset.kind===t)});const r=n.body.querySelector('[data-role="list"]');r.innerHTML=`<div class="set-list">${s.map((o,i)=>{const c=Qe(o.id);return`<div class="cat-row">
          <button type="button" class="cat-row-main" data-cat="${o.id}">
            <span class="cm-emoji">${u(o.emoji)}</span>
            <span class="cm-body">
              <div class="cm-name">${u(o.name)}</div>
              <div class="cm-sub">${c} 笔记录在用</div>
            </span>
          </button>
          <span class="cm-tools">
            <button type="button" class="mini-btn" data-up="${o.id}" ${i===0?"disabled":""} aria-label="上移">↑</button>
            <button type="button" class="mini-btn" data-down="${o.id}" ${i===s.length-1?"disabled":""} aria-label="下移">↓</button>
          </span>
        </div>`}).join("")}</div>`,r.querySelectorAll("[data-cat]").forEach(o=>{o.addEventListener("click",()=>ze(l.categories.find(i=>i.id===o.dataset.cat),()=>a()))}),r.querySelectorAll("[data-up], [data-down]").forEach(o=>{o.addEventListener("click",async()=>{const i=o.dataset.up?-1:1,c=o.dataset.up||o.dataset.down;await Et(c,i)&&a()})})}n.body.querySelectorAll('[data-role="seg"] button').forEach(s=>{s.addEventListener("click",()=>{t=s.dataset.kind,a()})}),n.body.querySelector('[data-role="add"]').addEventListener("click",()=>{ze(null,()=>{n.close(),q(e)},e,t)}),a()}function ze(e,t,n,a="expense"){const s=!e;let r=e?.emoji??"📦",o=e?.kind??a;const i=O({title:s?"新增分类":"编辑分类",body:`
      <div class="field-grid">
        <div class="field"><span class="field-label">名称</span>
          <input type="text" data-role="name" maxlength="6" value="${u(e?.name??"")}" placeholder="最多 6 个字" /></div>
        <div class="field"><span class="field-label">类型</span>
          <select data-role="kind">
            <option value="expense" ${o==="expense"?"selected":""}>支出</option>
            <option value="income" ${o==="income"?"selected":""}>收入</option>
          </select></div>
      </div>
      <p class="card-title" style="margin:16px 0 8px">选个图标</p>
      <div class="emoji-grid" data-role="emojis">
        ${Ln.map(c=>`<button type="button" data-e="${c}" class="${c===r?"active":""}">${c}</button>`).join("")}
      </div>
      ${s?"":'<div class="divider"></div><button type="button" class="btn btn-danger btn-block" data-role="del">删除这个分类</button>'}`,actions:[{label:"取消",className:"btn-outline",onClick:c=>c.close()},{label:s?"创建":"保存",className:"btn-primary",onClick:async c=>{const d=c.body.querySelector('[data-role="name"]').value.trim();if(!d)return y("给分类起个名字");const p=c.body.querySelector('[data-role="kind"]').value;s?(await xt(p,d,r),y("分类已添加")):(await Lt(e.id,{name:d,emoji:r,kind:p}),y("已保存")),c.close(),t?.()}}]});i.body.querySelector('[data-role="emojis"]').addEventListener("click",c=>{const d=c.target.closest("[data-e]");d&&(r=d.dataset.e,i.body.querySelectorAll("[data-e]").forEach(p=>p.classList.toggle("active",p===d)))}),i.body.querySelector('[data-role="del"]')?.addEventListener("click",async()=>{const c=Qe(e.id);await z({title:`删除「${e.name}」？`,message:c?`有 ${c} 笔记录在用这个分类。删掉分类不会删记录，但那些记录会变成「未分类」。`:"这个分类还没被用过，可以放心删。",okText:"删除",danger:!0})&&(await St(e.id),y("已删除"),i.close(),t?.())}),setTimeout(()=>i.body.querySelector('[data-role="name"]')?.focus(),120)}function dt(e){return e.mode==="download"?"已导出，去「下载」或「文件」里找":e.mode==="share-failed"?"文件已生成，但发送面板没弹出来："+(e.message||"系统限制"):"已导出，选个地方保存吧"}async function An(){const e=j(),t=qt(e.id),n=t.split(`\r
`).length-1;if(!n)return y("这个账本还没有记录，导出来是空的");const a=`${e.name}-${ct()}.csv`;try{const s=await it(a,"\uFEFF"+t,"text/csv");y(`${s.mode==="download"?`已导出 ${n} 条，`:""}${dt(s)}`)}catch(s){y("导出失败："+(s.message||"未知原因"))}}async function Mn(e){if(!l.transactions.length)return y("还没有数据可以备份");const t=`记账备份-${ct()}.json`;try{const n=await it(t,JSON.stringify(Tt(),null,2),"application/json");await X("lastBackupAt",Date.now()),y(dt(n)),e?.()}catch(n){y("导出失败："+(n.message||"未知原因"))}}async function Tn(e){let t=null;if(!await z({title:"从备份恢复？",message:`导入后，现在手机里的所有记录、账本、分类都会被备份文件里的内容替换掉，换不回来。

建议先「导出完整备份」存一份再操作。`,okText:"继续选择文件",danger:!0,onOk:()=>{t=En()}})||!t)return;const a=await t;if(a==null)return;let s;try{s=JSON.parse(a)}catch{return $e({title:"这个文件读不了",message:`它看起来不是备份文件，可能选错了。
请选之前用「导出完整备份」生成的那个 .json 文件。`})}try{const r=await Dt(s);await X("lastBackupAt",Date.now()),await $e({title:"恢复完成",message:`成功导入 ${r} 笔记录。`}),e()}catch(r){await $e({title:"恢复失败",message:r.message})}}async function qn(e){!await z({title:"清空所有数据？",message:`现在一共有 ${l.transactions.length} 笔记录、${l.ledgers.length} 个账本。
清空之后全部消失，没法恢复。`,okText:"我确定",danger:!0})||!await z({title:"最后确认一次",message:"真的要清空吗？建议先在电脑上导出一份备份放着。",okText:"清空",danger:!0})||(await h.clearAll(),await Ae(),y("已清空"),e())}const On={record:"记账",list:"账单",stats:"统计",settings:"设置"},lt=document.getElementById("view"),Dn=document.getElementById("pageTitle"),Rn=document.getElementById("ledgerName"),Nn={record:nt,list:M,stats:de,settings:q},Fe={};let Q=null;function ut(){Rn.textContent=j()?.name??""}function ne(){const e=Te();Q&&Q!==e&&(Fe[Q]=window.scrollY);const t=Q===e?window.scrollY:Fe[e]||0;Q=e,Dn.textContent=On[e],ut(),document.querySelectorAll(".tab").forEach(n=>n.classList.toggle("active",n.dataset.tab===e)),Nn[e](lt),window.scrollTo(0,t)}wt(ut);document.addEventListener("touchstart",()=>{},{passive:!0});function De(){const e=l.meta.theme,t=e?e==="dark":window.matchMedia("(prefers-color-scheme: dark)").matches;document.documentElement.dataset.theme=t?"dark":"light",document.querySelector('meta[name="theme-color"]')?.setAttribute("content",t?"#1d2027":"#3b7dd8")}document.getElementById("themeToggle").addEventListener("click",async()=>{const e=document.documentElement.dataset.theme==="dark"?"light":"dark";await X("theme",e),De()});window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change",()=>{l.meta.theme||De()});document.getElementById("ledgerSwitch").addEventListener("click",()=>{const e=l.ledgers.map(n=>({value:n.id,label:n.name,emoji:n.id===l.meta.currentLedgerId?"✅":"📒",sub:`${l.transactions.filter(a=>a.ledgerId===n.id).length} 笔`})),t=O({title:"切换账本",body:`<div class="set-list">${e.map(n=>`<button type="button" class="set-row" data-id="${n.value}">
          <span class="sr-ico">${n.emoji}</span>
          <span class="sr-main">${u(n.label)}<span class="sr-sub">${n.sub}</span></span>
        </button>`).join("")}</div>
    <p class="muted" style="margin-top:12px">要新建或删除账本，去「设置 → 账本」。</p>`});t.body.addEventListener("click",async n=>{const a=n.target.closest("[data-id]");a&&(await Me(a.dataset.id),t.close(),y("已切换账本"),Oe(),ne())})});document.querySelectorAll(".tab").forEach(e=>{e.addEventListener("click",()=>{const t=e.dataset.tab;t==="list"&&Oe(),t===Te()?(Fe[t]=0,ne()):qe(t)})});Ht(ne);const Bn=!!window.Capacitor?.isNativePlatform?.();"serviceWorker"in navigator&&(Bn?navigator.serviceWorker.getRegistrations?.().then(e=>e.forEach(t=>t.unregister())).catch(()=>{}):window.addEventListener("load",()=>{navigator.serviceWorker.register("./sw.js").catch(()=>{})}));async function Un(){try{await Ae()}catch(e){lt.innerHTML=`<div class="empty"><span class="empty-ico">😵</span>
      数据打不开了：${u(e.message)}<br /><br />
      可以试试刷新页面。如果还是不行，可能是浏览器禁用了本地存储。</div>`;return}De(),Oe(),ne(),window.addEventListener("focus",()=>{Te()==="list"&&ne()})}Un();export{Ce as E,ot as W,hn as b};
