(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))a(s);new MutationObserver(s=>{for(const r of s)if(r.type==="childList")for(const o of r.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&a(o)}).observe(document,{childList:!0,subtree:!0});function n(s){const r={};return s.integrity&&(r.integrity=s.integrity),s.referrerPolicy&&(r.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?r.credentials="include":s.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function a(s){if(s.ep)return;s.ep=!0;const r=n(s);fetch(s.href,r)}})();const Ut="jizhang",Ht=1,ze=["transactions","categories","ledgers","meta"];let pe=null;function me(){return pe||(pe=new Promise((e,t)=>{const n=indexedDB.open(Ut,Ht);n.onupgradeneeded=()=>{const a=n.result;if(!a.objectStoreNames.contains("transactions")){const s=a.createObjectStore("transactions",{keyPath:"id"});s.createIndex("ledgerId","ledgerId"),s.createIndex("ledger_date",["ledgerId","date"])}a.objectStoreNames.contains("categories")||a.createObjectStore("categories",{keyPath:"id"}).createIndex("ledgerId","ledgerId"),a.objectStoreNames.contains("ledgers")||a.createObjectStore("ledgers",{keyPath:"id"}),a.objectStoreNames.contains("meta")||a.createObjectStore("meta",{keyPath:"key"})},n.onsuccess=()=>e(n.result),n.onerror=()=>t(n.error)}),pe)}function Le(e,t){return me().then(n=>n.transaction(e,t).objectStore(e))}function Se(e){return new Promise((t,n)=>{e.onsuccess=()=>t(e.result),e.onerror=()=>n(e.error)})}const S={async getAll(e){const t=await Le(e,"readonly");return Se(t.getAll())},async put(e,t){const n=await Le(e,"readwrite");return Se(n.put(t))},async putMany(e,t){if(!t.length)return;const n=await me();return new Promise((a,s)=>{const r=n.transaction(e,"readwrite"),o=r.objectStore(e);t.forEach(i=>o.put(i)),r.oncomplete=()=>a(),r.onerror=()=>s(r.error),r.onabort=()=>s(r.error)})},async remove(e,t){const n=await Le(e,"readwrite");return Se(n.delete(t))},async removeMany(e,t){if(!t.length)return;const n=await me();return new Promise((a,s)=>{const r=n.transaction(e,"readwrite"),o=r.objectStore(e);t.forEach(i=>o.delete(i)),r.oncomplete=()=>a(),r.onerror=()=>s(r.error)})},async clearAll(){const e=await me();return new Promise((t,n)=>{const a=e.transaction(ze,"readwrite");ze.forEach(s=>a.objectStore(s).clear()),a.oncomplete=()=>t(),a.onerror=()=>n(a.error)})}};function Z(){return Date.now().toString(36)+Math.random().toString(36).slice(2,8)}const Wt="1.6";function ut(e){const t=e<0,n=Math.abs(e),a=Math.floor(n/100),s=n%100;return(t?"-":"")+a+(s?"."+String(s).padStart(2,"0"):"")}function x(e){const t=e<0,n=Math.abs(e),a=Math.floor(n/100),s=n%100,r=a.toLocaleString("en-US"),o=s?`${r}.${String(s).padStart(2,"0")}`:`${r}.00`;return(t?"-":"")+o}function he(e){const t=String(e).trim();if(!t||!/^\d*(\.\d{0,2})?$/.test(t))return null;const n=Number(t);return Number.isFinite(n)?Math.round(n*100):null}function M(){return K(new Date)}function K(e){const t=e.getFullYear(),n=String(e.getMonth()+1).padStart(2,"0"),a=String(e.getDate()).padStart(2,"0");return`${t}-${n}-${a}`}function fe(e){return/^\d{4}-\d{2}-\d{2}$/.test(String(e??""))}function ee(e,t){const[n,a,s]=String(e).split("-").map(Number);return K(new Date(n,a-1,s+t))}function Xe(e=0){return ee(M(),-e)}function Ne(e,t){const n=a=>{const[s,r,o]=String(a).split("-").map(Number);return new Date(s,r-1,o).getTime()};return Math.round((n(t)-n(e))/864e5)}function _e(e){return String(e).slice(0,7)}function we(){return M().slice(0,7)}function pt(e,t){const[n,a]=e.split("-").map(Number),s=new Date(n,a-1+t,1);return`${s.getFullYear()}-${String(s.getMonth()+1).padStart(2,"0")}`}function Je(e){const[t,n,a]=e.split("-").map(Number),s=new Date(t,n-1,a),r=["周日","周一","周二","周三","周四","周五","周六"][s.getDay()];return`${n}月${a}日 ${r}`}function Yt(e){const[t,n]=e.split("-").map(Number),a=new Date().getFullYear();return t===a?`${n}月`:`${t}年${n}月`}const mt=["week","month","year"],ft={week:"周",month:"月",year:"年"},Gt={week:"上周",month:"上月",year:"上年"},Qe={day:"天",week:"周",month:"个月",year:"年"},Kt={day:"天",week:"周",month:"月",year:"年"},gt={week:"这一周",month:"这个月",year:"这一年"};function X(e,t=M()){return e==="day"?t:e==="week"?Vt(t):e==="year"?t.slice(0,4):_e(t)}function C(e){return X(e,M())}function Vt(e){const[t,n,a]=e.split("-").map(Number),s=new Date(t,n-1,a);return s.setDate(s.getDate()-(s.getDay()+6)%7),K(s)}function R(e,t){if(e==="day")return{start:t,end:t};if(e==="week"){const[s,r,o]=t.split("-").map(Number);return{start:t,end:K(new Date(s,r-1,o+6))}}if(e==="year")return{start:`${t}-01-01`,end:`${t}-12-31`};const[n,a]=t.split("-").map(Number);return{start:`${t}-01`,end:K(new Date(n,a,0))}}function G(e,t,n){if(e==="day")return ee(t,n);if(e==="week"){const[a,s,r]=t.split("-").map(Number);return K(new Date(a,s-1,r+n*7))}return e==="year"?String(Number(t)+n):pt(t,n)}function yt(e,t,n){const{start:a,end:s}=R(e,t),r=M(),o=r>=a&&r<=s?r:a;return X(n,o)}function vt(e,t){if(e==="year")return`${t}年`;if(e==="month")return Yt(t);const{start:n,end:a}=R("week",t),[s,r,o]=n.split("-").map(Number),[i,c,d]=a.split("-").map(Number),y=new Date().getFullYear(),m=w=>w===y?"":`${w}年`,b=s===i&&r===c?`${d}日`:`${m(i)}${c}月${d}日`;return`${m(s)}${r}月${o}日–${b}`}function bt(e,t){if(e==="year")return t;if(e==="month")return`${Number(t.slice(5))}月`;const[,n,a]=t.split("-").map(Number);return`${n}/${a}`}const zt={start:"0000-01-01",end:"9999-12-31"};function ie({start:e,end:t}){return Ne(e,t)+1}function ge({start:e,end:t}){const n=new Date().getFullYear(),[a,s,r]=e.split("-").map(Number),[o,i,c]=t.split("-").map(Number),d=b=>b===n?"":`${b}年`;if(e===t)return`${d(a)}${s}月${r}日`;const y=`${d(a)}${s}月${r}日`,m=a===o&&s===i?`${c}日`:`${d(o)}${i}月${c}日`;return`${y}–${m}`}function Xt(e){const t=ie(e);return{start:ee(e.start,-t),end:ee(e.start,-1)}}const Ie=[{id:"d7",label:"近 7 天",days:7},{id:"d30",label:"近 30 天",days:30},{id:"m3",label:"近 3 个月",months:3},{id:"ytd",label:"今年"},{id:"last",label:"去年"}];function Ze(e,t=M()){if(e.days)return{start:ee(t,-(e.days-1)),end:t};if(e.months)return{start:`${pt(_e(t),-(e.months-1))}-01`,end:t};if(e.id==="ytd")return{start:`${t.slice(0,4)}-01-01`,end:t};if(e.id==="last"){const n=Number(t.slice(0,4))-1;return{start:`${n}-01-01`,end:`${n}-12-31`}}return{start:t,end:t}}function Jt(e,t){let n=0,a=X(t,e.start);for(;n<400&&!(R(t,a).start>e.end);)n+=1,a=G(t,a,1);return n}function Qt(e,t=8){const n=ie(e),a=n<=31?["day","week","month","year"]:n<=210?["week","month","year"]:n<=1460?["month","year"]:["year"];for(const s of a)if(Jt(e,s)<=t)return s;return a[a.length-1]}function u(e){return String(e??"").replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t])}const et=["#3b7dd8","#e0575b","#26a06a","#e0a32e","#8b5cf6","#12a5b8","#e0669a","#7a8b3f","#c2743a","#5a6b8c"];function tt(e){return et[e%et.length]}function ye(e,t){return e.reduce((n,a)=>n+t(a),0)}function Zt(e){const t=ye(e.filter(a=>a.kind==="income"),a=>a.amountFen),n=ye(e.filter(a=>a.kind==="expense"),a=>a.amountFen);return{incomeFen:t,expenseFen:n,balanceFen:t-n}}const ht=[{kind:"expense",name:"餐饮",emoji:"🍚"},{kind:"expense",name:"交通",emoji:"🚌"},{kind:"expense",name:"购物",emoji:"🛒"},{kind:"expense",name:"房租水电",emoji:"🏠"},{kind:"expense",name:"娱乐",emoji:"🎮"},{kind:"expense",name:"医疗",emoji:"💊"},{kind:"expense",name:"学习",emoji:"📚"},{kind:"expense",name:"人情",emoji:"🎁"},{kind:"expense",name:"其他",emoji:"📦"},{kind:"income",name:"工资",emoji:"💰"},{kind:"income",name:"红包",emoji:"🧧"},{kind:"income",name:"理财",emoji:"📈"},{kind:"income",name:"兼职",emoji:"💼"},{kind:"income",name:"其他",emoji:"📦"}],en="日常账本",l={ledgers:[],categories:[],transactions:[],meta:{},loaded:!1};async function Be(){const[e,t,n,a]=await Promise.all([S.getAll("ledgers"),S.getAll("categories"),S.getAll("transactions"),S.getAll("meta")]);if(l.ledgers=e.sort(Te),l.categories=t.sort(Te),l.transactions=n,l.meta=Object.fromEntries(a.map(s=>[s.key,s.value])),!l.ledgers.length){const s={id:Z(),name:en,budgetFen:0,order:0,createdAt:Date.now()};l.ledgers=[s],await S.put("ledgers",s),l.meta.currentLedgerId=s.id,await S.put("meta",{key:"currentLedgerId",value:s.id})}l.categories.length||(l.categories=ht.map((s,r)=>({id:Z(),kind:s.kind,name:s.name,emoji:s.emoji,order:r})),await S.putMany("categories",l.categories)),(!l.meta.currentLedgerId||!l.ledgers.some(s=>s.id===l.meta.currentLedgerId))&&(l.meta.currentLedgerId=l.ledgers[0].id,await S.put("meta",{key:"currentLedgerId",value:l.meta.currentLedgerId})),await tn(),l.loaded=!0}async function tn(){const e=l.categories.filter(t=>t.kind==="income"&&t.name==="红包"&&t.emoji==="💵");for(const t of e)t.emoji="🧧",await S.put("categories",t)}function Te(e,t){return(e.order??0)-(t.order??0)}async function ae(e,t){l.meta[e]=t,await S.put("meta",{key:e,value:t})}function D(){return l.ledgers.find(e=>e.id===l.meta.currentLedgerId)||l.ledgers[0]}const Ae=new Set;function nn(e){return Ae.add(e),()=>Ae.delete(e)}function $e(){const e=D();Ae.forEach(t=>t(e))}async function Ue(e){l.ledgers.some(t=>t.id===e)&&(await ae("currentLedgerId",e),$e())}async function an(e,t=0){const n={id:Z(),name:e.trim(),budgetFen:t,order:l.ledgers.length,createdAt:Date.now()};return l.ledgers.push(n),await S.put("ledgers",n),n}async function je(e,t){const n=l.ledgers.find(a=>a.id===e);n&&(Object.assign(n,t),await S.put("ledgers",n),$e())}async function sn(e){if(l.ledgers.length<=1)throw new Error("至少要保留一个账本");const t=l.transactions.filter(n=>n.ledgerId===e);l.transactions=l.transactions.filter(n=>n.ledgerId!==e),l.ledgers=l.ledgers.filter(n=>n.id!==e),await S.removeMany("transactions",t.map(n=>n.id)),await S.remove("ledgers",e),l.meta.currentLedgerId===e&&await ae("currentLedgerId",l.ledgers[0].id),$e()}function re(e){return l.categories.filter(t=>t.kind===e).sort(Te)}function J(e){return l.categories.find(t=>t.id===e)}async function rn(e,t,n,a=0){const s=l.categories.filter(o=>o.kind===e),r={id:Z(),kind:e,name:t.trim(),emoji:n||"📦",order:s.reduce((o,i)=>Math.max(o,i.order??0),-1)+1};return e==="expense"&&a>0&&(r.budgetFen=a),l.categories.push(r),await S.put("categories",r),r}async function on(e,t){const n=J(e);if(!n)return!1;const a=re(n.kind),s=a.findIndex(o=>o.id===e),r=s+t;return s<0||r<0||r>=a.length?!1:(a.splice(r,0,a.splice(s,1)[0]),await Promise.all(a.map((o,i)=>(o.order=i,S.put("categories",o)))),!0)}async function cn(e,t){const n=J(e);n&&(Object.assign(n,t),(n.kind==="income"||!(n.budgetFen>0))&&delete n.budgetFen,await S.put("categories",n))}function wt(e){return l.transactions.filter(t=>t.categoryId===e).length}async function dn(e){l.categories=l.categories.filter(t=>t.id!==e),await S.remove("categories",e)}function ce(e=l.meta.currentLedgerId){return l.transactions.filter(t=>t.ledgerId===e)}async function $t(e){const t=Date.now(),n={id:Z(),ledgerId:e.ledgerId,kind:e.kind,amountFen:e.amountFen,categoryId:e.categoryId,date:e.date,note:e.note||"",createdAt:t,updatedAt:t};return l.transactions.push(n),await S.put("transactions",n),n}async function ln(e,t){const n=l.transactions.find(a=>a.id===e);n&&(Object.assign(n,t,{updatedAt:Date.now()}),await S.put("transactions",n))}async function un(e){const t=l.transactions.find(n=>n.id===e)||null;return l.transactions=l.transactions.filter(n=>n.id!==e),await S.remove("transactions",e),t}async function pn(e){e&&(l.transactions.some(t=>t.id===e.id)||(l.transactions.push(e),await S.put("transactions",e)))}function mn(e,t=l.meta.currentLedgerId,{categoryId:n="",keyword:a=""}={}){const s=a.trim().toLowerCase();return ce(t).filter(r=>r.date>=e.start&&r.date<=e.end).filter(r=>!n||r.categoryId===n).filter(r=>{if(!s)return!0;const o=J(r.categoryId);return(r.note||"").toLowerCase().includes(s)||(o?.name||"").toLowerCase().includes(s)}).sort((r,o)=>r.date===o.date?o.createdAt-r.createdAt:o.date.localeCompare(r.date))}function ve(e,t=l.meta.currentLedgerId){const n=ce(t).filter(r=>r.date>=e.start&&r.date<=e.end),a=n.filter(r=>r.kind==="income").reduce((r,o)=>r+o.amountFen,0),s=n.filter(r=>r.kind==="expense").reduce((r,o)=>r+o.amountFen,0);return{incomeFen:a,expenseFen:s,balanceFen:a-s,count:n.length}}function kt(e,t,n=l.meta.currentLedgerId){const a=new Map;for(const s of ce(n)){if(s.kind!==t||s.date<e.start||s.date>e.end)continue;const r=a.get(s.categoryId)||{amountFen:0,count:0};r.amountFen+=s.amountFen,r.count+=1,a.set(s.categoryId,r)}return a}function fn(e,t,n=l.meta.currentLedgerId){const a=kt(e,t,n),s=[...a.values()].reduce((r,o)=>r+o.amountFen,0);return{total:s,items:[...a.entries()].map(([r,o])=>{const i=J(r);return{categoryId:r,amountFen:o.amountFen,count:o.count,name:i?.name??"未分类",emoji:i?.emoji??"❓",pct:s?o.amountFen/s:0}}).sort((r,o)=>o.amountFen-r.amountFen)}}function gn(e,t=l.meta.currentLedgerId,n=8){const a=Qt(e,n),s=[];let r=X(a,e.start);for(;s.length<400;){const o=R(a,r);if(o.start>e.end)break;const i={start:o.start<e.start?e.start:o.start,end:o.end>e.end?e.end:o.end};s.push({key:r,unit:a,label:bt(a,r),...ve(i,t)}),r=G(a,r,1)}return s}function xt(e,t,n=l.meta.currentLedgerId){return ve(R(e,t),n)}function Et(e,t=l.meta.currentLedgerId){return xt("month",e,t)}function yn(e,t,n,a=l.meta.currentLedgerId){return kt(R(e,t),n,a)}const vn=.8;function Lt(e=we(),t=l.meta.currentLedgerId){const n=yn("month",e,"expense",t),a=new Map;for(const s of l.categories){if(s.kind!=="expense")continue;const r=s.budgetFen||0;if(r<=0)continue;const o=n.get(s.id)?.amountFen??0,i=o/r;a.set(s.id,{budgetFen:r,spentFen:o,leftFen:r-o,ratio:i,level:i>=1?"over":i>=vn?"warn":"ok"})}return a}function bn(e,t,n,a=l.meta.currentLedgerId){const s=[];for(let r=n-1;r>=0;r-=1){const o=G(e,t,-r);s.push({key:o,label:bt(e,o),...xt(e,o,a)})}return s}function hn(e=l.meta.currentLedgerId){const t=ce(e);return t.length?t.reduce((n,a)=>a.date<n?a.date:n,t[0].date):M()}function wn(){return{app:"jizhang",version:1,exportedAt:new Date().toISOString(),ledgers:l.ledgers,categories:l.categories,transactions:l.transactions,meta:{currentLedgerId:l.meta.currentLedgerId}}}function $n(e=l.meta.currentLedgerId){const t=l.ledgers.find(a=>a.id===e),n=[["日期","类型","分类","金额(元)","备注","账本"]];return ce(e).slice().sort((a,s)=>a.date.localeCompare(s.date)||a.createdAt-s.createdAt).forEach(a=>{n.push([a.date,a.kind==="expense"?"支出":"收入",J(a.categoryId)?.name??"未分类",(a.amountFen/100).toFixed(2),a.note||"",t?.name??""])}),n.map(a=>a.map(kn).join(",")).join(`\r
`)}function kn(e){const t=String(e??"");return/[",\r\n]/.test(t)?`"${t.replace(/"/g,'""')}"`:t}async function xn(e){if(!e||e.app!=="jizhang")throw new Error("这不是本 App 导出的备份文件");if(!Array.isArray(e.ledgers)||!Array.isArray(e.transactions))throw new Error("备份文件内容不完整，可能传坏了");const t=e.ledgers;if(!t.length)throw new Error("备份文件里没有账本");if(!t.every(Ln))throw new Error("备份文件里的账本信息不完整");if(!e.transactions.every(In))throw new Error("备份文件里有读不懂的记录");const n=Array.isArray(e.categories)?e.categories.filter(Sn):[],a=n.length?n:En(),s=e.meta?.currentLedgerId,r=t.some(i=>i.id===s)?s:t[0].id,o={...l.meta};return delete o.currentLedgerId,await S.clearAll(),await S.putMany("ledgers",t),await S.putMany("categories",a),await S.putMany("transactions",e.transactions),await S.put("meta",{key:"currentLedgerId",value:r}),await S.putMany("meta",Object.entries(o).map(([i,c])=>({key:i,value:c}))),await Pn(),$e(),e.transactions.length}function En(){return ht.map((e,t)=>({id:Z(),kind:e.kind,name:e.name,emoji:e.emoji,order:t}))}function Ln(e){return e&&typeof e.id=="string"&&typeof e.name=="string"}function Sn(e){return e&&typeof e.id=="string"&&typeof e.name=="string"&&(e.kind==="expense"||e.kind==="income")}function In(e){return e&&typeof e.id=="string"&&typeof e.date=="string"&&Number.isFinite(e.amountFen)}async function Pn(){l.loaded=!1,await Be()}const Me=new Set;let qe="record";function He(){return qe}function Fn(e){return Me.add(e),()=>Me.delete(e)}function We(e){e!==qe&&(qe=e,Me.forEach(t=>t(e)))}function E(e,{ms:t=2e3,actionLabel:n="",onAction:a=null}={}){const s=document.getElementById("toastRoot");if(!s)return{dismiss(){}};const r=document.createElement("div");r.className="toast";const o=document.createElement("span");o.textContent=e,r.appendChild(o);let i=null;const c=()=>{clearTimeout(i),r.style.transition="opacity .25s",r.style.opacity="0",setTimeout(()=>r.remove(),260)};if(n){const d=document.createElement("button");d.type="button",d.className="toast-action",d.textContent=n,d.addEventListener("click",()=>{c(),a?.()}),r.appendChild(d)}return s.appendChild(r),i=setTimeout(c,t),{dismiss:c}}function N({title:e="",body:t="",actions:n=[],onClose:a=null}={}){const s=document.getElementById("sheetRoot"),r=document.createElement("div");r.className="sheet-mask",r.innerHTML=`
    <div class="sheet" role="dialog" aria-modal="true">
      <div class="sheet-grip"></div>
      ${e?`<h3>${u(e)}</h3>`:""}
      <div class="sheet-body"></div>
      ${n.length?'<div class="sheet-actions"></div>':""}
    </div>`;const o=r.querySelector(".sheet-body");typeof t=="string"?o.innerHTML=t:o.appendChild(t);let i=!1;const c={el:r,body:o,close(){i||(i=!0,r.style.animation="fade .15s reverse",setTimeout(()=>r.remove(),140),a?.())}};if(n.length){const d=r.querySelector(".sheet-actions");n.forEach(y=>{const m=document.createElement("button");m.type="button",m.className=`btn ${y.className||""}`,m.textContent=y.label,y.disabled&&(m.disabled=!0),m.addEventListener("click",()=>y.onClick?.(c)),d.appendChild(m)})}return r.addEventListener("click",d=>{d.target===r&&c.close()}),s.appendChild(r),c}function te({title:e="确认",message:t="",okText:n="确定",cancelText:a="取消",danger:s=!1,onOk:r}={}){return new Promise(o=>{const i=document.getElementById("dialogRoot"),c=document.createElement("div");c.className="dialog-mask",c.innerHTML=`
      <div class="dialog" role="alertdialog" aria-modal="true">
        <h3>${u(e)}</h3>
        <p>${u(t)}</p>
        <div class="dialog-actions">
          <button type="button" class="btn btn-outline" data-act="cancel">${u(a)}</button>
          <button type="button" class="btn ${s?"btn-danger":"btn-primary"}" data-act="ok">${u(n)}</button>
        </div>
      </div>`;const d=y=>{c.remove(),o(y)};c.querySelector('[data-act="cancel"]').addEventListener("click",()=>d(!1)),c.querySelector('[data-act="ok"]').addEventListener("click",()=>{r?.(),d(!0)}),c.addEventListener("click",y=>{y.target===c&&d(!1)}),i.appendChild(c)})}function Pe({title:e="提示",message:t=""}={}){return new Promise(n=>{const a=document.getElementById("dialogRoot"),s=document.createElement("div");s.className="dialog-mask",s.innerHTML=`
      <div class="dialog" role="alertdialog" aria-modal="true">
        <h3>${u(e)}</h3>
        <p>${u(t)}</p>
        <div class="dialog-actions">
          <button type="button" class="btn btn-primary" data-act="ok">知道了</button>
        </div>
      </div>`;const r=()=>{s.remove(),n()};s.querySelector('[data-act="ok"]').addEventListener("click",r),s.addEventListener("click",o=>{o.target===s&&r()}),a.appendChild(s)})}function Cn(e){let t=String(e).replace(/[^\d.]/g,"");const n=t.indexOf(".");if(n!==-1){t=t.slice(0,n+1)+t.slice(n+1).replace(/\./g,"");const[a,s=""]=t.split(".");t=`${a}.${s.slice(0,2)}`}return t}function Tn(e,t){return t.level==="over"?`${e.name}：本月已花 ${x(t.spentFen)} 元，超预算 ${x(-t.leftFen)} 元（预算 ${x(t.budgetFen)} 元）`:`${e.name}：本月已花 ${x(t.spentFen)} 元，预算 ${x(t.budgetFen)} 元，还剩 ${x(t.leftFen)} 元（已用 ${(t.ratio*100).toFixed(0)}%）`}function St(e,t={}){const n=!!t.tx,a=n?{kind:t.tx.kind,amount:(t.tx.amountFen/100).toFixed(2).replace(/\.00$/,""),categoryId:t.tx.categoryId,date:t.tx.date,note:t.tx.note||""}:{kind:"expense",amount:"",categoryId:"",date:M(),note:""};e.innerHTML=`
    <div class="seg" data-role="seg">
      <button type="button" data-kind="expense">支出</button>
      <button type="button" data-kind="income">收入</button>
    </div>

    <div class="amount-box">
      <div class="amount-label">金额</div>
      <div class="amount-row">
        <span class="amount-cur">¥</span>
        <input id="amountInput" type="text" inputmode="decimal" placeholder="0.00"
               autocomplete="off" enterkeyhint="done" />
      </div>
      <div class="amount-hint" data-role="hint"></div>
    </div>

    <div class="card">
      <p class="card-title">分类</p>
      <div class="cat-grid" data-role="cats"></div>
      <p class="cat-legend" data-role="cat-legend" hidden></p>
    </div>

    <div class="card">
      <div class="field-grid">
        <div class="field">
          <span class="field-label">日期</span>
          <input type="date" data-role="date" />
        </div>
        <div class="quick-dates" data-role="quickdates">
          <button type="button" class="chip" data-off="0">今天</button>
          <button type="button" class="chip" data-off="1">昨天</button>
          <button type="button" class="chip" data-off="2">前天</button>
        </div>
        <div class="field">
          <span class="field-label">备注</span>
          <input type="text" data-role="note" maxlength="60" placeholder="选填，例如：和同事聚餐" />
        </div>
      </div>
    </div>

    <button type="button" class="btn btn-primary btn-block" data-role="save">${u(t.submitLabel||(n?"保存修改":"保存这笔"))}</button>
  `;const s=e.querySelector("#amountInput"),r=e.querySelector('[data-role="hint"]'),o=e.querySelector('[data-role="cats"]'),i=e.querySelector('[data-role="cat-legend"]'),c=e.querySelector('[data-role="date"]'),d=e.querySelector('[data-role="note"]'),y=e.querySelector('[data-role="save"]'),m=e.querySelector('[data-role="quickdates"]');s.value=a.amount,c.value=a.date,d.value=a.note;function b(){e.querySelectorAll('[data-role="seg"] button').forEach(p=>{p.classList.toggle("active",p.dataset.kind===a.kind)})}function w(){const p=re(a.kind);if(!p.length){o.innerHTML='<div class="muted">这个类型下还没有分类，去「设置 → 分类管理」加一个</div>',i.hidden=!0;return}p.some(k=>k.id===a.categoryId)||(a.categoryId=p[0].id);const g=a.kind==="expense"?Lt(_e(a.date)):new Map;o.innerHTML=p.map(k=>{const h=g.get(k.id),j=h?Tn(k,h):"";return`<button type="button" class="cat-item ${k.id===a.categoryId?"active":""}" data-cat="${k.id}"
            ${h?`title="${u(j)}" aria-label="${u(j)}"`:""}>
          ${h?`<span class="cat-dot ${h.level}"></span>`:""}
          <span class="cat-emoji">${u(k.emoji)}</span>
          <span class="cat-name">${u(k.name)}</span>
        </button>`}).join(""),i.hidden=g.size===0,i.textContent="圆点＝月预算，黄是花到八成，红是超支"}function L(){m.querySelectorAll("[data-off]").forEach(p=>{p.classList.toggle("active",Xe(Number(p.dataset.off))===a.date)})}function v(){const p=he(a.amount);return a.amount.trim()===""?(r.className="amount-hint",r.textContent="",null):p===null?(r.className="amount-hint error",r.textContent="金额只能填数字，最多两位小数",null):p<=0?(r.className="amount-hint error",r.textContent="金额要大于 0",null):(r.className="amount-hint",r.textContent=`合计 ${x(p)} 元`,p)}return s.addEventListener("input",()=>{const p=Cn(s.value);if(p!==s.value){const g=s.selectionStart??p.length;s.value=p;const k=Math.max(0,Math.min(p.length,g-1));s.setSelectionRange(k,k)}a.amount=p,v()}),s.addEventListener("keydown",p=>{p.key==="Enter"&&(p.preventDefault(),y.click())}),e.querySelectorAll('[data-role="seg"] button').forEach(p=>{p.addEventListener("click",()=>{a.kind=p.dataset.kind,a.categoryId="",b(),w()})}),o.addEventListener("click",p=>{const g=p.target.closest("[data-cat]");g&&(a.categoryId=g.dataset.cat,w())}),c.addEventListener("change",()=>{a.date=c.value||M(),L(),w()}),m.addEventListener("click",p=>{const g=p.target.closest("[data-off]");g&&(a.date=Xe(Number(g.dataset.off)),c.value=a.date,L(),w())}),d.addEventListener("input",()=>{a.note=d.value}),y.addEventListener("click",async()=>{const p=v();if(p===null){a.amount.trim()===""&&E("先填金额"),s.focus();return}if(!a.categoryId){E("先选一个分类");return}y.disabled=!0;try{n?(await ln(t.tx.id,{kind:a.kind,amountFen:p,categoryId:a.categoryId,date:a.date,note:a.note.trim()}),E("已保存修改")):(await $t({ledgerId:D().id,kind:a.kind,amountFen:p,categoryId:a.categoryId,date:a.date,note:a.note.trim()}),E(`记下了 ${x(p)} 元`)),y.disabled=!1,t.onSaved?.({...a,amountFen:p})}catch(g){y.disabled=!1,E("保存失败："+g.message)}}),b(),w(),L(),v(),n&&setTimeout(()=>{s.focus(),s.select()},150),{draft:a,reset(){a.amount="",a.note="",a.date=M(),a.categoryId="",s.value="",d.value="",c.value=a.date,w(),L(),v()}}}const It=864e5,An=30,jn=7;function Pt(e){const t=D(),n=Et(we()),a=t.budgetFen||0;e.innerHTML=`
    ${Mn()}
    ${a>0?Rn(n.expenseFen,a):""}
    <div data-role="form"></div>
  `,qn(e),St(e.querySelector('[data-role="form"]'),{onSaved:()=>{Pt(e)}})}function Mn(){const e=l.meta.lastBackupAt||0,t=l.meta.backupReminderMutedUntil||0;if(Date.now()<t||!l.transactions.length)return"";const n=l.transactions.reduce((o,i)=>Math.min(o,i.createdAt||Date.now()),Date.now());if(Date.now()-(e||n)<An*It)return"";const s=e?Ne(new Date(e).toISOString().slice(0,10),new Date().toISOString().slice(0,10)):null,r=e?`上次备份是 ${s} 天前了。数据只在这台手机里，建议导出一份存到网盘。`:"还没有备份过。数据只在这台手机里，系统云备份也是关的 —— 卸载或者丢手机就全没了。建议导出一份存到网盘。";return`<div class="reminder" data-role="reminder">
    <span class="rem-main">${u(r)}</span>
    <button type="button" class="rem-close" data-act="reminder-close" aria-label="暂时不提醒">×</button>
  </div>`}function qn(e){const t=e.querySelector('[data-role="reminder"]');t&&(t.querySelector('[data-act="reminder-close"]').addEventListener("click",async()=>{await ae("backupReminderMutedUntil",Date.now()+jn*It),t.remove()}),t.querySelector(".rem-main").addEventListener("click",()=>We("settings")))}function Rn(e,t){const n=e/t,a=n>=1?"over":n>=.8?"warn":"",s=t-e,r=n>=1?`已经超支 ${x(-s)} 元`:`还能花 ${x(s)} 元`;return`<div class="card">
    <p class="card-title">本月预算</p>
    <div class="budget-line">
      <span>已花 ${u(x(e))} 元</span>
      <span>预算 ${u(x(t))} 元</span>
    </div>
    <div class="progress ${a}"><i style="width:${Math.min(n*100,100).toFixed(1)}%"></i></div>
    <div class="budget-tip ${a}">${u(r)}（已用 ${(n*100).toFixed(0)}%）</div>
  </div>`}function Ft({initial:e=null,fallback:t=null}={}){return new Promise(n=>{let a=!1;const s=v=>{a||(a=!0,n(v))},r=M(),o=nt(e)||nt(t)||{start:ee(r,-29),end:r},i=N({title:"自定义时间",body:`
        <p class="range-cap">快捷选择</p>
        <div class="chip-row" data-role="presets">
          ${Ie.map(v=>`<button type="button" class="chip" data-preset="${v.id}">${u(v.label)}</button>`).join("")}
        </div>
        <div class="range-fields">
          <label class="range-field">
            <span>开始</span>
            <input type="date" data-role="start" max="${r}" value="${o.start}" />
          </label>
          <span class="range-sep">–</span>
          <label class="range-field">
            <span>结束</span>
            <input type="date" data-role="end" max="${r}" value="${o.end}" />
          </label>
        </div>
        <p class="range-hint" data-role="hint"></p>`,actions:[{label:"取消",className:"btn-outline",onClick:v=>v.close()},{label:"看这段",className:"btn-primary",onClick:v=>{const p=b();p.error||(s(p.value),v.close())}}],onClose:()=>s(null)}),c=i.body.querySelector('[data-role="start"]'),d=i.body.querySelector('[data-role="end"]'),y=i.body.querySelector('[data-role="hint"]'),m=i.el.querySelector(".sheet-actions .btn-primary");function b(){const v=c.value,p=d.value;return!fe(v)||!fe(p)?{error:"开始和结束日期都要选"}:v>p?{error:"开始日期不能晚于结束日期"}:{value:{start:v,end:p>r?r:p}}}function w(){const v=b();if(v.error)return"";const p=Ie.find(g=>{const k=Ze(g,r);return k.start===v.value.start&&k.end===v.value.end});return p?p.id:""}function L(){const v=b(),p=!v.error;if(m&&(m.disabled=!p),!p)y.textContent=v.error,y.classList.add("error");else{const k=ie(v.value);y.textContent=k>1?`${ge(v.value)}　共 ${k} 天`:`${ge(v.value)}（就这一天）`,y.classList.remove("error")}const g=w();i.body.querySelectorAll("[data-preset]").forEach(k=>{k.classList.toggle("active",k.dataset.preset===g)})}c.addEventListener("change",L),d.addEventListener("change",L),i.body.querySelector('[data-role="presets"]').addEventListener("click",v=>{const p=v.target.closest("[data-preset]");if(!p)return;const g=Ie.find(h=>h.id===p.dataset.preset);if(!g)return;const k=Ze(g,r);c.value=k.start,d.value=k.end,L()}),L()})}function nt(e){if(!e)return null;const{start:t,end:n}=e;return!fe(t)||!fe(n)||t>n?null:{start:t,end:n}}const f={unit:"month",key:C("month"),categoryId:"",keyword:"",scope:"period",range:null};function Ye(){f.key=C(f.unit),f.categoryId="",f.keyword="",f.scope="period"}function Dn(){return f.scope==="custom"&&f.range?f.range:f.scope==="all"?zt:R(f.unit,f.key)}function A(e){const t=f.unit,n=f.scope==="custom"&&!!f.range;!n&&f.key>C(t)&&(f.key=C(t));const a=D(),s=n?f.range:Dn(),r=mn(s,a.id,{categoryId:f.categoryId,keyword:f.keyword}),o=!!(f.categoryId||f.keyword.trim()),i=f.scope==="all",c=Zt(r),d=f.key<=X(t,hn(a.id)),y=f.key>=C(t),m=o?` · 筛选出 ${r.length} 笔`:"";e.innerHTML=`
    <div class="scope" data-role="scope">
      ${mt.map(g=>`<button type="button" data-scope="${g}" class="${f.scope==="period"&&t===g?"active":""}">${ft[g]}</button>`).join("")}
      <button type="button" data-scope="all" class="${i?"active":""}">全部时间</button>
      <button type="button" data-scope="custom" class="${n?"active":""}">自定义</button>
    </div>

    ${n?`<button type="button" class="month-nav range-bar" data-role="editrange">
          <span class="m-label">${u(ge(s))}<span class="rb-sub">${u(On(s,o,r.length))}</span></span>
          <span class="rb-edit">修改</span>
        </button>`:i?"":`<div class="month-nav">
            <button type="button" class="m-arrow" data-role="prev" ${d?"disabled":""}>‹</button>
            <span class="m-label">${u(vt(t,f.key)+m)}</span>
            <button type="button" class="m-arrow" data-role="next" ${y?"disabled":""}>›</button>
          </div>`}

    <div class="summary">
      <div><div class="s-val income">${u(x(c.incomeFen))}</div><div class="s-key income">收入</div></div>
      <div><div class="s-val expense">${u(x(c.expenseFen))}</div><div class="s-key expense">支出</div></div>
      <div><div class="s-val balance">${u(x(c.balanceFen))}</div><div class="s-key">结余</div></div>
    </div>

    ${i?`<p class="muted" style="margin:-4px 0 12px 2px">全部时间里${o?"筛选出":"共"} ${r.length} 笔</p>`:""}

    <div class="filters">
      <select data-role="cat">
        <option value="">全部分类</option>
        ${re("expense").map(g=>`<option value="${g.id}" ${f.categoryId===g.id?"selected":""}>支出 · ${u(g.name)}</option>`).join("")}
        ${re("income").map(g=>`<option value="${g.id}" ${f.categoryId===g.id?"selected":""}>收入 · ${u(g.name)}</option>`).join("")}
      </select>
      <input type="search" data-role="kw" placeholder="搜备注或分类" value="${u(f.keyword)}" />
    </div>

    <div data-role="list"></div>
  `;const b=e.querySelector('[data-role="list"]');b.innerHTML=r.length?Nn(r,i||n):_n(o,f.scope,t),e.querySelector('[data-role="scope"]').addEventListener("click",g=>{const k=g.target.closest("[data-scope]");if(!k)return;const h=k.dataset.scope;if(h==="custom"){at(e);return}if(h==="all"){if(i)return;f.scope="all",A(e);return}if(f.scope==="period"&&t===h){if(f.key===C(t))return;f.key=C(t),A(e);return}f.key=f.scope==="custom"&&f.range?X(h,f.range.end):f.scope==="all"?C(h):yt(t,f.key,h),f.unit=h,f.scope="period",A(e)});const w=e.querySelector('[data-role="editrange"]');w&&w.addEventListener("click",()=>at(e));const L=e.querySelector('[data-role="prev"]');L&&(L.addEventListener("click",()=>{f.key=G(t,f.key,-1),A(e)}),e.querySelector('[data-role="next"]').addEventListener("click",()=>{f.key=G(t,f.key,1),A(e)})),e.querySelector('[data-role="cat"]').addEventListener("change",g=>{f.categoryId=g.target.value,A(e)});const v=e.querySelector('[data-role="kw"]');let p=null;v.addEventListener("input",()=>{clearTimeout(p),p=setTimeout(()=>{f.keyword=v.value,A(e);const g=document.querySelector('[data-role="kw"]');g&&(g.focus(),g.setSelectionRange(g.value.length,g.value.length))},260)}),b.addEventListener("click",g=>{const k=g.target.closest("[data-tx]");k&&Bn(k.dataset.tx,e)})}function On(e,t,n){const a=[`共 ${ie(e)} 天`];return t&&a.push(`筛选出 ${n} 笔`),a.push("点这里改时间"),a.join(" · ")}async function at(e){const t=await Ft({initial:f.range,fallback:R(f.unit,f.key)});t&&(f.range=t,f.scope="custom",A(e))}function Nn(e,t){const n=new Map;for(const s of e)n.has(s.date)||n.set(s.date,[]),n.get(s.date).push(s);const a=String(new Date().getFullYear());return[...n.entries()].map(([s,r])=>{const o=ye(r.filter(m=>m.kind==="income"),m=>m.amountFen),i=ye(r.filter(m=>m.kind==="expense"),m=>m.amountFen),c=[];o&&c.push(`收 ${x(o)}`),i&&c.push(`支 ${x(i)}`);const d=s.slice(0,4),y=t&&d!==a?`${d}年${Je(s)}`:Je(s);return`<div class="day-group">
        <div class="day-head">
          <span>${u(y)}</span>
          <span class="d-sub">${u(c.join("　"))}</span>
        </div>
        <div class="tx-list">
          ${r.map(m=>{const b=J(m.categoryId);return`<div class="tx" data-tx="${m.id}">
                <span class="tx-emoji">${u(b?.emoji??"❓")}</span>
                <span class="tx-main">
                  <div class="tx-cat">${u(b?.name??"未分类")}</div>
                  ${m.note?`<div class="tx-note">${u(m.note)}</div>`:""}
                </span>
                <span class="tx-amt ${m.kind}">${m.kind==="expense"?"-":"+"}${u(x(m.amountFen))}</span>
              </div>`}).join("")}
        </div>
      </div>`}).join("")}function _n(e,t,n){const a=e?"没有符合条件的记录":t==="all"?"还没有任何记录":t==="custom"?"这段时间还没有记账":`${gt[n]}还没有记账`;return`<div class="empty">
    <span class="empty-ico">${e?"🔍":"🗒️"}</span>
    ${a}
  </div>`}function Bn(e,t){const n=l.transactions.find(r=>r.id===e);if(!n)return;const a=J(n.categoryId),s=N({title:"这笔记录",body:`
      <div class="set-list">
        <div class="set-row" style="cursor:default">
          <span class="sr-ico">${u(a?.emoji??"❓")}</span>
          <span class="sr-main">
            <div style="font-size:16px;font-weight:600">${u(x(n.amountFen))} 元</div>
            <div class="sr-sub">${u(a?.name??"未分类")} · ${u(n.date)}${n.note?" · "+u(n.note):""}</div>
          </span>
        </div>
        <button type="button" class="set-row" data-act="edit"><span class="sr-ico">✏️</span><span class="sr-main">修改</span></button>
        <button type="button" class="set-row" data-act="dup"><span class="sr-ico">📋</span><span class="sr-main">再记一笔一样的<span class="sr-sub">复制到今天</span></span></button>
        <button type="button" class="set-row" data-act="del"><span class="sr-ico">🗑️</span><span class="sr-main" style="color:var(--danger)">删除</span></button>
      </div>`,actions:[{label:"取消",className:"btn-outline",onClick:r=>r.close()}]});s.body.addEventListener("click",async r=>{const o=r.target.closest("[data-act]");if(!o)return;const i=o.dataset.act;if(s.close(),i==="edit")return Hn(n,t);if(i==="del"){if(!await te({title:"删除这笔记录？",message:`${n.date}　${a?.name??"未分类"}　${x(n.amountFen)} 元
删掉之后可以马上点提示里的「撤销」找回。`,okText:"删除",danger:!0}))return;const d=await un(n.id);A(t),E("已删除 1 笔记录",{ms:6e3,actionLabel:"撤销",onAction:async()=>{await pn(d),E("已恢复"),A(t)}});return}i==="dup"&&await Un(n,t)})}async function Un(e,t){await $t({ledgerId:D().id,kind:e.kind,amountFen:e.amountFen,categoryId:e.categoryId,date:M(),note:e.note}),E("已复制到今天"),f.scope==="period"&&f.key!==C(f.unit)&&(f.key=C(f.unit)),A(t)}function Hn(e,t){const n=N({title:"修改记录",body:'<div data-role="form"></div>'});St(n.body.querySelector('[data-role="form"]'),{tx:e,submitLabel:"保存修改",onSaved:()=>{n.close(),A(t)}})}function st({unit:e,key:t,categoryId:n,range:a}={}){e&&(f.unit=e),t&&(f.key=t),n!==void 0&&(f.categoryId=n),a?(f.range=a,f.scope="custom"):t&&(f.scope="period")}const Ct=320;function Wn(e,{size:t=Ct,thickness:n=48,emptyText:a="这段时间还没有记录"}={}){const s=e.reduce((m,b)=>m+b.amountFen,0);if(!s)return`<div class="empty">${u(a)}</div>`;const r=(t-n)/2,o=t/2,i=t/2;let c=-Math.PI/2;const d=e.map((m,b)=>{const w=m.amountFen/s*Math.PI*2,L=w>=Math.PI*2-1e-6?rt(o,i,r,n,0,Math.PI*2-1e-4):rt(o,i,r,n,c,c+w);return c+=w,`<path d="${L}" fill="${tt(b)}" />`}),y=e[0];return`<div class="chart-wrap">
    <svg viewBox="0 0 ${t} ${t}" width="${t}" height="${t}" role="img"
         aria-label="分类占比环形图，合计 ${u(x(s))} 元">
      ${d.join("")}
      <text x="${o}" y="${i-8}" text-anchor="middle" font-size="13" fill="var(--text-3)">合计</text>
      <text x="${o}" y="${i+16}" text-anchor="middle" font-size="18" font-weight="600" fill="var(--text)">${u(x(s))}</text>
    </svg>
  </div>
  <div class="legend">
    ${e.slice(0,8).map((m,b)=>`<div class="legend-row">
          <span class="legend-dot" style="background:${tt(b)}"></span>
          <span class="legend-name">${u(m.emoji+" "+m.name)}</span>
          <span class="legend-amt">${u(x(m.amountFen))}</span>
          <span class="legend-pct">${(m.pct*100).toFixed(1)}%</span>
        </div>`).join("")}
    ${e.length>8?`<div class="muted">还有 ${e.length-8} 个分类没显示</div>`:""}
  </div>
  <div class="muted" style="margin-top:10px">占比最大：${u(y.name)}，${(y.pct*100).toFixed(1)}%</div>`}function rt(e,t,n,a,s,r){const o=n+a/2,i=n-a/2,c=r-s>Math.PI?1:0,d=e+o*Math.cos(s),y=t+o*Math.sin(s),m=e+o*Math.cos(r),b=t+o*Math.sin(r),w=e+i*Math.cos(r),L=t+i*Math.sin(r),v=e+i*Math.cos(s),p=t+i*Math.sin(s);return`M ${d} ${y} A ${o} ${o} 0 ${c} 1 ${m} ${b} L ${w} ${L} A ${i} ${i} 0 ${c} 0 ${v} ${p} Z`}function Yn(e,{height:t=190,emptyText:n="这段时间还没有记录",ariaLabel:a="收支趋势柱状图"}={}){const s=Ct,r=t,o=42,i=8,c=16,d=30,y=s-o-i,m=r-c-d,b=Math.max(...e.map(h=>Math.max(h.incomeFen,h.expenseFen)),1),w=y/e.length,L=Math.min(12,w/3.2),v=c+m,p=e.map((h,j)=>{const U=o+w*j+w/2,de=Math.round(h.incomeFen/b*m),I=Math.round(h.expenseFen/b*m),P=v-de,H=v-I;return`
        <rect x="${(U-L-2).toFixed(1)}" y="${H}" width="${L}" height="${Math.max(I,h.expenseFen?2:0)}" rx="2.5" fill="var(--expense)" />
        <rect x="${(U+2).toFixed(1)}" y="${P}" width="${L}" height="${Math.max(de,h.incomeFen?2:0)}" rx="2.5" fill="var(--income)" />
        <text x="${U.toFixed(1)}" y="${r-10}" text-anchor="middle" font-size="13" fill="var(--text-3)">${u(h.label)}</text>`}).join(""),g=[1,.5,0].map(h=>{const j=c+m*(1-h),U=h===0;return`
        <line x1="${o}" y1="${j.toFixed(1)}" x2="${s-i}" y2="${j.toFixed(1)}"
              stroke="var(--border)" stroke-width="${U?1:.5}"
              ${U?"":'stroke-dasharray="3 3"'} />
        <text x="${o-8}" y="${j.toFixed(1)}" text-anchor="end" dominant-baseline="central"
              font-size="12" fill="var(--text-3)">${u(Gn(b*h))}</text>`}).join(""),k=e.some(h=>h.incomeFen||h.expenseFen);return`<div class="chart-wrap">
    <svg viewBox="0 0 ${s} ${r}" role="img" aria-label="${u(a)}">
      ${g}
      ${p}
    </svg>
  </div>
  <div class="legend-group" style="margin-top:8px">
    <span class="legend-item"><i class="legend-dot" style="background:var(--income)"></i>收入</span>
    <span class="legend-item"><i class="legend-dot" style="background:var(--expense)"></i>支出</span>
  </div>
  ${k?"":`<div class="muted" style="margin-top:8px">${u(n)}</div>`}`}function Gn(e){if(!e)return"0";const t=e/100;if(t>=1e4){const n=t/1e4;return`${n>=10?String(Math.round(n)):n.toFixed(1).replace(/\.0$/,"")}万`}return String(Math.round(t))}const Fe=6,Kn=8,$={unit:"month",key:C("month"),kind:"expense",scope:"period",range:null};function z(e){const t=$.unit,n=$.scope==="custom"&&!!$.range;!n&&$.key>C(t)&&($.key=C(t));const a=D(),s=n?$.range:R(t,$.key),r=n?Xt(s):R(t,G(t,$.key,-1)),o=ve(s,a.id),i=ve(r,a.id),c=fn(s,$.kind,a.id),d=n?gn(s,a.id,Kn):bn(t,$.key,Fe,a.id),y=n?ge(s):vt(t,$.key),m=n?"上一段":Gt[t],b=!n&&$.key>=C(t),w=n?d[0]?.unit??"day":t,L=n?`区间趋势 · 按${Kt[w]}`:`最近 ${Fe} ${Qe[t]}趋势`;e.innerHTML=`
    <div class="scope" data-role="scope">
      ${mt.map(g=>`<button type="button" data-scope="${g}" class="${$.scope==="period"&&t===g?"active":""}">${ft[g]}</button>`).join("")}
      <button type="button" data-scope="custom" class="${n?"active":""}">自定义</button>
    </div>

    ${n?`<button type="button" class="month-nav range-bar" data-role="editrange">
          <span class="m-label">${u(y)}<span class="rb-sub">共 ${ie(s)} 天 · 点这里改时间</span></span>
          <span class="rb-edit">修改</span>
        </button>`:`<div class="month-nav">
          <button type="button" class="m-arrow" data-role="prev">‹</button>
          <span class="m-label">${u(y)}</span>
          <button type="button" class="m-arrow" data-role="next" ${b?"disabled":""}>›</button>
        </div>`}

    <div class="card">
      <p class="card-title">${u(y)}总结</p>
      <div class="summary summary-plain">
        <div><div class="s-val income">${u(x(o.incomeFen))}</div><div class="s-key income">收入</div></div>
        <div><div class="s-val expense">${u(x(o.expenseFen))}</div><div class="s-key expense">支出</div></div>
        <div><div class="s-val balance">${u(x(o.balanceFen))}</div><div class="s-key">结余</div></div>
      </div>
      ${Vn(o,i,m)}
      ${o.count?"":`<div class="muted" style="margin-top:10px">${u(n?"这段时间":gt[t])}还没有记录</div>`}
    </div>

    <div class="card">
      <div class="seg" data-role="kindseg" style="margin-bottom:12px">
        <button type="button" data-kind="expense">支出构成</button>
        <button type="button" data-kind="income">收入构成</button>
      </div>
      <div data-role="pie"></div>
    </div>

    <div class="card">
      <p class="card-title">${u(L)}</p>
      <div data-role="trend"></div>
    </div>
  `,e.querySelector('[data-role="pie"]').innerHTML=Wn(c.items,{emptyText:`这段时间还没有${$.kind==="income"?"收入":"支出"}记录`}),e.querySelector('[data-role="trend"]').innerHTML=Yn(d,{ariaLabel:n?"这段时间的收支趋势柱状图":`最近 ${Fe} ${Qe[t]}的收支趋势柱状图`,emptyText:"这段时间还没有记录"}),e.querySelector('[data-role="scope"]').addEventListener("click",g=>{const k=g.target.closest("[data-scope]");if(!k)return;const h=k.dataset.scope;if(h==="custom"){ot(e);return}if($.scope==="period"&&h===$.unit){if($.key===C(t))return;$.key=C(t),z(e);return}$.key=$.scope==="custom"&&$.range?X(h,$.range.end):yt($.unit,$.key,h),$.unit=h,$.scope="period",z(e)});const v=e.querySelector('[data-role="editrange"]');v&&v.addEventListener("click",()=>ot(e)),e.querySelectorAll('[data-role="kindseg"] button').forEach(g=>{g.classList.toggle("active",g.dataset.kind===$.kind),g.addEventListener("click",()=>{$.kind=g.dataset.kind,z(e)})});const p=e.querySelector('[data-role="prev"]');p&&(p.addEventListener("click",()=>{$.key=G(t,$.key,-1),z(e)}),e.querySelector('[data-role="next"]').addEventListener("click",()=>{$.key=G(t,$.key,1),z(e)})),e.querySelectorAll('[data-role="pie"] .legend-row').forEach((g,k)=>{const h=c.items[k];h&&(g.style.cursor="pointer",g.title="点一下看这个分类的明细",g.addEventListener("click",()=>{st(n?{range:$.range,categoryId:h.categoryId}:{unit:$.unit,key:$.key,categoryId:h.categoryId}),We("list")}))})}async function ot(e){const t=await Ft({initial:$.range,fallback:R($.unit,$.key)});t&&($.range=t,$.scope="custom",z(e))}function Vn(e,t,n){if(!e.count)return"";if(!t.count)return`<div class="delta">${n}没有记录，没法比</div>`;const a=e.expenseFen-t.expenseFen;if(a===0)return`<div class="delta">支出和${n}持平</div>`;const s=a>0,r=s?"up":"down",o=`支出比${n}${s?"多":"少"}花 <b>${u(x(Math.abs(a)))}</b> 元`;if(!t.expenseFen)return`<div class="delta ${r}">${o}</div>`;const i=Math.round(Math.abs(a/t.expenseFen)*100);return`<div class="delta ${r}">${o} <b>(${s?"+":"-"}${i}%)</b></div>`}const zn="modulepreload",Xn=function(e,t){return new URL(e,t).href},it={},Tt=function(t,n,a){let s=Promise.resolve();if(n&&n.length>0){const o=document.getElementsByTagName("link"),i=document.querySelector("meta[property=csp-nonce]"),c=i?.nonce||i?.getAttribute("nonce");s=Promise.allSettled(n.map(d=>{if(d=Xn(d,a),d in it)return;it[d]=!0;const y=d.endsWith(".css"),m=y?'[rel="stylesheet"]':"";if(!!a)for(let L=o.length-1;L>=0;L--){const v=o[L];if(v.href===d&&(!y||v.rel==="stylesheet"))return}else if(document.querySelector(`link[href="${d}"]${m}`))return;const w=document.createElement("link");if(w.rel=y?"stylesheet":zn,y||(w.as="script"),w.crossOrigin="",w.href=d,c&&w.setAttribute("nonce",c),document.head.appendChild(w),y)return new Promise((L,v)=>{w.addEventListener("load",L),w.addEventListener("error",()=>v(new Error(`Unable to preload CSS for ${d}`)))})}))}function r(o){const i=new Event("vite:preloadError",{cancelable:!0});if(i.payload=o,window.dispatchEvent(i),!i.defaultPrevented)throw o}return s.then(o=>{for(const i of o||[])i.status==="rejected"&&r(i.reason);return t().catch(r)})};/*! Capacitor: https://capacitorjs.com/ - MIT License */const Jn=e=>{const t=new Map;t.set("web",{name:"web"});const n=e.CapacitorPlatforms||{currentPlatform:{name:"web"},platforms:t},a=(r,o)=>{n.platforms.set(r,o)},s=r=>{n.platforms.has(r)&&(n.currentPlatform=n.platforms.get(r))};return n.addPlatform=a,n.setPlatform=s,n},Qn=e=>e.CapacitorPlatforms=Jn(e),At=Qn(typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});At.addPlatform;At.setPlatform;var ne;(function(e){e.Unimplemented="UNIMPLEMENTED",e.Unavailable="UNAVAILABLE"})(ne||(ne={}));class Ce extends Error{constructor(t,n,a){super(t),this.message=t,this.code=n,this.data=a}}const Zn=e=>{var t,n;return e?.androidBridge?"android":!((n=(t=e?.webkit)===null||t===void 0?void 0:t.messageHandlers)===null||n===void 0)&&n.bridge?"ios":"web"},ea=e=>{var t,n,a,s,r;const o=e.CapacitorCustomPlatform||null,i=e.Capacitor||{},c=i.Plugins=i.Plugins||{},d=e.CapacitorPlatforms,y=()=>o!==null?o.name:Zn(e),m=((t=d?.currentPlatform)===null||t===void 0?void 0:t.getPlatform)||y,b=()=>m()!=="web",w=((n=d?.currentPlatform)===null||n===void 0?void 0:n.isNativePlatform)||b,L=I=>{const P=j.get(I);return!!(P?.platforms.has(m())||g(I))},v=((a=d?.currentPlatform)===null||a===void 0?void 0:a.isPluginAvailable)||L,p=I=>{var P;return(P=i.PluginHeaders)===null||P===void 0?void 0:P.find(H=>H.name===I)},g=((s=d?.currentPlatform)===null||s===void 0?void 0:s.getPluginHeader)||p,k=I=>e.console.error(I),h=(I,P,H)=>Promise.reject(`${H} does not have an implementation of "${P}".`),j=new Map,U=(I,P={})=>{const H=j.get(I);if(H)return console.warn(`Capacitor plugin "${I}" already registered. Cannot register plugins twice.`),H.proxy;const V=m(),Q=g(I);let _;const Nt=async()=>(!_&&V in P?_=typeof P[V]=="function"?_=await P[V]():_=P[V]:o!==null&&!_&&"web"in P&&(_=typeof P.web=="function"?_=await P.web():_=P.web),_),_t=(F,T)=>{var O,W;if(Q){const Y=Q?.methods.find(q=>T===q.name);if(Y)return Y.rtype==="promise"?q=>i.nativePromise(I,T.toString(),q):(q,le)=>i.nativeCallback(I,T.toString(),q,le);if(F)return(O=F[T])===null||O===void 0?void 0:O.bind(F)}else{if(F)return(W=F[T])===null||W===void 0?void 0:W.bind(F);throw new Ce(`"${I}" plugin is not implemented on ${V}`,ne.Unimplemented)}},xe=F=>{let T;const O=(...W)=>{const Y=Nt().then(q=>{const le=_t(q,F);if(le){const ue=le(...W);return T=ue?.remove,ue}else throw new Ce(`"${I}.${F}()" is not implemented on ${V}`,ne.Unimplemented)});return F==="addListener"&&(Y.remove=async()=>T()),Y};return O.toString=()=>`${F.toString()}() { [capacitor code] }`,Object.defineProperty(O,"name",{value:F,writable:!1,configurable:!1}),O},Ke=xe("addListener"),Ve=xe("removeListener"),Bt=(F,T)=>{const O=Ke({eventName:F},T),W=async()=>{const q=await O;Ve({eventName:F,callbackId:q},T)},Y=new Promise(q=>O.then(()=>q({remove:W})));return Y.remove=async()=>{console.warn("Using addListener() without 'await' is deprecated."),await W()},Y},Ee=new Proxy({},{get(F,T){switch(T){case"$$typeof":return;case"toJSON":return()=>({});case"addListener":return Q?Bt:Ke;case"removeListener":return Ve;default:return xe(T)}}});return c[I]=Ee,j.set(I,{name:I,proxy:Ee,platforms:new Set([...Object.keys(P),...Q?[V]:[]])}),Ee},de=((r=d?.currentPlatform)===null||r===void 0?void 0:r.registerPlugin)||U;return i.convertFileSrc||(i.convertFileSrc=I=>I),i.getPlatform=m,i.handleError=k,i.isNativePlatform=w,i.isPluginAvailable=v,i.pluginMethodNoop=h,i.registerPlugin=de,i.Exception=Ce,i.DEBUG=!!i.DEBUG,i.isLoggingEnabled=!!i.isLoggingEnabled,i.platform=i.getPlatform(),i.isNative=i.isNativePlatform(),i},ta=e=>e.Capacitor=ea(e),be=ta(typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{}),ke=be.registerPlugin;be.Plugins;class jt{constructor(t){this.listeners={},this.retainedEventArguments={},this.windowListeners={},t&&(console.warn(`Capacitor WebPlugin "${t.name}" config object was deprecated in v3 and will be removed in v4.`),this.config=t)}addListener(t,n){let a=!1;this.listeners[t]||(this.listeners[t]=[],a=!0),this.listeners[t].push(n);const r=this.windowListeners[t];r&&!r.registered&&this.addWindowListener(r),a&&this.sendRetainedArgumentsForEvent(t);const o=async()=>this.removeListener(t,n);return Promise.resolve({remove:o})}async removeAllListeners(){this.listeners={};for(const t in this.windowListeners)this.removeWindowListener(this.windowListeners[t]);this.windowListeners={}}notifyListeners(t,n,a){const s=this.listeners[t];if(!s){if(a){let r=this.retainedEventArguments[t];r||(r=[]),r.push(n),this.retainedEventArguments[t]=r}return}s.forEach(r=>r(n))}hasListeners(t){return!!this.listeners[t].length}registerWindowListener(t,n){this.windowListeners[n]={registered:!1,windowEventName:t,pluginEventName:n,handler:a=>{this.notifyListeners(n,a)}}}unimplemented(t="not implemented"){return new be.Exception(t,ne.Unimplemented)}unavailable(t="not available"){return new be.Exception(t,ne.Unavailable)}async removeListener(t,n){const a=this.listeners[t];if(!a)return;const s=a.indexOf(n);this.listeners[t].splice(s,1),this.listeners[t].length||this.removeWindowListener(this.windowListeners[t])}addWindowListener(t){window.addEventListener(t.windowEventName,t.handler),t.registered=!0}removeWindowListener(t){t&&(window.removeEventListener(t.windowEventName,t.handler),t.registered=!1)}sendRetainedArgumentsForEvent(t){const n=this.retainedEventArguments[t];n&&(delete this.retainedEventArguments[t],n.forEach(a=>{this.notifyListeners(t,a)}))}}const ct=e=>encodeURIComponent(e).replace(/%(2[346B]|5E|60|7C)/g,decodeURIComponent).replace(/[()]/g,escape),dt=e=>e.replace(/(%[\dA-F]{2})+/gi,decodeURIComponent);class na extends jt{async getCookies(){const t=document.cookie,n={};return t.split(";").forEach(a=>{if(a.length<=0)return;let[s,r]=a.replace(/=/,"CAP_COOKIE").split("CAP_COOKIE");s=dt(s).trim(),r=dt(r).trim(),n[s]=r}),n}async setCookie(t){try{const n=ct(t.key),a=ct(t.value),s=`; expires=${(t.expires||"").replace("expires=","")}`,r=(t.path||"/").replace("path=",""),o=t.url!=null&&t.url.length>0?`domain=${t.url}`:"";document.cookie=`${n}=${a||""}${s}; path=${r}; ${o};`}catch(n){return Promise.reject(n)}}async deleteCookie(t){try{document.cookie=`${t.key}=; Max-Age=0`}catch(n){return Promise.reject(n)}}async clearCookies(){try{const t=document.cookie.split(";")||[];for(const n of t)document.cookie=n.replace(/^ +/,"").replace(/=.*/,`=;expires=${new Date().toUTCString()};path=/`)}catch(t){return Promise.reject(t)}}async clearAllCookies(){try{await this.clearCookies()}catch(t){return Promise.reject(t)}}}ke("CapacitorCookies",{web:()=>new na});const aa=async e=>new Promise((t,n)=>{const a=new FileReader;a.onload=()=>{const s=a.result;t(s.indexOf(",")>=0?s.split(",")[1]:s)},a.onerror=s=>n(s),a.readAsDataURL(e)}),sa=(e={})=>{const t=Object.keys(e);return Object.keys(e).map(s=>s.toLocaleLowerCase()).reduce((s,r,o)=>(s[r]=e[t[o]],s),{})},ra=(e,t=!0)=>e?Object.entries(e).reduce((a,s)=>{const[r,o]=s;let i,c;return Array.isArray(o)?(c="",o.forEach(d=>{i=t?encodeURIComponent(d):d,c+=`${r}=${i}&`}),c.slice(0,-1)):(i=t?encodeURIComponent(o):o,c=`${r}=${i}`),`${a}&${c}`},"").substr(1):null,oa=(e,t={})=>{const n=Object.assign({method:e.method||"GET",headers:e.headers},t),s=sa(e.headers)["content-type"]||"";if(typeof e.data=="string")n.body=e.data;else if(s.includes("application/x-www-form-urlencoded")){const r=new URLSearchParams;for(const[o,i]of Object.entries(e.data||{}))r.set(o,i);n.body=r.toString()}else if(s.includes("multipart/form-data")||e.data instanceof FormData){const r=new FormData;if(e.data instanceof FormData)e.data.forEach((i,c)=>{r.append(c,i)});else for(const i of Object.keys(e.data))r.append(i,e.data[i]);n.body=r;const o=new Headers(n.headers);o.delete("content-type"),n.headers=o}else(s.includes("application/json")||typeof e.data=="object")&&(n.body=JSON.stringify(e.data));return n};class ia extends jt{async request(t){const n=oa(t,t.webFetchExtra),a=ra(t.params,t.shouldEncodeUrlParams),s=a?`${t.url}?${a}`:t.url,r=await fetch(s,n),o=r.headers.get("content-type")||"";let{responseType:i="text"}=r.ok?t:{};o.includes("application/json")&&(i="json");let c,d;switch(i){case"arraybuffer":case"blob":d=await r.blob(),c=await aa(d);break;case"json":c=await r.json();break;case"document":case"text":default:c=await r.text()}const y={};return r.headers.forEach((m,b)=>{y[b]=m}),{data:c,headers:y,status:r.status,url:r.url}}async get(t){return this.request(Object.assign(Object.assign({},t),{method:"GET"}))}async post(t){return this.request(Object.assign(Object.assign({},t),{method:"POST"}))}async put(t){return this.request(Object.assign(Object.assign({},t),{method:"PUT"}))}async patch(t){return this.request(Object.assign(Object.assign({},t),{method:"PATCH"}))}async delete(t){return this.request(Object.assign(Object.assign({},t),{method:"DELETE"}))}}ke("CapacitorHttp",{web:()=>new ia});var Re;(function(e){e.Documents="DOCUMENTS",e.Data="DATA",e.Library="LIBRARY",e.Cache="CACHE",e.External="EXTERNAL",e.ExternalStorage="EXTERNAL_STORAGE"})(Re||(Re={}));var De;(function(e){e.UTF8="utf8",e.ASCII="ascii",e.UTF16="utf16"})(De||(De={}));const ca=ke("Filesystem",{web:()=>Tt(()=>import("./web-C9Xxo8wO.js"),[],import.meta.url).then(e=>new e.FilesystemWeb)}),da=ke("Share",{web:()=>Tt(()=>import("./web-CKYNAveO.js"),[],import.meta.url).then(e=>new e.ShareWeb)});function la(){return!!window.Capacitor?.isNativePlatform?.()}async function Mt(e,t,n="text/plain"){if(la()){const o=await ca.writeFile({path:e,data:t,directory:Re.Cache,encoding:De.UTF8});try{return await da.share({title:e,text:e,url:o.uri,dialogTitle:"保存或发送这个文件"}),{mode:"share"}}catch(i){return{mode:"share-failed",uri:o.uri,message:i?.message||""}}}const a=new Blob([t],{type:`${n};charset=utf-8`}),s=URL.createObjectURL(a),r=document.createElement("a");return r.href=s,r.download=e,document.body.appendChild(r),r.click(),r.remove(),setTimeout(()=>URL.revokeObjectURL(s),1e3),{mode:"download"}}function ua(e=".json,application/json"){return new Promise(t=>{const n=document.createElement("input");n.type="file",n.accept=e,n.style.display="none";let a=!1;const s=r=>{a||(a=!0,n.remove(),t(r))};n.addEventListener("change",()=>{const r=n.files?.[0];if(!r)return s(null);const o=new FileReader;o.onload=()=>s(String(o.result)),o.onerror=()=>s(null),o.readAsText(r,"utf-8")}),window.addEventListener("focus",()=>setTimeout(()=>{n.files?.length||s(null)},800),{once:!0}),document.body.appendChild(n),n.click()})}function qt(){const e=new Date,t=n=>String(n).padStart(2,"0");return`${e.getFullYear()}${t(e.getMonth()+1)}${t(e.getDate())}-${t(e.getHours())}${t(e.getMinutes())}`}const pa=["🍚","🍜","🍔","🍰","☕","🍺","🚌","🚇","🚕","⛽","🛒","👕","💄","🏠","💡","📱","🎮","🎬","✈️","🏨","💊","🏥","📚","✏️","🎓","🎁","💵","💰","💼","📈","🐱","👶","🔧","🚿","🛁","🏋️","🎵","📷","🌸","📦","💳","🏦","💎","🎯","📄","💉","🍎","🚗","🛵","🎨","🧧"];function B(e){const t=document.createElement("div");e.replaceChildren(t);const n=D(),a=Et(we(),n.id),s=n.budgetFen||0,r=l.meta.lastBackupAt||0;t.innerHTML=`
    <div class="set-group">
      <h2>账本</h2>
      <div class="set-list">
        <button type="button" class="set-row" data-act="ledgers">
          <span class="sr-ico">📒</span>
          <span class="sr-main">${u(n.name)}<span class="sr-sub">共 ${l.ledgers.length} 个账本，点这里切换</span></span>
          <span class="sr-arrow">›</span>
        </button>
        <button type="button" class="set-row" data-act="budget">
          <span class="sr-ico">🎯</span>
          <span class="sr-main">本月预算<span class="sr-sub">本月已花 ${u(x(a.expenseFen))} 元</span></span>
          <span class="sr-val">${s?u(x(s))+" 元":"未设置"}</span>
          <span class="sr-arrow">›</span>
        </button>
        <button type="button" class="set-row" data-act="rename">
          <span class="sr-ico">✏️</span>
          <span class="sr-main">重命名当前账本</span>
          <span class="sr-arrow">›</span>
        </button>
        <button type="button" class="set-row" data-act="newledger">
          <span class="sr-ico">➕</span>
          <span class="sr-main">新建账本<span class="sr-sub">比如「装修」「旅行」，数据各算各的</span></span>
          <span class="sr-arrow">›</span>
        </button>
      </div>
    </div>

    <div class="set-group">
      <h2>分类</h2>
      <div class="set-list">
        <button type="button" class="set-row" data-act="cats">
          <span class="sr-ico">🏷️</span>
          <span class="sr-main">分类管理<span class="sr-sub">新增、改名、换图标、调顺序、删除</span></span>
          <span class="sr-val">${l.categories.length} 个</span>
          <span class="sr-arrow">›</span>
        </button>
      </div>
    </div>

    <div class="set-group">
      <h2>数据</h2>
      <div class="set-list">
        <button type="button" class="set-row" data-act="csv">
          <span class="sr-ico">📊</span>
          <span class="sr-main">导出当前账本为 CSV<span class="sr-sub">Excel / WPS 能直接打开</span></span>
          <span class="sr-arrow">›</span>
        </button>
        <button type="button" class="set-row" data-act="backup">
          <span class="sr-ico">💾</span>
          <span class="sr-main">导出完整备份<span class="sr-sub">所有账本、分类、预算，一个文件全带走</span></span>
          <span class="sr-val">${u(ma(r))}</span>
          <span class="sr-arrow">›</span>
        </button>
        <button type="button" class="set-row" data-act="restore">
          <span class="sr-ico">📥</span>
          <span class="sr-main">从备份恢复<span class="sr-sub" style="color:var(--danger)">会覆盖现在的全部数据</span></span>
          <span class="sr-arrow">›</span>
        </button>
        <button type="button" class="set-row" data-act="wipe">
          <span class="sr-ico">🗑️</span>
          <span class="sr-main" style="color:var(--danger)">清空所有数据</span>
          <span class="sr-arrow">›</span>
        </button>
      </div>
      <p class="muted" style="margin:10px 6px 0">
        数据全部存在这台手机里，不联网、不上传。换手机或者怕丢，记得定期「导出完整备份」，把文件存到网盘或发给自己。
      </p>
    </div>

    <div class="set-group">
      <h2>关于</h2>
      <div class="set-list">
        <div class="set-row" style="cursor:default">
          <span class="sr-ico">ℹ️</span>
          <span class="sr-main">记账本<span class="sr-sub">本地版 v${u(Wt)} · 记录 ${l.transactions.length} 笔</span></span>
        </div>
      </div>
    </div>
  `,t.addEventListener("click",async o=>{const i=o.target.closest("[data-act]");if(!i)return;const c=i.dataset.act,d=()=>B(e);if(c==="ledgers")return fa(e);if(c==="budget")return va(e);if(c==="rename")return ya(e);if(c==="newledger")return ga(e);if(c==="cats")return ha(e);if(c==="csv")return wa();if(c==="backup")return $a(d);if(c==="restore")return ka(d);if(c==="wipe")return xa(d)})}function ma(e){if(!e)return"还没有备份";const t=Ne(K(new Date(e)),K(new Date));return t<=0?"今天刚备份":t===1?"昨天备份":`${t} 天前备份`}function fa(e){const t=l.ledgers.map(a=>`<button type="button" class="set-row" data-id="${a.id}">
        <span class="sr-ico">${a.id===l.meta.currentLedgerId?"✅":"📒"}</span>
        <span class="sr-main">${u(a.name)}
          <span class="sr-sub">${l.transactions.filter(s=>s.ledgerId===a.id).length} 笔${a.budgetFen?" · 预算 "+u(x(a.budgetFen)):""}</span>
        </span>
        ${l.ledgers.length>1?`<span class="sr-val" data-del="${a.id}">删除</span>`:""}
      </button>`).join(""),n=N({title:"选择账本",body:`<div class="set-list">${t}</div>
      <p class="muted" style="margin-top:12px">每个账本的记录和统计互相独立，切换后首页、账单、统计都会跟着变。</p>`});n.body.addEventListener("click",async a=>{const s=a.target.closest("[data-del]");if(s){a.stopPropagation();const o=l.ledgers.find(d=>d.id===s.dataset.del),i=l.transactions.filter(d=>d.ledgerId===o.id).length;if(!await te({title:`删除「${o.name}」？`,message:i?`这个账本里有 ${i} 笔记录，会一起删掉，删了没法恢复。`:"这个账本还是空的，删掉不影响别的账本。",okText:"删除",danger:!0}))return;try{await sn(o.id),E("已删除账本"),n.close(),B(e)}catch(d){E(d.message)}return}const r=a.target.closest("[data-id]");r&&(await Ue(r.dataset.id),E("已切换账本"),n.close(),B(e))})}function ga(e){const t=N({title:"新建账本",body:`<div class="field-grid">
      <div class="field"><span class="field-label">名字</span>
        <input type="text" data-role="name" maxlength="12" placeholder="例如：装修" /></div>
      <div class="field"><span class="field-label">预算</span>
        <input type="text" inputmode="decimal" data-role="budget" placeholder="选填，每月支出上限" /></div>
    </div>
    <p class="muted" style="margin-top:10px">预算可以以后再设，先建账本也行。</p>`,actions:[{label:"取消",className:"btn-outline",onClick:n=>n.close()},{label:"创建",className:"btn-primary",onClick:async n=>{const a=n.body.querySelector('[data-role="name"]').value.trim(),s=n.body.querySelector('[data-role="budget"]').value.trim();if(!a)return E("给账本起个名字");let r=0;if(s){const i=he(s);if(i===null||i<0)return E("预算填个数字就行，比如 3000");r=i}const o=await an(a,r);await Ue(o.id),E(`已创建「${a}」并切过去了`),n.close(),B(e)}}]});setTimeout(()=>t.body.querySelector('[data-role="name"]')?.focus(),120)}function ya(e){const t=D(),n=N({title:"重命名账本",body:`<div class="field-grid">
      <div class="field"><span class="field-label">名字</span>
        <input type="text" data-role="name" maxlength="12" value="${u(t.name)}" /></div>
    </div>`,actions:[{label:"取消",className:"btn-outline",onClick:a=>a.close()},{label:"保存",className:"btn-primary",onClick:async a=>{const s=a.body.querySelector('[data-role="name"]').value.trim();if(!s)return E("名字不能是空的");await je(t.id,{name:s}),E("已改名"),a.close(),B(e)}}]});setTimeout(()=>n.body.querySelector('[data-role="name"]')?.select(),120)}function va(e){const t=D(),n=N({title:"本月预算",body:`<div class="field-grid">
      <div class="field"><span class="field-label">金额</span>
        <input type="text" inputmode="decimal" data-role="amount"
               placeholder="比如 3000，填 0 表示不设预算"
               value="${t.budgetFen?u(ut(t.budgetFen)):""}" /></div>
    </div>
    <p class="muted" style="margin-top:10px">这是每个月总的支出上限，花到 80% 会提醒你。</p>`,actions:[{label:"取消",className:"btn-outline",onClick:a=>a.close()},{label:"保存",className:"btn-primary",onClick:async a=>{const s=a.body.querySelector('[data-role="amount"]').value.trim();if(!s)return await je(t.id,{budgetFen:0}),E("已取消预算"),a.close(),B(e);const r=he(s);if(r===null)return E("填数字就行，比如 3000");await je(t.id,{budgetFen:r}),E(r?`预算设为 ${x(r)} 元`:"已取消预算"),a.close(),B(e)}}]});setTimeout(()=>n.body.querySelector('[data-role="amount"]')?.focus(),120)}function ba(e,t){const n=`${e} 笔记录在用`;if(!t)return n;const a=(t.ratio*100).toFixed(0);return`${n} · 本月 ${x(t.spentFen)} / ${x(t.budgetFen)} 元（${a}%）`}function ha(e,t="expense"){const n=N({title:"分类管理",body:`
      <div class="seg" data-role="seg" style="margin-bottom:12px">
        <button type="button" data-kind="expense">支出分类</button>
        <button type="button" data-kind="income">收入分类</button>
      </div>
      <div data-role="list"></div>
      <button type="button" class="btn btn-outline btn-block" data-role="add" style="margin-top:14px">➕ 新增分类</button>
      <p class="muted" style="margin-top:12px">↑↓ 调整分类在记账页的排列顺序。点分类可以改名、换图标，也可以给支出分类设月预算。删掉分类不会删掉记录，那些记录会显示成「未分类」。</p>`});function a(){const s=re(t),r=t==="expense"?Lt(we()):new Map;n.body.querySelectorAll('[data-role="seg"] button').forEach(i=>{i.classList.toggle("active",i.dataset.kind===t)});const o=n.body.querySelector('[data-role="list"]');o.innerHTML=`<div class="set-list">${s.map((i,c)=>{const d=wt(i.id),y=r.get(i.id);return`<div class="cat-row">
          <button type="button" class="cat-row-main" data-cat="${i.id}">
            <span class="cm-emoji">${u(i.emoji)}</span>
            <span class="cm-body">
              <div class="cm-name">${u(i.name)}</div>
              <div class="cm-sub ${y?y.level:""}">${ba(d,y)}</div>
            </span>
          </button>
          <span class="cm-tools">
            <button type="button" class="mini-btn" data-up="${i.id}" ${c===0?"disabled":""} aria-label="上移">↑</button>
            <button type="button" class="mini-btn" data-down="${i.id}" ${c===s.length-1?"disabled":""} aria-label="下移">↓</button>
          </span>
        </div>`}).join("")}</div>`,o.querySelectorAll("[data-cat]").forEach(i=>{i.addEventListener("click",()=>lt(l.categories.find(c=>c.id===i.dataset.cat),()=>a()))}),o.querySelectorAll("[data-up], [data-down]").forEach(i=>{i.addEventListener("click",async()=>{const c=i.dataset.up?-1:1,d=i.dataset.up||i.dataset.down;await on(d,c)&&a()})})}n.body.querySelectorAll('[data-role="seg"] button').forEach(s=>{s.addEventListener("click",()=>{t=s.dataset.kind,a()})}),n.body.querySelector('[data-role="add"]').addEventListener("click",()=>{lt(null,()=>{n.close(),B(e)},e,t)}),a()}function lt(e,t,n,a="expense"){const s=!e;let r=e?.emoji??"📦",o=e?.kind??a;const i=N({title:s?"新增分类":"编辑分类",body:`
      <div class="field-grid">
        <div class="field"><span class="field-label">名称</span>
          <input type="text" data-role="name" maxlength="6" value="${u(e?.name??"")}" placeholder="最多 6 个字" /></div>
        <div class="field"><span class="field-label">类型</span>
          <select data-role="kind">
            <option value="expense" ${o==="expense"?"selected":""}>支出</option>
            <option value="income" ${o==="income"?"selected":""}>收入</option>
          </select></div>
        <div class="field" data-role="budget-field" ${o==="expense"?"":"hidden"}>
          <span class="field-label">月预算</span>
          <input type="text" inputmode="decimal" data-role="budget" placeholder="选填，比如 1000"
                 value="${e?.budgetFen?u(ut(e.budgetFen)):""}" /></div>
      </div>
      <p class="muted" data-role="budget-hint" style="margin-top:10px" ${o==="expense"?"":"hidden"}>
        月预算是这个分类每月的支出上限。记账页的分类格上会显示进度，花到八成变黄、超支变红。留空或填 0 就是不设。
      </p>
      <p class="card-title" style="margin:16px 0 8px">选个图标</p>
      <div class="emoji-grid" data-role="emojis">
        ${pa.map(c=>`<button type="button" data-e="${c}" class="${c===r?"active":""}">${c}</button>`).join("")}
      </div>
      ${s?"":'<div class="divider"></div><button type="button" class="btn btn-danger btn-block" data-role="del">删除这个分类</button>'}`,actions:[{label:"取消",className:"btn-outline",onClick:c=>c.close()},{label:s?"创建":"保存",className:"btn-primary",onClick:async c=>{const d=c.body.querySelector('[data-role="name"]').value.trim();if(!d)return E("给分类起个名字");const y=c.body.querySelector('[data-role="kind"]').value,m=c.body.querySelector('[data-role="budget"]').value.trim();let b=0;if(y==="expense"&&m){const w=he(m);if(w===null||w<0)return E("月预算填个数字就行，比如 1000");b=w}s?(await rn(y,d,r,b),E(b?`分类已添加，月预算 ${x(b)} 元`:"分类已添加")):(await cn(e.id,{name:d,emoji:r,kind:y,budgetFen:b}),E(b?`已保存，月预算 ${x(b)} 元`:"已保存")),c.close(),t?.()}}]});i.body.querySelector('[data-role="kind"]').addEventListener("change",c=>{const d=c.target.value==="expense";i.body.querySelector('[data-role="budget-field"]').hidden=!d,i.body.querySelector('[data-role="budget-hint"]').hidden=!d}),i.body.querySelector('[data-role="emojis"]').addEventListener("click",c=>{const d=c.target.closest("[data-e]");d&&(r=d.dataset.e,i.body.querySelectorAll("[data-e]").forEach(y=>y.classList.toggle("active",y===d)))}),i.body.querySelector('[data-role="del"]')?.addEventListener("click",async()=>{const c=wt(e.id);await te({title:`删除「${e.name}」？`,message:c?`有 ${c} 笔记录在用这个分类。删掉分类不会删记录，但那些记录会变成「未分类」。`:"这个分类还没被用过，可以放心删。",okText:"删除",danger:!0})&&(await dn(e.id),E("已删除"),i.close(),t?.())}),setTimeout(()=>i.body.querySelector('[data-role="name"]')?.focus(),120)}function Rt(e){return e.mode==="download"?"已导出，去「下载」或「文件」里找":e.mode==="share-failed"?"文件已生成，但发送面板没弹出来："+(e.message||"系统限制"):"已导出，选个地方保存吧"}async function wa(){const e=D(),t=$n(e.id),n=t.split(`\r
`).length-1;if(!n)return E("这个账本还没有记录，导出来是空的");const a=`${e.name}-${qt()}.csv`;try{const s=await Mt(a,"\uFEFF"+t,"text/csv");E(`${s.mode==="download"?`已导出 ${n} 条，`:""}${Rt(s)}`)}catch(s){E("导出失败："+(s.message||"未知原因"))}}async function $a(e){if(!l.transactions.length)return E("还没有数据可以备份");const t=`记账备份-${qt()}.json`;try{const n=await Mt(t,JSON.stringify(wn(),null,2),"application/json");await ae("lastBackupAt",Date.now()),E(Rt(n)),e?.()}catch(n){E("导出失败："+(n.message||"未知原因"))}}async function ka(e){let t=null;if(!await te({title:"从备份恢复？",message:`导入后，现在手机里的所有记录、账本、分类都会被备份文件里的内容替换掉，换不回来。

建议先「导出完整备份」存一份再操作。`,okText:"继续选择文件",danger:!0,onOk:()=>{t=ua()}})||!t)return;const a=await t;if(a==null)return;let s;try{s=JSON.parse(a)}catch{return Pe({title:"这个文件读不了",message:`它看起来不是备份文件，可能选错了。
请选之前用「导出完整备份」生成的那个 .json 文件。`})}try{const r=await xn(s);await ae("lastBackupAt",Date.now()),await Pe({title:"恢复完成",message:`成功导入 ${r} 笔记录。`}),e()}catch(r){await Pe({title:"恢复失败",message:r.message})}}async function xa(e){!await te({title:"清空所有数据？",message:`现在一共有 ${l.transactions.length} 笔记录、${l.ledgers.length} 个账本。
清空之后全部消失，没法恢复。`,okText:"我确定",danger:!0})||!await te({title:"最后确认一次",message:"真的要清空吗？建议先在电脑上导出一份备份放着。",okText:"清空",danger:!0})||(await S.clearAll(),await Be(),E("已清空"),e())}const Ea={record:"记账",list:"账单",stats:"统计",settings:"设置"},Dt=document.getElementById("view"),La=document.getElementById("pageTitle"),Sa=document.getElementById("ledgerName"),Ia={record:Pt,list:A,stats:z,settings:B},Oe={};let se=null;function Ot(){Sa.textContent=D()?.name??""}function oe(){const e=He();se&&se!==e&&(Oe[se]=window.scrollY);const t=se===e?window.scrollY:Oe[e]||0;se=e,La.textContent=Ea[e],Ot(),document.querySelectorAll(".tab").forEach(n=>n.classList.toggle("active",n.dataset.tab===e)),Ia[e](Dt),window.scrollTo(0,t)}nn(Ot);document.addEventListener("touchstart",()=>{},{passive:!0});function Ge(){const e=l.meta.theme,t=e?e==="dark":window.matchMedia("(prefers-color-scheme: dark)").matches;document.documentElement.dataset.theme=t?"dark":"light",document.querySelector('meta[name="theme-color"]')?.setAttribute("content",t?"#1d2027":"#3b7dd8")}document.getElementById("themeToggle").addEventListener("click",async()=>{const e=document.documentElement.dataset.theme==="dark"?"light":"dark";await ae("theme",e),Ge()});window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change",()=>{l.meta.theme||Ge()});document.getElementById("ledgerSwitch").addEventListener("click",()=>{const e=l.ledgers.map(n=>({value:n.id,label:n.name,emoji:n.id===l.meta.currentLedgerId?"✅":"📒",sub:`${l.transactions.filter(a=>a.ledgerId===n.id).length} 笔`})),t=N({title:"切换账本",body:`<div class="set-list">${e.map(n=>`<button type="button" class="set-row" data-id="${n.value}">
          <span class="sr-ico">${n.emoji}</span>
          <span class="sr-main">${u(n.label)}<span class="sr-sub">${n.sub}</span></span>
        </button>`).join("")}</div>
    <p class="muted" style="margin-top:12px">要新建或删除账本，去「设置 → 账本」。</p>`});t.body.addEventListener("click",async n=>{const a=n.target.closest("[data-id]");a&&(await Ue(a.dataset.id),t.close(),E("已切换账本"),Ye(),oe())})});document.querySelectorAll(".tab").forEach(e=>{e.addEventListener("click",()=>{const t=e.dataset.tab;t==="list"&&Ye(),t===He()?(Oe[t]=0,oe()):We(t)})});Fn(oe);const Pa=!!window.Capacitor?.isNativePlatform?.();"serviceWorker"in navigator&&(Pa?navigator.serviceWorker.getRegistrations?.().then(e=>e.forEach(t=>t.unregister())).catch(()=>{}):window.addEventListener("load",()=>{navigator.serviceWorker.register("./sw.js").catch(()=>{})}));async function Fa(){try{await Be()}catch(e){Dt.innerHTML=`<div class="empty"><span class="empty-ico">😵</span>
      数据打不开了：${u(e.message)}<br /><br />
      可以试试刷新页面。如果还是不行，可能是浏览器禁用了本地存储。</div>`;return}Ge(),Ye(),oe(),window.addEventListener("focus",()=>{He()==="list"&&oe()})}Fa();export{De as E,jt as W,oa as b};
