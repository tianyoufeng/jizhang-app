(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))a(s);new MutationObserver(s=>{for(const r of s)if(r.type==="childList")for(const i of r.addedNodes)i.tagName==="LINK"&&i.rel==="modulepreload"&&a(i)}).observe(document,{childList:!0,subtree:!0});function n(s){const r={};return s.integrity&&(r.integrity=s.integrity),s.referrerPolicy&&(r.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?r.credentials="include":s.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function a(s){if(s.ep)return;s.ep=!0;const r=n(s);fetch(s.href,r)}})();const bt="jizhang",ht=1,Be=["transactions","categories","ledgers","meta"];let ie=null;function ce(){return ie||(ie=new Promise((e,t)=>{const n=indexedDB.open(bt,ht);n.onupgradeneeded=()=>{const a=n.result;if(!a.objectStoreNames.contains("transactions")){const s=a.createObjectStore("transactions",{keyPath:"id"});s.createIndex("ledgerId","ledgerId"),s.createIndex("ledger_date",["ledgerId","date"])}a.objectStoreNames.contains("categories")||a.createObjectStore("categories",{keyPath:"id"}).createIndex("ledgerId","ledgerId"),a.objectStoreNames.contains("ledgers")||a.createObjectStore("ledgers",{keyPath:"id"}),a.objectStoreNames.contains("meta")||a.createObjectStore("meta",{keyPath:"key"})},n.onsuccess=()=>e(n.result),n.onerror=()=>t(n.error)}),ie)}function we(e,t){return ce().then(n=>n.transaction(e,t).objectStore(e))}function $e(e){return new Promise((t,n)=>{e.onsuccess=()=>t(e.result),e.onerror=()=>n(e.error)})}const $={async getAll(e){const t=await we(e,"readonly");return $e(t.getAll())},async put(e,t){const n=await we(e,"readwrite");return $e(n.put(t))},async putMany(e,t){if(!t.length)return;const n=await ce();return new Promise((a,s)=>{const r=n.transaction(e,"readwrite"),i=r.objectStore(e);t.forEach(o=>i.put(o)),r.oncomplete=()=>a(),r.onerror=()=>s(r.error),r.onabort=()=>s(r.error)})},async remove(e,t){const n=await we(e,"readwrite");return $e(n.delete(t))},async removeMany(e,t){if(!t.length)return;const n=await ce();return new Promise((a,s)=>{const r=n.transaction(e,"readwrite"),i=r.objectStore(e);t.forEach(o=>i.delete(o)),r.oncomplete=()=>a(),r.onerror=()=>s(r.error)})},async clearAll(){const e=await ce();return new Promise((t,n)=>{const a=e.transaction(Be,"readwrite");Be.forEach(s=>a.objectStore(s).clear()),a.oncomplete=()=>t(),a.onerror=()=>n(a.error)})}};function K(){return Date.now().toString(36)+Math.random().toString(36).slice(2,8)}const wt="1.2";function Je(e){const t=e<0,n=Math.abs(e),a=Math.floor(n/100),s=n%100;return(t?"-":"")+a+(s?"."+String(s).padStart(2,"0"):"")}function y(e){const t=e<0,n=Math.abs(e),a=Math.floor(n/100),s=n%100,r=a.toLocaleString("en-US"),i=s?`${r}.${String(s).padStart(2,"0")}`:`${r}.00`;return(t?"-":"")+i}function ge(e){const t=String(e).trim();if(!t||!/^\d*(\.\d{0,2})?$/.test(t))return null;const n=Number(t);return Number.isFinite(n)?Math.round(n*100):null}function Z(){return le(new Date)}function le(e){const t=e.getFullYear(),n=String(e.getMonth()+1).padStart(2,"0"),a=String(e.getDate()).padStart(2,"0");return`${t}-${n}-${a}`}function _e(e=0){const t=new Date;return t.setDate(t.getDate()-e),le(t)}function Xe(e,t){const n=a=>{const[s,r,i]=String(a).split("-").map(Number);return new Date(s,r-1,i).getTime()};return Math.round((n(t)-n(e))/864e5)}function H(e){return String(e).slice(0,7)}function I(){return Z().slice(0,7)}function V(e,t){const[n,a]=e.split("-").map(Number),s=new Date(n,a-1+t,1);return`${s.getFullYear()}-${String(s.getMonth()+1).padStart(2,"0")}`}function Ue(e){const[t,n,a]=e.split("-").map(Number),s=new Date(t,n-1,a),r=["周日","周一","周二","周三","周四","周五","周六"][s.getDay()];return`${n}月${a}日 ${r}`}function ue(e){const[t,n]=e.split("-").map(Number),a=new Date().getFullYear();return t===a?`${n}月`:`${t}年${n}月`}function u(e){return String(e??"").replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t])}const He=["#3b7dd8","#e0575b","#26a06a","#e0a32e","#8b5cf6","#12a5b8","#e0669a","#7a8b3f","#c2743a","#5a6b8c"];function We(e){return He[e%He.length]}function me(e,t){return e.reduce((n,a)=>n+t(a),0)}function $t(e){const t=me(e.filter(a=>a.kind==="income"),a=>a.amountFen),n=me(e.filter(a=>a.kind==="expense"),a=>a.amountFen);return{incomeFen:t,expenseFen:n,balanceFen:t-n}}const Qe=[{kind:"expense",name:"餐饮",emoji:"🍚"},{kind:"expense",name:"交通",emoji:"🚌"},{kind:"expense",name:"购物",emoji:"🛒"},{kind:"expense",name:"房租水电",emoji:"🏠"},{kind:"expense",name:"娱乐",emoji:"🎮"},{kind:"expense",name:"医疗",emoji:"💊"},{kind:"expense",name:"学习",emoji:"📚"},{kind:"expense",name:"人情",emoji:"🎁"},{kind:"expense",name:"其他",emoji:"📦"},{kind:"income",name:"工资",emoji:"💰"},{kind:"income",name:"红包",emoji:"💵"},{kind:"income",name:"理财",emoji:"📈"},{kind:"income",name:"兼职",emoji:"💼"},{kind:"income",name:"其他",emoji:"📦"}],kt="日常账本",l={ledgers:[],categories:[],transactions:[],meta:{},loaded:!1};async function je(){const[e,t,n,a]=await Promise.all([$.getAll("ledgers"),$.getAll("categories"),$.getAll("transactions"),$.getAll("meta")]);if(l.ledgers=e.sort(Ee),l.categories=t.sort(Ee),l.transactions=n,l.meta=Object.fromEntries(a.map(s=>[s.key,s.value])),!l.ledgers.length){const s={id:K(),name:kt,budgetFen:0,order:0,createdAt:Date.now()};l.ledgers=[s],await $.put("ledgers",s),l.meta.currentLedgerId=s.id,await $.put("meta",{key:"currentLedgerId",value:s.id})}l.categories.length||(l.categories=Qe.map((s,r)=>({id:K(),kind:s.kind,name:s.name,emoji:s.emoji,order:r})),await $.putMany("categories",l.categories)),(!l.meta.currentLedgerId||!l.ledgers.some(s=>s.id===l.meta.currentLedgerId))&&(l.meta.currentLedgerId=l.ledgers[0].id,await $.put("meta",{key:"currentLedgerId",value:l.meta.currentLedgerId})),l.loaded=!0}function Ee(e,t){return(e.order??0)-(t.order??0)}async function X(e,t){l.meta[e]=t,await $.put("meta",{key:e,value:t})}function M(){return l.ledgers.find(e=>e.id===l.meta.currentLedgerId)||l.ledgers[0]}const Le=new Set;function xt(e){return Le.add(e),()=>Le.delete(e)}function fe(){const e=M();Le.forEach(t=>t(e))}async function Me(e){l.ledgers.some(t=>t.id===e)&&(await X("currentLedgerId",e),fe())}async function Et(e,t=0){const n={id:K(),name:e.trim(),budgetFen:t,order:l.ledgers.length,createdAt:Date.now()};return l.ledgers.push(n),await $.put("ledgers",n),n}async function Se(e,t){const n=l.ledgers.find(a=>a.id===e);n&&(Object.assign(n,t),await $.put("ledgers",n),fe())}async function Lt(e){if(l.ledgers.length<=1)throw new Error("至少要保留一个账本");const t=l.transactions.filter(n=>n.ledgerId===e);l.transactions=l.transactions.filter(n=>n.ledgerId!==e),l.ledgers=l.ledgers.filter(n=>n.id!==e),await $.removeMany("transactions",t.map(n=>n.id)),await $.remove("ledgers",e),l.meta.currentLedgerId===e&&await X("currentLedgerId",l.ledgers[0].id),fe()}function ee(e){return l.categories.filter(t=>t.kind===e).sort(Ee)}function W(e){return l.categories.find(t=>t.id===e)}async function St(e,t,n,a=0){const s=l.categories.filter(i=>i.kind===e),r={id:K(),kind:e,name:t.trim(),emoji:n||"📦",order:s.reduce((i,o)=>Math.max(i,o.order??0),-1)+1};return e==="expense"&&a>0&&(r.budgetFen=a),l.categories.push(r),await $.put("categories",r),r}async function Ft(e,t){const n=W(e);if(!n)return!1;const a=ee(n.kind),s=a.findIndex(i=>i.id===e),r=s+t;return s<0||r<0||r>=a.length?!1:(a.splice(r,0,a.splice(s,1)[0]),await Promise.all(a.map((i,o)=>(i.order=o,$.put("categories",i)))),!0)}async function It(e,t){const n=W(e);n&&(Object.assign(n,t),(n.kind==="income"||!(n.budgetFen>0))&&delete n.budgetFen,await $.put("categories",n))}function Ze(e){return l.transactions.filter(t=>t.categoryId===e).length}async function Pt(e){l.categories=l.categories.filter(t=>t.id!==e),await $.remove("categories",e)}function ae(e=l.meta.currentLedgerId){return l.transactions.filter(t=>t.ledgerId===e)}async function et(e){const t=Date.now(),n={id:K(),ledgerId:e.ledgerId,kind:e.kind,amountFen:e.amountFen,categoryId:e.categoryId,date:e.date,note:e.note||"",createdAt:t,updatedAt:t};return l.transactions.push(n),await $.put("transactions",n),n}async function Ct(e,t){const n=l.transactions.find(a=>a.id===e);n&&(Object.assign(n,t,{updatedAt:Date.now()}),await $.put("transactions",n))}async function At(e){const t=l.transactions.find(n=>n.id===e)||null;return l.transactions=l.transactions.filter(n=>n.id!==e),await $.remove("transactions",e),t}async function jt(e){e&&(l.transactions.some(t=>t.id===e.id)||(l.transactions.push(e),await $.put("transactions",e)))}function Mt(e,t=l.meta.currentLedgerId,{categoryId:n="",keyword:a="",scope:s="month"}={}){const r=a.trim().toLowerCase();return ae(t).filter(i=>s==="all"||H(i.date)===e).filter(i=>!n||i.categoryId===n).filter(i=>{if(!r)return!0;const o=W(i.categoryId);return(i.note||"").toLowerCase().includes(r)||(o?.name||"").toLowerCase().includes(r)}).sort((i,o)=>i.date===o.date?o.createdAt-i.createdAt:o.date.localeCompare(i.date))}function te(e,t=l.meta.currentLedgerId){const n=ae(t).filter(r=>H(r.date)===e),a=n.filter(r=>r.kind==="income").reduce((r,i)=>r+i.amountFen,0),s=n.filter(r=>r.kind==="expense").reduce((r,i)=>r+i.amountFen,0);return{incomeFen:a,expenseFen:s,balanceFen:a-s,count:n.length}}function tt(e,t,n=l.meta.currentLedgerId){const a=new Map;for(const s of ae(n)){if(s.kind!==t||H(s.date)!==e)continue;const r=a.get(s.categoryId)||{amountFen:0,count:0};r.amountFen+=s.amountFen,r.count+=1,a.set(s.categoryId,r)}return a}function Tt(e,t,n=l.meta.currentLedgerId){const a=tt(e,t,n),s=[...a.values()].reduce((r,i)=>r+i.amountFen,0);return{total:s,items:[...a.entries()].map(([r,i])=>{const o=W(r);return{categoryId:r,amountFen:i.amountFen,count:i.count,name:o?.name??"未分类",emoji:o?.emoji??"❓",pct:s?i.amountFen/s:0}}).sort((r,i)=>i.amountFen-r.amountFen)}}const qt=.8;function nt(e=I(),t=l.meta.currentLedgerId){const n=tt(e,"expense",t),a=new Map;for(const s of l.categories){if(s.kind!=="expense")continue;const r=s.budgetFen||0;if(r<=0)continue;const i=n.get(s.id)?.amountFen??0,o=i/r;a.set(s.id,{budgetFen:r,spentFen:i,leftFen:r-i,ratio:o,level:o>=1?"over":o>=qt?"warn":"ok"})}return a}function Ot(e,t=l.meta.currentLedgerId){return e.map(n=>({month:n,...te(n,t)}))}function Rt(e=l.meta.currentLedgerId){const t=ae(e);return t.length?t.reduce((n,a)=>H(a.date)<n?H(a.date):n,H(t[0].date)):I()}function Dt(){return{app:"jizhang",version:1,exportedAt:new Date().toISOString(),ledgers:l.ledgers,categories:l.categories,transactions:l.transactions,meta:{currentLedgerId:l.meta.currentLedgerId}}}function Nt(e=l.meta.currentLedgerId){const t=l.ledgers.find(a=>a.id===e),n=[["日期","类型","分类","金额(元)","备注","账本"]];return ae(e).slice().sort((a,s)=>a.date.localeCompare(s.date)||a.createdAt-s.createdAt).forEach(a=>{n.push([a.date,a.kind==="expense"?"支出":"收入",W(a.categoryId)?.name??"未分类",(a.amountFen/100).toFixed(2),a.note||"",t?.name??""])}),n.map(a=>a.map(Bt).join(",")).join(`\r
`)}function Bt(e){const t=String(e??"");return/[",\r\n]/.test(t)?`"${t.replace(/"/g,'""')}"`:t}async function _t(e){if(!e||e.app!=="jizhang")throw new Error("这不是本 App 导出的备份文件");if(!Array.isArray(e.ledgers)||!Array.isArray(e.transactions))throw new Error("备份文件内容不完整，可能传坏了");const t=e.ledgers;if(!t.length)throw new Error("备份文件里没有账本");if(!t.every(Ht))throw new Error("备份文件里的账本信息不完整");if(!e.transactions.every(Yt))throw new Error("备份文件里有读不懂的记录");const n=Array.isArray(e.categories)?e.categories.filter(Wt):[],a=n.length?n:Ut(),s=e.meta?.currentLedgerId,r=t.some(o=>o.id===s)?s:t[0].id,i={...l.meta};return delete i.currentLedgerId,await $.clearAll(),await $.putMany("ledgers",t),await $.putMany("categories",a),await $.putMany("transactions",e.transactions),await $.put("meta",{key:"currentLedgerId",value:r}),await $.putMany("meta",Object.entries(i).map(([o,c])=>({key:o,value:c}))),await Gt(),fe(),e.transactions.length}function Ut(){return Qe.map((e,t)=>({id:K(),kind:e.kind,name:e.name,emoji:e.emoji,order:t}))}function Ht(e){return e&&typeof e.id=="string"&&typeof e.name=="string"}function Wt(e){return e&&typeof e.id=="string"&&typeof e.name=="string"&&(e.kind==="expense"||e.kind==="income")}function Yt(e){return e&&typeof e.id=="string"&&typeof e.date=="string"&&Number.isFinite(e.amountFen)}async function Gt(){l.loaded=!1,await je()}const Fe=new Set;let Ie="record";function Te(){return Ie}function Vt(e){return Fe.add(e),()=>Fe.delete(e)}function qe(e){e!==Ie&&(Ie=e,Fe.forEach(t=>t(e)))}function h(e,{ms:t=2e3,actionLabel:n="",onAction:a=null}={}){const s=document.getElementById("toastRoot");if(!s)return{dismiss(){}};const r=document.createElement("div");r.className="toast";const i=document.createElement("span");i.textContent=e,r.appendChild(i);let o=null;const c=()=>{clearTimeout(o),r.style.transition="opacity .25s",r.style.opacity="0",setTimeout(()=>r.remove(),260)};if(n){const d=document.createElement("button");d.type="button",d.className="toast-action",d.textContent=n,d.addEventListener("click",()=>{c(),a?.()}),r.appendChild(d)}return s.appendChild(r),o=setTimeout(c,t),{dismiss:c}}function N({title:e="",body:t="",actions:n=[]}={}){const a=document.getElementById("sheetRoot"),s=document.createElement("div");s.className="sheet-mask",s.innerHTML=`
    <div class="sheet" role="dialog" aria-modal="true">
      <div class="sheet-grip"></div>
      ${e?`<h3>${u(e)}</h3>`:""}
      <div class="sheet-body"></div>
      ${n.length?'<div class="sheet-actions"></div>':""}
    </div>`;const r=s.querySelector(".sheet-body");typeof t=="string"?r.innerHTML=t:r.appendChild(t);const i={el:s,body:r,close(){s.style.animation="fade .15s reverse",setTimeout(()=>s.remove(),140)}};if(n.length){const o=s.querySelector(".sheet-actions");n.forEach(c=>{const d=document.createElement("button");d.type="button",d.className=`btn ${c.className||""}`,d.textContent=c.label,c.disabled&&(d.disabled=!0),d.addEventListener("click",()=>c.onClick?.(i)),o.appendChild(d)})}return s.addEventListener("click",o=>{o.target===s&&i.close()}),a.appendChild(s),i}function z({title:e="确认",message:t="",okText:n="确定",cancelText:a="取消",danger:s=!1,onOk:r}={}){return new Promise(i=>{const o=document.getElementById("dialogRoot"),c=document.createElement("div");c.className="dialog-mask",c.innerHTML=`
      <div class="dialog" role="alertdialog" aria-modal="true">
        <h3>${u(e)}</h3>
        <p>${u(t)}</p>
        <div class="dialog-actions">
          <button type="button" class="btn btn-outline" data-act="cancel">${u(a)}</button>
          <button type="button" class="btn ${s?"btn-danger":"btn-primary"}" data-act="ok">${u(n)}</button>
        </div>
      </div>`;const d=m=>{c.remove(),i(m)};c.querySelector('[data-act="cancel"]').addEventListener("click",()=>d(!1)),c.querySelector('[data-act="ok"]').addEventListener("click",()=>{r?.(),d(!0)}),c.addEventListener("click",m=>{m.target===c&&d(!1)}),o.appendChild(c)})}function ke({title:e="提示",message:t=""}={}){return new Promise(n=>{const a=document.getElementById("dialogRoot"),s=document.createElement("div");s.className="dialog-mask",s.innerHTML=`
      <div class="dialog" role="alertdialog" aria-modal="true">
        <h3>${u(e)}</h3>
        <p>${u(t)}</p>
        <div class="dialog-actions">
          <button type="button" class="btn btn-primary" data-act="ok">知道了</button>
        </div>
      </div>`;const r=()=>{s.remove(),n()};s.querySelector('[data-act="ok"]').addEventListener("click",r),s.addEventListener("click",i=>{i.target===s&&r()}),a.appendChild(s)})}function Kt(e){let t=String(e).replace(/[^\d.]/g,"");const n=t.indexOf(".");if(n!==-1){t=t.slice(0,n+1)+t.slice(n+1).replace(/\./g,"");const[a,s=""]=t.split(".");t=`${a}.${s.slice(0,2)}`}return t}function zt(e,t){return t.level==="over"?`${e.name}：本月已花 ${y(t.spentFen)} 元，超预算 ${y(-t.leftFen)} 元（预算 ${y(t.budgetFen)} 元）`:`${e.name}：本月已花 ${y(t.spentFen)} 元，预算 ${y(t.budgetFen)} 元，还剩 ${y(t.leftFen)} 元（已用 ${(t.ratio*100).toFixed(0)}%）`}function at(e,t={}){const n=!!t.tx,a=n?{kind:t.tx.kind,amount:(t.tx.amountFen/100).toFixed(2).replace(/\.00$/,""),categoryId:t.tx.categoryId,date:t.tx.date,note:t.tx.note||""}:{kind:"expense",amount:"",categoryId:"",date:Z(),note:""};e.innerHTML=`
    <div class="seg" data-role="seg">
      <button type="button" data-kind="expense">支出</button>
      <button type="button" data-kind="income">收入</button>
    </div>

    <div class="amount-box">
      <div class="amount-label">金额</div>
      <div class="amount-row">
        <span class="amount-cur">¥</span>
        <input id="amountInput" type="text" inputmode="decimal" placeholder="0.00"
               autocomplete="off" enterkeyhint="done" />
      </div>
      <div class="amount-hint" data-role="hint"></div>
    </div>

    <div class="card">
      <p class="card-title">分类</p>
      <div class="cat-grid" data-role="cats"></div>
      <p class="cat-legend" data-role="cat-legend" hidden></p>
    </div>

    <div class="card">
      <div class="field-grid">
        <div class="field">
          <span class="field-label">日期</span>
          <input type="date" data-role="date" />
        </div>
        <div class="quick-dates" data-role="quickdates">
          <button type="button" class="chip" data-off="0">今天</button>
          <button type="button" class="chip" data-off="1">昨天</button>
          <button type="button" class="chip" data-off="2">前天</button>
        </div>
        <div class="field">
          <span class="field-label">备注</span>
          <input type="text" data-role="note" maxlength="60" placeholder="选填，例如：和同事聚餐" />
        </div>
      </div>
    </div>

    <button type="button" class="btn btn-primary btn-block" data-role="save">${u(t.submitLabel||(n?"保存修改":"保存这笔"))}</button>
  `;const s=e.querySelector("#amountInput"),r=e.querySelector('[data-role="hint"]'),i=e.querySelector('[data-role="cats"]'),o=e.querySelector('[data-role="cat-legend"]'),c=e.querySelector('[data-role="date"]'),d=e.querySelector('[data-role="note"]'),m=e.querySelector('[data-role="save"]'),g=e.querySelector('[data-role="quickdates"]');s.value=a.amount,c.value=a.date,d.value=a.note;function p(){e.querySelectorAll('[data-role="seg"] button').forEach(f=>{f.classList.toggle("active",f.dataset.kind===a.kind)})}function v(){const f=ee(a.kind);if(!f.length){i.innerHTML='<div class="muted">这个类型下还没有分类，去「设置 → 分类管理」加一个</div>',o.hidden=!0;return}f.some(x=>x.id===a.categoryId)||(a.categoryId=f[0].id);const w=a.kind==="expense"?nt(H(a.date)):new Map;i.innerHTML=f.map(x=>{const C=w.get(x.id),O=C?zt(x,C):"";return`<button type="button" class="cat-item ${x.id===a.categoryId?"active":""}" data-cat="${x.id}"
            ${C?`title="${u(O)}" aria-label="${u(O)}"`:""}>
          ${C?`<span class="cat-dot ${C.level}"></span>`:""}
          <span class="cat-emoji">${u(x.emoji)}</span>
          <span class="cat-name">${u(x.name)}</span>
        </button>`}).join(""),o.hidden=w.size===0,o.textContent="圆点＝月预算，黄是花到八成，红是超支"}function S(){g.querySelectorAll("[data-off]").forEach(f=>{f.classList.toggle("active",_e(Number(f.dataset.off))===a.date)})}function P(){const f=ge(a.amount);return a.amount.trim()===""?(r.className="amount-hint",r.textContent="",null):f===null?(r.className="amount-hint error",r.textContent="金额只能填数字，最多两位小数",null):f<=0?(r.className="amount-hint error",r.textContent="金额要大于 0",null):(r.className="amount-hint",r.textContent=`合计 ${y(f)} 元`,f)}return s.addEventListener("input",()=>{const f=Kt(s.value);if(f!==s.value){const w=s.selectionStart??f.length;s.value=f;const x=Math.max(0,Math.min(f.length,w-1));s.setSelectionRange(x,x)}a.amount=f,P()}),s.addEventListener("keydown",f=>{f.key==="Enter"&&(f.preventDefault(),m.click())}),e.querySelectorAll('[data-role="seg"] button').forEach(f=>{f.addEventListener("click",()=>{a.kind=f.dataset.kind,a.categoryId="",p(),v()})}),i.addEventListener("click",f=>{const w=f.target.closest("[data-cat]");w&&(a.categoryId=w.dataset.cat,v())}),c.addEventListener("change",()=>{a.date=c.value||Z(),S(),v()}),g.addEventListener("click",f=>{const w=f.target.closest("[data-off]");w&&(a.date=_e(Number(w.dataset.off)),c.value=a.date,S(),v())}),d.addEventListener("input",()=>{a.note=d.value}),m.addEventListener("click",async()=>{const f=P();if(f===null){a.amount.trim()===""&&h("先填金额"),s.focus();return}if(!a.categoryId){h("先选一个分类");return}m.disabled=!0;try{n?(await Ct(t.tx.id,{kind:a.kind,amountFen:f,categoryId:a.categoryId,date:a.date,note:a.note.trim()}),h("已保存修改")):(await et({ledgerId:M().id,kind:a.kind,amountFen:f,categoryId:a.categoryId,date:a.date,note:a.note.trim()}),h(`记下了 ${y(f)} 元`)),m.disabled=!1,t.onSaved?.({...a,amountFen:f})}catch(w){m.disabled=!1,h("保存失败："+w.message)}}),p(),v(),S(),P(),n&&setTimeout(()=>{s.focus(),s.select()},150),{draft:a,reset(){a.amount="",a.note="",a.date=Z(),a.categoryId="",s.value="",d.value="",c.value=a.date,v(),S(),P()}}}const st=864e5,Jt=30,Xt=7;function rt(e){const t=M(),n=te(I()),a=t.budgetFen||0;e.innerHTML=`
    ${Qt()}
    ${a>0?en(n.expenseFen,a):""}
    <div data-role="form"></div>
  `,Zt(e),at(e.querySelector('[data-role="form"]'),{onSaved:()=>{rt(e)}})}function Qt(){const e=l.meta.lastBackupAt||0,t=l.meta.backupReminderMutedUntil||0;if(Date.now()<t||!l.transactions.length)return"";const n=l.transactions.reduce((i,o)=>Math.min(i,o.createdAt||Date.now()),Date.now());if(Date.now()-(e||n)<Jt*st)return"";const s=e?Xe(new Date(e).toISOString().slice(0,10),new Date().toISOString().slice(0,10)):null,r=e?`上次备份是 ${s} 天前了。数据只在这台手机里，建议导出一份存到网盘。`:"还没有备份过。数据只在这台手机里，系统云备份也是关的 —— 卸载或者丢手机就全没了。建议导出一份存到网盘。";return`<div class="reminder" data-role="reminder">
    <span class="rem-main">${u(r)}</span>
    <button type="button" class="rem-close" data-act="reminder-close" aria-label="暂时不提醒">×</button>
  </div>`}function Zt(e){const t=e.querySelector('[data-role="reminder"]');t&&(t.querySelector('[data-act="reminder-close"]').addEventListener("click",async()=>{await X("backupReminderMutedUntil",Date.now()+Xt*st),t.remove()}),t.querySelector(".rem-main").addEventListener("click",()=>qe("settings")))}function en(e,t){const n=e/t,a=n>=1?"over":n>=.8?"warn":"",s=t-e,r=n>=1?`已经超支 ${y(-s)} 元`:`还能花 ${y(s)} 元`;return`<div class="card">
    <p class="card-title">本月预算</p>
    <div class="budget-line">
      <span>已花 ${u(y(e))} 元</span>
      <span>预算 ${u(y(t))} 元</span>
    </div>
    <div class="progress ${a}"><i style="width:${Math.min(n*100,100).toFixed(1)}%"></i></div>
    <div class="budget-tip ${a}">${u(r)}（已用 ${(n*100).toFixed(0)}%）</div>
  </div>`}const b={month:I(),categoryId:"",keyword:"",scope:"month"};function Oe(){b.month=I(),b.categoryId="",b.keyword="",b.scope="month"}function q(e){b.month>I()&&(b.month=I());const t=M(),n=Mt(b.month,t.id,{categoryId:b.categoryId,keyword:b.keyword,scope:b.scope}),a=!!(b.categoryId||b.keyword.trim()),s=b.scope==="all",r=$t(n),i=b.month<=Rt(t.id),o=b.month>=I();e.innerHTML=`
    <div class="scope" data-role="scope">
      <button type="button" data-scope="month" class="${s?"":"active"}">按月</button>
      <button type="button" data-scope="all" class="${s?"active":""}">全部时间</button>
    </div>

    ${s?"":`<div class="month-nav">
      <button type="button" class="m-arrow" data-role="prev" ${i?"disabled":""}>‹</button>
      <span class="m-label">${u(ue(b.month))}${a?` · 筛选出 ${n.length} 笔`:""}</span>
      <button type="button" class="m-arrow" data-role="next" ${o?"disabled":""}>›</button>
    </div>`}

    <div class="summary">
      <div><div class="s-val income">${u(y(r.incomeFen))}</div><div class="s-key">收入</div></div>
      <div><div class="s-val expense">${u(y(r.expenseFen))}</div><div class="s-key">支出</div></div>
      <div><div class="s-val balance">${u(y(r.balanceFen))}</div><div class="s-key">结余</div></div>
    </div>

    ${s?`<p class="muted" style="margin:-4px 0 12px 2px">全部时间里${a?"筛选出":"共"} ${n.length} 笔</p>`:""}

    <div class="filters">
      <select data-role="cat">
        <option value="">全部分类</option>
        ${ee("expense").map(p=>`<option value="${p.id}" ${b.categoryId===p.id?"selected":""}>支出 · ${u(p.name)}</option>`).join("")}
        ${ee("income").map(p=>`<option value="${p.id}" ${b.categoryId===p.id?"selected":""}>收入 · ${u(p.name)}</option>`).join("")}
      </select>
      <input type="search" data-role="kw" placeholder="搜备注或分类" value="${u(b.keyword)}" />
    </div>

    <div data-role="list"></div>
  `;const c=e.querySelector('[data-role="list"]');c.innerHTML=n.length?tn(n,s):nn(a,s),e.querySelector('[data-role="scope"]').addEventListener("click",p=>{const v=p.target.closest("[data-scope]");!v||v.dataset.scope===b.scope||(b.scope=v.dataset.scope,q(e))});const d=e.querySelector('[data-role="prev"]');d&&(d.addEventListener("click",()=>{b.month=V(b.month,-1),q(e)}),e.querySelector('[data-role="next"]').addEventListener("click",()=>{b.month=V(b.month,1),q(e)})),e.querySelector('[data-role="cat"]').addEventListener("change",p=>{b.categoryId=p.target.value,q(e)});const m=e.querySelector('[data-role="kw"]');let g=null;m.addEventListener("input",()=>{clearTimeout(g),g=setTimeout(()=>{b.keyword=m.value,q(e);const p=document.querySelector('[data-role="kw"]');p&&(p.focus(),p.setSelectionRange(p.value.length,p.value.length))},260)}),c.addEventListener("click",p=>{const v=p.target.closest("[data-tx]");v&&an(v.dataset.tx,e)})}function tn(e,t){const n=new Map;for(const s of e)n.has(s.date)||n.set(s.date,[]),n.get(s.date).push(s);const a=String(new Date().getFullYear());return[...n.entries()].map(([s,r])=>{const i=me(r.filter(g=>g.kind==="income"),g=>g.amountFen),o=me(r.filter(g=>g.kind==="expense"),g=>g.amountFen),c=[];i&&c.push(`收 ${y(i)}`),o&&c.push(`支 ${y(o)}`);const d=s.slice(0,4),m=t&&d!==a?`${d}年${Ue(s)}`:Ue(s);return`<div class="day-group">
        <div class="day-head">
          <span>${u(m)}</span>
          <span class="d-sub">${u(c.join("　"))}</span>
        </div>
        <div class="tx-list">
          ${r.map(g=>{const p=W(g.categoryId);return`<div class="tx" data-tx="${g.id}">
                <span class="tx-emoji">${u(p?.emoji??"❓")}</span>
                <span class="tx-main">
                  <div class="tx-cat">${u(p?.name??"未分类")}</div>
                  ${g.note?`<div class="tx-note">${u(g.note)}</div>`:""}
                </span>
                <span class="tx-amt ${g.kind}">${g.kind==="expense"?"-":"+"}${u(y(g.amountFen))}</span>
              </div>`}).join("")}
        </div>
      </div>`}).join("")}function nn(e,t){return`<div class="empty">
    <span class="empty-ico">${e?"🔍":"🗒️"}</span>
    ${e?"没有符合条件的记录":t?"还没有任何记录":"这个月还没有记账"}
  </div>`}function an(e,t){const n=l.transactions.find(r=>r.id===e);if(!n)return;const a=W(n.categoryId),s=N({title:"这笔记录",body:`
      <div class="set-list">
        <div class="set-row" style="cursor:default">
          <span class="sr-ico">${u(a?.emoji??"❓")}</span>
          <span class="sr-main">
            <div style="font-size:16px;font-weight:600">${u(y(n.amountFen))} 元</div>
            <div class="sr-sub">${u(a?.name??"未分类")} · ${u(n.date)}${n.note?" · "+u(n.note):""}</div>
          </span>
        </div>
        <button type="button" class="set-row" data-act="edit"><span class="sr-ico">✏️</span><span class="sr-main">修改</span></button>
        <button type="button" class="set-row" data-act="dup"><span class="sr-ico">📋</span><span class="sr-main">再记一笔一样的<span class="sr-sub">复制到今天</span></span></button>
        <button type="button" class="set-row" data-act="del"><span class="sr-ico">🗑️</span><span class="sr-main" style="color:var(--danger)">删除</span></button>
      </div>`,actions:[{label:"取消",className:"btn-outline",onClick:r=>r.close()}]});s.body.addEventListener("click",async r=>{const i=r.target.closest("[data-act]");if(!i)return;const o=i.dataset.act;if(s.close(),o==="edit")return rn(n,t);if(o==="del"){if(!await z({title:"删除这笔记录？",message:`${n.date}　${a?.name??"未分类"}　${y(n.amountFen)} 元
删掉之后可以马上点提示里的「撤销」找回。`,okText:"删除",danger:!0}))return;const d=await At(n.id);q(t),h("已删除 1 笔记录",{ms:6e3,actionLabel:"撤销",onAction:async()=>{await jt(d),h("已恢复"),q(t)}});return}o==="dup"&&await sn(n,t)})}async function sn(e,t){await et({ledgerId:M().id,kind:e.kind,amountFen:e.amountFen,categoryId:e.categoryId,date:Z(),note:e.note}),h("已复制到今天"),b.scope!=="all"&&b.month!==I()&&(b.month=I()),q(t)}function rn(e,t){const n=N({title:"修改记录",body:'<div data-role="form"></div>'});at(n.body.querySelector('[data-role="form"]'),{tx:e,submitLabel:"保存修改",onSaved:()=>{n.close(),q(t)}})}function on({month:e,categoryId:t}={}){e&&(b.month=e),t!==void 0&&(b.categoryId=t),e&&(b.scope="month")}const ot=320;function cn(e,{size:t=ot,thickness:n=48}={}){const a=e.reduce((m,g)=>m+g.amountFen,0);if(!a)return'<div class="empty">还没有支出记录</div>';const s=(t-n)/2,r=t/2,i=t/2;let o=-Math.PI/2;const c=e.map((m,g)=>{const p=m.amountFen/a*Math.PI*2,v=p>=Math.PI*2-1e-6?Ye(r,i,s,n,0,Math.PI*2-1e-4):Ye(r,i,s,n,o,o+p);return o+=p,`<path d="${v}" fill="${We(g)}" />`}),d=e[0];return`<div class="chart-wrap">
    <svg viewBox="0 0 ${t} ${t}" width="${t}" height="${t}" role="img"
         aria-label="分类占比环形图，合计 ${u(y(a))} 元">
      ${c.join("")}
      <text x="${r}" y="${i-8}" text-anchor="middle" font-size="13" fill="var(--text-3)">合计</text>
      <text x="${r}" y="${i+16}" text-anchor="middle" font-size="18" font-weight="600" fill="var(--text)">${u(y(a))}</text>
    </svg>
  </div>
  <div class="legend">
    ${e.slice(0,8).map((m,g)=>`<div class="legend-row">
          <span class="legend-dot" style="background:${We(g)}"></span>
          <span class="legend-name">${u(m.emoji+" "+m.name)}</span>
          <span class="legend-amt">${u(y(m.amountFen))}</span>
          <span class="legend-pct">${(m.pct*100).toFixed(1)}%</span>
        </div>`).join("")}
    ${e.length>8?`<div class="muted">还有 ${e.length-8} 个分类没显示</div>`:""}
  </div>
  <div class="muted" style="margin-top:10px">占比最大：${u(d.name)}，${(d.pct*100).toFixed(1)}%</div>`}function Ye(e,t,n,a,s,r){const i=n+a/2,o=n-a/2,c=r-s>Math.PI?1:0,d=e+i*Math.cos(s),m=t+i*Math.sin(s),g=e+i*Math.cos(r),p=t+i*Math.sin(r),v=e+o*Math.cos(r),S=t+o*Math.sin(r),P=e+o*Math.cos(s),f=t+o*Math.sin(s);return`M ${d} ${m} A ${i} ${i} 0 ${c} 1 ${g} ${p} L ${v} ${S} A ${o} ${o} 0 ${c} 0 ${P} ${f} Z`}function dn(e,{height:t=190}={}){const n=ot,a=t,s=42,r=8,i=16,o=30,c=n-s-r,d=a-i-o,m=Math.max(...e.map(w=>Math.max(w.incomeFen,w.expenseFen)),1),g=c/e.length,p=Math.min(12,g/3.2),v=i+d,S=e.map((w,x)=>{const C=s+g*x+g/2,O=Math.round(w.incomeFen/m*d),se=Math.round(w.expenseFen/m*d),ye=v-O,k=v-se;return`
        <rect x="${(C-p-2).toFixed(1)}" y="${k}" width="${p}" height="${Math.max(se,w.expenseFen?2:0)}" rx="2.5" fill="var(--expense)" />
        <rect x="${(C+2).toFixed(1)}" y="${ye}" width="${p}" height="${Math.max(O,w.incomeFen?2:0)}" rx="2.5" fill="var(--income)" />
        <text x="${C.toFixed(1)}" y="${a-10}" text-anchor="middle" font-size="13" fill="var(--text-3)">${u(ue(w.month))}</text>`}).join(""),P=[1,.5,0].map(w=>{const x=i+d*(1-w),C=w===0;return`
        <line x1="${s}" y1="${x.toFixed(1)}" x2="${n-r}" y2="${x.toFixed(1)}"
              stroke="var(--border)" stroke-width="${C?1:.5}"
              ${C?"":'stroke-dasharray="3 3"'} />
        <text x="${s-8}" y="${x.toFixed(1)}" text-anchor="end" dominant-baseline="central"
              font-size="12" fill="var(--text-3)">${u(ln(m*w))}</text>`}).join(""),f=e.some(w=>w.incomeFen||w.expenseFen);return`<div class="chart-wrap">
    <svg viewBox="0 0 ${n} ${a}" role="img" aria-label="最近几个月收支趋势柱状图">
      ${P}
      ${S}
    </svg>
  </div>
  <div class="legend-group" style="margin-top:8px">
    <span class="legend-item"><i class="legend-dot" style="background:var(--income)"></i>收入</span>
    <span class="legend-item"><i class="legend-dot" style="background:var(--expense)"></i>支出</span>
  </div>
  ${f?"":'<div class="muted" style="margin-top:8px">这几个月还没有记录</div>'}`}function ln(e){if(!e)return"0";const t=e/100;if(t>=1e4){const n=t/1e4;return`${n>=10?String(Math.round(n)):n.toFixed(1).replace(/\.0$/,"")}万`}return String(Math.round(t))}const L={month:I(),kind:"expense"};function de(e){L.month>I()&&(L.month=I());const t=M(),n=mn(L.month,6),a=Ot(n,t.id),s=te(L.month,t.id),r=te(V(L.month,-1),t.id),i=Tt(L.month,L.kind,t.id),o=L.month>=I();e.innerHTML=`
    <div class="month-nav">
      <button type="button" class="m-arrow" data-role="prev">‹</button>
      <span class="m-label">${u(ue(L.month))}</span>
      <button type="button" class="m-arrow" data-role="next" ${o?"disabled":""}>›</button>
    </div>

    <div class="card">
      <p class="card-title">${u(ue(L.month))}总结</p>
      <div class="summary summary-plain">
        <div><div class="s-val income">${u(y(s.incomeFen))}</div><div class="s-key">收入</div></div>
        <div><div class="s-val expense">${u(y(s.expenseFen))}</div><div class="s-key">支出</div></div>
        <div><div class="s-val balance">${u(y(s.balanceFen))}</div><div class="s-key">结余</div></div>
      </div>
      ${un(s,r)}
      ${s.count?"":'<div class="muted" style="margin-top:10px">这个月还没有记录</div>'}
    </div>

    <div class="card">
      <div class="seg" data-role="kindseg" style="margin-bottom:12px">
        <button type="button" data-kind="expense">支出构成</button>
        <button type="button" data-kind="income">收入构成</button>
      </div>
      <div data-role="pie"></div>
    </div>

    <div class="card">
      <p class="card-title">最近 6 个月趋势</p>
      <div data-role="trend"></div>
    </div>
  `,e.querySelector('[data-role="pie"]').innerHTML=cn(i.items),e.querySelector('[data-role="trend"]').innerHTML=dn(a),e.querySelectorAll('[data-role="kindseg"] button').forEach(c=>{c.classList.toggle("active",c.dataset.kind===L.kind),c.addEventListener("click",()=>{L.kind=c.dataset.kind,de(e)})}),e.querySelector('[data-role="prev"]').addEventListener("click",()=>{L.month=V(L.month,-1),de(e)}),e.querySelector('[data-role="next"]').addEventListener("click",()=>{L.month=V(L.month,1),de(e)}),e.querySelectorAll('[data-role="pie"] .legend-row').forEach((c,d)=>{const m=i.items[d];m&&(c.style.cursor="pointer",c.title="点一下看这个分类的明细",c.addEventListener("click",()=>{on({month:L.month,categoryId:m.categoryId}),qe("list")}))})}function un(e,t){if(!e.count)return"";if(!t.count)return'<div class="delta">上月没有记录，没法比</div>';const n=e.expenseFen-t.expenseFen;if(n===0)return'<div class="delta">支出和上月持平</div>';const a=Math.round(Math.abs(n/t.expenseFen)*100),s=n>0;return`<div class="delta ${s?"up":"down"}">
    支出比上月${s?"多":"少"}花 <b>${u(y(Math.abs(n)))}</b> 元
    <b>(${s?"+":"-"}${a}%)</b>
  </div>`}function mn(e,t){const n=[];for(let a=t-1;a>=0;a-=1)n.push(V(e,-a));return n}const pn="modulepreload",gn=function(e,t){return new URL(e,t).href},Ge={},it=function(t,n,a){let s=Promise.resolve();if(n&&n.length>0){const i=document.getElementsByTagName("link"),o=document.querySelector("meta[property=csp-nonce]"),c=o?.nonce||o?.getAttribute("nonce");s=Promise.allSettled(n.map(d=>{if(d=gn(d,a),d in Ge)return;Ge[d]=!0;const m=d.endsWith(".css"),g=m?'[rel="stylesheet"]':"";if(!!a)for(let S=i.length-1;S>=0;S--){const P=i[S];if(P.href===d&&(!m||P.rel==="stylesheet"))return}else if(document.querySelector(`link[href="${d}"]${g}`))return;const v=document.createElement("link");if(v.rel=m?"stylesheet":pn,m||(v.as="script"),v.crossOrigin="",v.href=d,c&&v.setAttribute("nonce",c),document.head.appendChild(v),m)return new Promise((S,P)=>{v.addEventListener("load",S),v.addEventListener("error",()=>P(new Error(`Unable to preload CSS for ${d}`)))})}))}function r(i){const o=new Event("vite:preloadError",{cancelable:!0});if(o.payload=i,window.dispatchEvent(o),!o.defaultPrevented)throw i}return s.then(i=>{for(const o of i||[])o.status==="rejected"&&r(o.reason);return t().catch(r)})};/*! Capacitor: https://capacitorjs.com/ - MIT License */const fn=e=>{const t=new Map;t.set("web",{name:"web"});const n=e.CapacitorPlatforms||{currentPlatform:{name:"web"},platforms:t},a=(r,i)=>{n.platforms.set(r,i)},s=r=>{n.platforms.has(r)&&(n.currentPlatform=n.platforms.get(r))};return n.addPlatform=a,n.setPlatform=s,n},vn=e=>e.CapacitorPlatforms=fn(e),ct=vn(typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});ct.addPlatform;ct.setPlatform;var J;(function(e){e.Unimplemented="UNIMPLEMENTED",e.Unavailable="UNAVAILABLE"})(J||(J={}));class xe extends Error{constructor(t,n,a){super(t),this.message=t,this.code=n,this.data=a}}const yn=e=>{var t,n;return e?.androidBridge?"android":!((n=(t=e?.webkit)===null||t===void 0?void 0:t.messageHandlers)===null||n===void 0)&&n.bridge?"ios":"web"},bn=e=>{var t,n,a,s,r;const i=e.CapacitorCustomPlatform||null,o=e.Capacitor||{},c=o.Plugins=o.Plugins||{},d=e.CapacitorPlatforms,m=()=>i!==null?i.name:yn(e),g=((t=d?.currentPlatform)===null||t===void 0?void 0:t.getPlatform)||m,p=()=>g()!=="web",v=((n=d?.currentPlatform)===null||n===void 0?void 0:n.isNativePlatform)||p,S=k=>{const E=O.get(k);return!!(E?.platforms.has(g())||w(k))},P=((a=d?.currentPlatform)===null||a===void 0?void 0:a.isPluginAvailable)||S,f=k=>{var E;return(E=o.PluginHeaders)===null||E===void 0?void 0:E.find(Y=>Y.name===k)},w=((s=d?.currentPlatform)===null||s===void 0?void 0:s.getPluginHeader)||f,x=k=>e.console.error(k),C=(k,E,Y)=>Promise.reject(`${Y} does not have an implementation of "${E}".`),O=new Map,se=(k,E={})=>{const Y=O.get(k);if(Y)return console.warn(`Capacitor plugin "${k}" already registered. Cannot register plugins twice.`),Y.proxy;const U=g(),G=w(k);let R;const ft=async()=>(!R&&U in E?R=typeof E[U]=="function"?R=await E[U]():R=E[U]:i!==null&&!R&&"web"in E&&(R=typeof E.web=="function"?R=await E.web():R=E.web),R),vt=(F,A)=>{var T,B;if(G){const _=G?.methods.find(j=>A===j.name);if(_)return _.rtype==="promise"?j=>o.nativePromise(k,A.toString(),j):(j,re)=>o.nativeCallback(k,A.toString(),j,re);if(F)return(T=F[A])===null||T===void 0?void 0:T.bind(F)}else{if(F)return(B=F[A])===null||B===void 0?void 0:B.bind(F);throw new xe(`"${k}" plugin is not implemented on ${U}`,J.Unimplemented)}},be=F=>{let A;const T=(...B)=>{const _=ft().then(j=>{const re=vt(j,F);if(re){const oe=re(...B);return A=oe?.remove,oe}else throw new xe(`"${k}.${F}()" is not implemented on ${U}`,J.Unimplemented)});return F==="addListener"&&(_.remove=async()=>A()),_};return T.toString=()=>`${F.toString()}() { [capacitor code] }`,Object.defineProperty(T,"name",{value:F,writable:!1,configurable:!1}),T},De=be("addListener"),Ne=be("removeListener"),yt=(F,A)=>{const T=De({eventName:F},A),B=async()=>{const j=await T;Ne({eventName:F,callbackId:j},A)},_=new Promise(j=>T.then(()=>j({remove:B})));return _.remove=async()=>{console.warn("Using addListener() without 'await' is deprecated."),await B()},_},he=new Proxy({},{get(F,A){switch(A){case"$$typeof":return;case"toJSON":return()=>({});case"addListener":return G?yt:De;case"removeListener":return Ne;default:return be(A)}}});return c[k]=he,O.set(k,{name:k,proxy:he,platforms:new Set([...Object.keys(E),...G?[U]:[]])}),he},ye=((r=d?.currentPlatform)===null||r===void 0?void 0:r.registerPlugin)||se;return o.convertFileSrc||(o.convertFileSrc=k=>k),o.getPlatform=g,o.handleError=x,o.isNativePlatform=v,o.isPluginAvailable=P,o.pluginMethodNoop=C,o.registerPlugin=ye,o.Exception=xe,o.DEBUG=!!o.DEBUG,o.isLoggingEnabled=!!o.isLoggingEnabled,o.platform=o.getPlatform(),o.isNative=o.isNativePlatform(),o},hn=e=>e.Capacitor=bn(e),pe=hn(typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{}),ve=pe.registerPlugin;pe.Plugins;class dt{constructor(t){this.listeners={},this.retainedEventArguments={},this.windowListeners={},t&&(console.warn(`Capacitor WebPlugin "${t.name}" config object was deprecated in v3 and will be removed in v4.`),this.config=t)}addListener(t,n){let a=!1;this.listeners[t]||(this.listeners[t]=[],a=!0),this.listeners[t].push(n);const r=this.windowListeners[t];r&&!r.registered&&this.addWindowListener(r),a&&this.sendRetainedArgumentsForEvent(t);const i=async()=>this.removeListener(t,n);return Promise.resolve({remove:i})}async removeAllListeners(){this.listeners={};for(const t in this.windowListeners)this.removeWindowListener(this.windowListeners[t]);this.windowListeners={}}notifyListeners(t,n,a){const s=this.listeners[t];if(!s){if(a){let r=this.retainedEventArguments[t];r||(r=[]),r.push(n),this.retainedEventArguments[t]=r}return}s.forEach(r=>r(n))}hasListeners(t){return!!this.listeners[t].length}registerWindowListener(t,n){this.windowListeners[n]={registered:!1,windowEventName:t,pluginEventName:n,handler:a=>{this.notifyListeners(n,a)}}}unimplemented(t="not implemented"){return new pe.Exception(t,J.Unimplemented)}unavailable(t="not available"){return new pe.Exception(t,J.Unavailable)}async removeListener(t,n){const a=this.listeners[t];if(!a)return;const s=a.indexOf(n);this.listeners[t].splice(s,1),this.listeners[t].length||this.removeWindowListener(this.windowListeners[t])}addWindowListener(t){window.addEventListener(t.windowEventName,t.handler),t.registered=!0}removeWindowListener(t){t&&(window.removeEventListener(t.windowEventName,t.handler),t.registered=!1)}sendRetainedArgumentsForEvent(t){const n=this.retainedEventArguments[t];n&&(delete this.retainedEventArguments[t],n.forEach(a=>{this.notifyListeners(t,a)}))}}const Ve=e=>encodeURIComponent(e).replace(/%(2[346B]|5E|60|7C)/g,decodeURIComponent).replace(/[()]/g,escape),Ke=e=>e.replace(/(%[\dA-F]{2})+/gi,decodeURIComponent);class wn extends dt{async getCookies(){const t=document.cookie,n={};return t.split(";").forEach(a=>{if(a.length<=0)return;let[s,r]=a.replace(/=/,"CAP_COOKIE").split("CAP_COOKIE");s=Ke(s).trim(),r=Ke(r).trim(),n[s]=r}),n}async setCookie(t){try{const n=Ve(t.key),a=Ve(t.value),s=`; expires=${(t.expires||"").replace("expires=","")}`,r=(t.path||"/").replace("path=",""),i=t.url!=null&&t.url.length>0?`domain=${t.url}`:"";document.cookie=`${n}=${a||""}${s}; path=${r}; ${i};`}catch(n){return Promise.reject(n)}}async deleteCookie(t){try{document.cookie=`${t.key}=; Max-Age=0`}catch(n){return Promise.reject(n)}}async clearCookies(){try{const t=document.cookie.split(";")||[];for(const n of t)document.cookie=n.replace(/^ +/,"").replace(/=.*/,`=;expires=${new Date().toUTCString()};path=/`)}catch(t){return Promise.reject(t)}}async clearAllCookies(){try{await this.clearCookies()}catch(t){return Promise.reject(t)}}}ve("CapacitorCookies",{web:()=>new wn});const $n=async e=>new Promise((t,n)=>{const a=new FileReader;a.onload=()=>{const s=a.result;t(s.indexOf(",")>=0?s.split(",")[1]:s)},a.onerror=s=>n(s),a.readAsDataURL(e)}),kn=(e={})=>{const t=Object.keys(e);return Object.keys(e).map(s=>s.toLocaleLowerCase()).reduce((s,r,i)=>(s[r]=e[t[i]],s),{})},xn=(e,t=!0)=>e?Object.entries(e).reduce((a,s)=>{const[r,i]=s;let o,c;return Array.isArray(i)?(c="",i.forEach(d=>{o=t?encodeURIComponent(d):d,c+=`${r}=${o}&`}),c.slice(0,-1)):(o=t?encodeURIComponent(i):i,c=`${r}=${o}`),`${a}&${c}`},"").substr(1):null,En=(e,t={})=>{const n=Object.assign({method:e.method||"GET",headers:e.headers},t),s=kn(e.headers)["content-type"]||"";if(typeof e.data=="string")n.body=e.data;else if(s.includes("application/x-www-form-urlencoded")){const r=new URLSearchParams;for(const[i,o]of Object.entries(e.data||{}))r.set(i,o);n.body=r.toString()}else if(s.includes("multipart/form-data")||e.data instanceof FormData){const r=new FormData;if(e.data instanceof FormData)e.data.forEach((o,c)=>{r.append(c,o)});else for(const o of Object.keys(e.data))r.append(o,e.data[o]);n.body=r;const i=new Headers(n.headers);i.delete("content-type"),n.headers=i}else(s.includes("application/json")||typeof e.data=="object")&&(n.body=JSON.stringify(e.data));return n};class Ln extends dt{async request(t){const n=En(t,t.webFetchExtra),a=xn(t.params,t.shouldEncodeUrlParams),s=a?`${t.url}?${a}`:t.url,r=await fetch(s,n),i=r.headers.get("content-type")||"";let{responseType:o="text"}=r.ok?t:{};i.includes("application/json")&&(o="json");let c,d;switch(o){case"arraybuffer":case"blob":d=await r.blob(),c=await $n(d);break;case"json":c=await r.json();break;case"document":case"text":default:c=await r.text()}const m={};return r.headers.forEach((g,p)=>{m[p]=g}),{data:c,headers:m,status:r.status,url:r.url}}async get(t){return this.request(Object.assign(Object.assign({},t),{method:"GET"}))}async post(t){return this.request(Object.assign(Object.assign({},t),{method:"POST"}))}async put(t){return this.request(Object.assign(Object.assign({},t),{method:"PUT"}))}async patch(t){return this.request(Object.assign(Object.assign({},t),{method:"PATCH"}))}async delete(t){return this.request(Object.assign(Object.assign({},t),{method:"DELETE"}))}}ve("CapacitorHttp",{web:()=>new Ln});var Pe;(function(e){e.Documents="DOCUMENTS",e.Data="DATA",e.Library="LIBRARY",e.Cache="CACHE",e.External="EXTERNAL",e.ExternalStorage="EXTERNAL_STORAGE"})(Pe||(Pe={}));var Ce;(function(e){e.UTF8="utf8",e.ASCII="ascii",e.UTF16="utf16"})(Ce||(Ce={}));const Sn=ve("Filesystem",{web:()=>it(()=>import("./web-Ciq_nMWk.js"),[],import.meta.url).then(e=>new e.FilesystemWeb)}),Fn=ve("Share",{web:()=>it(()=>import("./web-CIsunh-O.js"),[],import.meta.url).then(e=>new e.ShareWeb)});function In(){return!!window.Capacitor?.isNativePlatform?.()}async function lt(e,t,n="text/plain"){if(In()){const i=await Sn.writeFile({path:e,data:t,directory:Pe.Cache,encoding:Ce.UTF8});try{return await Fn.share({title:e,text:e,url:i.uri,dialogTitle:"保存或发送这个文件"}),{mode:"share"}}catch(o){return{mode:"share-failed",uri:i.uri,message:o?.message||""}}}const a=new Blob([t],{type:`${n};charset=utf-8`}),s=URL.createObjectURL(a),r=document.createElement("a");return r.href=s,r.download=e,document.body.appendChild(r),r.click(),r.remove(),setTimeout(()=>URL.revokeObjectURL(s),1e3),{mode:"download"}}function Pn(e=".json,application/json"){return new Promise(t=>{const n=document.createElement("input");n.type="file",n.accept=e,n.style.display="none";let a=!1;const s=r=>{a||(a=!0,n.remove(),t(r))};n.addEventListener("change",()=>{const r=n.files?.[0];if(!r)return s(null);const i=new FileReader;i.onload=()=>s(String(i.result)),i.onerror=()=>s(null),i.readAsText(r,"utf-8")}),window.addEventListener("focus",()=>setTimeout(()=>{n.files?.length||s(null)},800),{once:!0}),document.body.appendChild(n),n.click()})}function ut(){const e=new Date,t=n=>String(n).padStart(2,"0");return`${e.getFullYear()}${t(e.getMonth()+1)}${t(e.getDate())}-${t(e.getHours())}${t(e.getMinutes())}`}const Cn=["🍚","🍜","🍔","🍰","☕","🍺","🚌","🚇","🚕","⛽","🛒","👕","💄","🏠","💡","📱","🎮","🎬","✈️","🏨","💊","🏥","📚","✏️","🎓","🎁","💵","💰","💼","📈","🐱","👶","🔧","🚿","🛁","🏋️","🎵","📷","🌸","📦","💳","🏦","💎","🎯","📄","💉","🍎","🚗","🛵","🎨"];function D(e){const t=document.createElement("div");e.replaceChildren(t);const n=M(),a=te(I(),n.id),s=n.budgetFen||0,r=l.meta.lastBackupAt||0;t.innerHTML=`
    <div class="set-group">
      <h2>账本</h2>
      <div class="set-list">
        <button type="button" class="set-row" data-act="ledgers">
          <span class="sr-ico">📒</span>
          <span class="sr-main">${u(n.name)}<span class="sr-sub">共 ${l.ledgers.length} 个账本，点这里切换</span></span>
          <span class="sr-arrow">›</span>
        </button>
        <button type="button" class="set-row" data-act="budget">
          <span class="sr-ico">🎯</span>
          <span class="sr-main">本月预算<span class="sr-sub">本月已花 ${u(y(a.expenseFen))} 元</span></span>
          <span class="sr-val">${s?u(y(s))+" 元":"未设置"}</span>
          <span class="sr-arrow">›</span>
        </button>
        <button type="button" class="set-row" data-act="rename">
          <span class="sr-ico">✏️</span>
          <span class="sr-main">重命名当前账本</span>
          <span class="sr-arrow">›</span>
        </button>
        <button type="button" class="set-row" data-act="newledger">
          <span class="sr-ico">➕</span>
          <span class="sr-main">新建账本<span class="sr-sub">比如「装修」「旅行」，数据各算各的</span></span>
          <span class="sr-arrow">›</span>
        </button>
      </div>
    </div>

    <div class="set-group">
      <h2>分类</h2>
      <div class="set-list">
        <button type="button" class="set-row" data-act="cats">
          <span class="sr-ico">🏷️</span>
          <span class="sr-main">分类管理<span class="sr-sub">新增、改名、换图标、调顺序、删除</span></span>
          <span class="sr-val">${l.categories.length} 个</span>
          <span class="sr-arrow">›</span>
        </button>
      </div>
    </div>

    <div class="set-group">
      <h2>数据</h2>
      <div class="set-list">
        <button type="button" class="set-row" data-act="csv">
          <span class="sr-ico">📊</span>
          <span class="sr-main">导出当前账本为 CSV<span class="sr-sub">Excel / WPS 能直接打开</span></span>
          <span class="sr-arrow">›</span>
        </button>
        <button type="button" class="set-row" data-act="backup">
          <span class="sr-ico">💾</span>
          <span class="sr-main">导出完整备份<span class="sr-sub">所有账本、分类、预算，一个文件全带走</span></span>
          <span class="sr-val">${u(An(r))}</span>
          <span class="sr-arrow">›</span>
        </button>
        <button type="button" class="set-row" data-act="restore">
          <span class="sr-ico">📥</span>
          <span class="sr-main">从备份恢复<span class="sr-sub" style="color:var(--danger)">会覆盖现在的全部数据</span></span>
          <span class="sr-arrow">›</span>
        </button>
        <button type="button" class="set-row" data-act="wipe">
          <span class="sr-ico">🗑️</span>
          <span class="sr-main" style="color:var(--danger)">清空所有数据</span>
          <span class="sr-arrow">›</span>
        </button>
      </div>
      <p class="muted" style="margin:10px 6px 0">
        数据全部存在这台手机里，不联网、不上传。换手机或者怕丢，记得定期「导出完整备份」，把文件存到网盘或发给自己。
      </p>
    </div>

    <div class="set-group">
      <h2>关于</h2>
      <div class="set-list">
        <div class="set-row" style="cursor:default">
          <span class="sr-ico">ℹ️</span>
          <span class="sr-main">记账本<span class="sr-sub">本地版 v${u(wt)} · 记录 ${l.transactions.length} 笔</span></span>
        </div>
      </div>
    </div>
  `,t.addEventListener("click",async i=>{const o=i.target.closest("[data-act]");if(!o)return;const c=o.dataset.act,d=()=>D(e);if(c==="ledgers")return jn(e);if(c==="budget")return qn(e);if(c==="rename")return Tn(e);if(c==="newledger")return Mn(e);if(c==="cats")return Rn(e);if(c==="csv")return Dn();if(c==="backup")return Nn(d);if(c==="restore")return Bn(d);if(c==="wipe")return _n(d)})}function An(e){if(!e)return"还没有备份";const t=Xe(le(new Date(e)),le(new Date));return t<=0?"今天刚备份":t===1?"昨天备份":`${t} 天前备份`}function jn(e){const t=l.ledgers.map(a=>`<button type="button" class="set-row" data-id="${a.id}">
        <span class="sr-ico">${a.id===l.meta.currentLedgerId?"✅":"📒"}</span>
        <span class="sr-main">${u(a.name)}
          <span class="sr-sub">${l.transactions.filter(s=>s.ledgerId===a.id).length} 笔${a.budgetFen?" · 预算 "+u(y(a.budgetFen)):""}</span>
        </span>
        ${l.ledgers.length>1?`<span class="sr-val" data-del="${a.id}">删除</span>`:""}
      </button>`).join(""),n=N({title:"选择账本",body:`<div class="set-list">${t}</div>
      <p class="muted" style="margin-top:12px">每个账本的记录和统计互相独立，切换后首页、账单、统计都会跟着变。</p>`});n.body.addEventListener("click",async a=>{const s=a.target.closest("[data-del]");if(s){a.stopPropagation();const i=l.ledgers.find(d=>d.id===s.dataset.del),o=l.transactions.filter(d=>d.ledgerId===i.id).length;if(!await z({title:`删除「${i.name}」？`,message:o?`这个账本里有 ${o} 笔记录，会一起删掉，删了没法恢复。`:"这个账本还是空的，删掉不影响别的账本。",okText:"删除",danger:!0}))return;try{await Lt(i.id),h("已删除账本"),n.close(),D(e)}catch(d){h(d.message)}return}const r=a.target.closest("[data-id]");r&&(await Me(r.dataset.id),h("已切换账本"),n.close(),D(e))})}function Mn(e){const t=N({title:"新建账本",body:`<div class="field-grid">
      <div class="field"><span class="field-label">名字</span>
        <input type="text" data-role="name" maxlength="12" placeholder="例如：装修" /></div>
      <div class="field"><span class="field-label">预算</span>
        <input type="text" inputmode="decimal" data-role="budget" placeholder="选填，每月支出上限" /></div>
    </div>
    <p class="muted" style="margin-top:10px">预算可以以后再设，先建账本也行。</p>`,actions:[{label:"取消",className:"btn-outline",onClick:n=>n.close()},{label:"创建",className:"btn-primary",onClick:async n=>{const a=n.body.querySelector('[data-role="name"]').value.trim(),s=n.body.querySelector('[data-role="budget"]').value.trim();if(!a)return h("给账本起个名字");let r=0;if(s){const o=ge(s);if(o===null||o<0)return h("预算填个数字就行，比如 3000");r=o}const i=await Et(a,r);await Me(i.id),h(`已创建「${a}」并切过去了`),n.close(),D(e)}}]});setTimeout(()=>t.body.querySelector('[data-role="name"]')?.focus(),120)}function Tn(e){const t=M(),n=N({title:"重命名账本",body:`<div class="field-grid">
      <div class="field"><span class="field-label">名字</span>
        <input type="text" data-role="name" maxlength="12" value="${u(t.name)}" /></div>
    </div>`,actions:[{label:"取消",className:"btn-outline",onClick:a=>a.close()},{label:"保存",className:"btn-primary",onClick:async a=>{const s=a.body.querySelector('[data-role="name"]').value.trim();if(!s)return h("名字不能是空的");await Se(t.id,{name:s}),h("已改名"),a.close(),D(e)}}]});setTimeout(()=>n.body.querySelector('[data-role="name"]')?.select(),120)}function qn(e){const t=M(),n=N({title:"本月预算",body:`<div class="field-grid">
      <div class="field"><span class="field-label">金额</span>
        <input type="text" inputmode="decimal" data-role="amount"
               placeholder="比如 3000，填 0 表示不设预算"
               value="${t.budgetFen?u(Je(t.budgetFen)):""}" /></div>
    </div>
    <p class="muted" style="margin-top:10px">这是每个月总的支出上限，花到 80% 会提醒你。</p>`,actions:[{label:"取消",className:"btn-outline",onClick:a=>a.close()},{label:"保存",className:"btn-primary",onClick:async a=>{const s=a.body.querySelector('[data-role="amount"]').value.trim();if(!s)return await Se(t.id,{budgetFen:0}),h("已取消预算"),a.close(),D(e);const r=ge(s);if(r===null)return h("填数字就行，比如 3000");await Se(t.id,{budgetFen:r}),h(r?`预算设为 ${y(r)} 元`:"已取消预算"),a.close(),D(e)}}]});setTimeout(()=>n.body.querySelector('[data-role="amount"]')?.focus(),120)}function On(e,t){const n=`${e} 笔记录在用`;if(!t)return n;const a=(t.ratio*100).toFixed(0);return`${n} · 本月 ${y(t.spentFen)} / ${y(t.budgetFen)} 元（${a}%）`}function Rn(e,t="expense"){const n=N({title:"分类管理",body:`
      <div class="seg" data-role="seg" style="margin-bottom:12px">
        <button type="button" data-kind="expense">支出分类</button>
        <button type="button" data-kind="income">收入分类</button>
      </div>
      <div data-role="list"></div>
      <button type="button" class="btn btn-outline btn-block" data-role="add" style="margin-top:14px">➕ 新增分类</button>
      <p class="muted" style="margin-top:12px">↑↓ 调整分类在记账页的排列顺序。点分类可以改名、换图标，也可以给支出分类设月预算。删掉分类不会删掉记录，那些记录会显示成「未分类」。</p>`});function a(){const s=ee(t),r=t==="expense"?nt(I()):new Map;n.body.querySelectorAll('[data-role="seg"] button').forEach(o=>{o.classList.toggle("active",o.dataset.kind===t)});const i=n.body.querySelector('[data-role="list"]');i.innerHTML=`<div class="set-list">${s.map((o,c)=>{const d=Ze(o.id),m=r.get(o.id);return`<div class="cat-row">
          <button type="button" class="cat-row-main" data-cat="${o.id}">
            <span class="cm-emoji">${u(o.emoji)}</span>
            <span class="cm-body">
              <div class="cm-name">${u(o.name)}</div>
              <div class="cm-sub ${m?m.level:""}">${On(d,m)}</div>
            </span>
          </button>
          <span class="cm-tools">
            <button type="button" class="mini-btn" data-up="${o.id}" ${c===0?"disabled":""} aria-label="上移">↑</button>
            <button type="button" class="mini-btn" data-down="${o.id}" ${c===s.length-1?"disabled":""} aria-label="下移">↓</button>
          </span>
        </div>`}).join("")}</div>`,i.querySelectorAll("[data-cat]").forEach(o=>{o.addEventListener("click",()=>ze(l.categories.find(c=>c.id===o.dataset.cat),()=>a()))}),i.querySelectorAll("[data-up], [data-down]").forEach(o=>{o.addEventListener("click",async()=>{const c=o.dataset.up?-1:1,d=o.dataset.up||o.dataset.down;await Ft(d,c)&&a()})})}n.body.querySelectorAll('[data-role="seg"] button').forEach(s=>{s.addEventListener("click",()=>{t=s.dataset.kind,a()})}),n.body.querySelector('[data-role="add"]').addEventListener("click",()=>{ze(null,()=>{n.close(),D(e)},e,t)}),a()}function ze(e,t,n,a="expense"){const s=!e;let r=e?.emoji??"📦",i=e?.kind??a;const o=N({title:s?"新增分类":"编辑分类",body:`
      <div class="field-grid">
        <div class="field"><span class="field-label">名称</span>
          <input type="text" data-role="name" maxlength="6" value="${u(e?.name??"")}" placeholder="最多 6 个字" /></div>
        <div class="field"><span class="field-label">类型</span>
          <select data-role="kind">
            <option value="expense" ${i==="expense"?"selected":""}>支出</option>
            <option value="income" ${i==="income"?"selected":""}>收入</option>
          </select></div>
        <div class="field" data-role="budget-field" ${i==="expense"?"":"hidden"}>
          <span class="field-label">月预算</span>
          <input type="text" inputmode="decimal" data-role="budget" placeholder="选填，比如 1000"
                 value="${e?.budgetFen?u(Je(e.budgetFen)):""}" /></div>
      </div>
      <p class="muted" data-role="budget-hint" style="margin-top:10px" ${i==="expense"?"":"hidden"}>
        月预算是这个分类每月的支出上限。记账页的分类格上会显示进度，花到八成变黄、超支变红。留空或填 0 就是不设。
      </p>
      <p class="card-title" style="margin:16px 0 8px">选个图标</p>
      <div class="emoji-grid" data-role="emojis">
        ${Cn.map(c=>`<button type="button" data-e="${c}" class="${c===r?"active":""}">${c}</button>`).join("")}
      </div>
      ${s?"":'<div class="divider"></div><button type="button" class="btn btn-danger btn-block" data-role="del">删除这个分类</button>'}`,actions:[{label:"取消",className:"btn-outline",onClick:c=>c.close()},{label:s?"创建":"保存",className:"btn-primary",onClick:async c=>{const d=c.body.querySelector('[data-role="name"]').value.trim();if(!d)return h("给分类起个名字");const m=c.body.querySelector('[data-role="kind"]').value,g=c.body.querySelector('[data-role="budget"]').value.trim();let p=0;if(m==="expense"&&g){const v=ge(g);if(v===null||v<0)return h("月预算填个数字就行，比如 1000");p=v}s?(await St(m,d,r,p),h(p?`分类已添加，月预算 ${y(p)} 元`:"分类已添加")):(await It(e.id,{name:d,emoji:r,kind:m,budgetFen:p}),h(p?`已保存，月预算 ${y(p)} 元`:"已保存")),c.close(),t?.()}}]});o.body.querySelector('[data-role="kind"]').addEventListener("change",c=>{const d=c.target.value==="expense";o.body.querySelector('[data-role="budget-field"]').hidden=!d,o.body.querySelector('[data-role="budget-hint"]').hidden=!d}),o.body.querySelector('[data-role="emojis"]').addEventListener("click",c=>{const d=c.target.closest("[data-e]");d&&(r=d.dataset.e,o.body.querySelectorAll("[data-e]").forEach(m=>m.classList.toggle("active",m===d)))}),o.body.querySelector('[data-role="del"]')?.addEventListener("click",async()=>{const c=Ze(e.id);await z({title:`删除「${e.name}」？`,message:c?`有 ${c} 笔记录在用这个分类。删掉分类不会删记录，但那些记录会变成「未分类」。`:"这个分类还没被用过，可以放心删。",okText:"删除",danger:!0})&&(await Pt(e.id),h("已删除"),o.close(),t?.())}),setTimeout(()=>o.body.querySelector('[data-role="name"]')?.focus(),120)}function mt(e){return e.mode==="download"?"已导出，去「下载」或「文件」里找":e.mode==="share-failed"?"文件已生成，但发送面板没弹出来："+(e.message||"系统限制"):"已导出，选个地方保存吧"}async function Dn(){const e=M(),t=Nt(e.id),n=t.split(`\r
`).length-1;if(!n)return h("这个账本还没有记录，导出来是空的");const a=`${e.name}-${ut()}.csv`;try{const s=await lt(a,"\uFEFF"+t,"text/csv");h(`${s.mode==="download"?`已导出 ${n} 条，`:""}${mt(s)}`)}catch(s){h("导出失败："+(s.message||"未知原因"))}}async function Nn(e){if(!l.transactions.length)return h("还没有数据可以备份");const t=`记账备份-${ut()}.json`;try{const n=await lt(t,JSON.stringify(Dt(),null,2),"application/json");await X("lastBackupAt",Date.now()),h(mt(n)),e?.()}catch(n){h("导出失败："+(n.message||"未知原因"))}}async function Bn(e){let t=null;if(!await z({title:"从备份恢复？",message:`导入后，现在手机里的所有记录、账本、分类都会被备份文件里的内容替换掉，换不回来。

建议先「导出完整备份」存一份再操作。`,okText:"继续选择文件",danger:!0,onOk:()=>{t=Pn()}})||!t)return;const a=await t;if(a==null)return;let s;try{s=JSON.parse(a)}catch{return ke({title:"这个文件读不了",message:`它看起来不是备份文件，可能选错了。
请选之前用「导出完整备份」生成的那个 .json 文件。`})}try{const r=await _t(s);await X("lastBackupAt",Date.now()),await ke({title:"恢复完成",message:`成功导入 ${r} 笔记录。`}),e()}catch(r){await ke({title:"恢复失败",message:r.message})}}async function _n(e){!await z({title:"清空所有数据？",message:`现在一共有 ${l.transactions.length} 笔记录、${l.ledgers.length} 个账本。
清空之后全部消失，没法恢复。`,okText:"我确定",danger:!0})||!await z({title:"最后确认一次",message:"真的要清空吗？建议先在电脑上导出一份备份放着。",okText:"清空",danger:!0})||(await $.clearAll(),await je(),h("已清空"),e())}const Un={record:"记账",list:"账单",stats:"统计",settings:"设置"},pt=document.getElementById("view"),Hn=document.getElementById("pageTitle"),Wn=document.getElementById("ledgerName"),Yn={record:rt,list:q,stats:de,settings:D},Ae={};let Q=null;function gt(){Wn.textContent=M()?.name??""}function ne(){const e=Te();Q&&Q!==e&&(Ae[Q]=window.scrollY);const t=Q===e?window.scrollY:Ae[e]||0;Q=e,Hn.textContent=Un[e],gt(),document.querySelectorAll(".tab").forEach(n=>n.classList.toggle("active",n.dataset.tab===e)),Yn[e](pt),window.scrollTo(0,t)}xt(gt);document.addEventListener("touchstart",()=>{},{passive:!0});function Re(){const e=l.meta.theme,t=e?e==="dark":window.matchMedia("(prefers-color-scheme: dark)").matches;document.documentElement.dataset.theme=t?"dark":"light",document.querySelector('meta[name="theme-color"]')?.setAttribute("content",t?"#1d2027":"#3b7dd8")}document.getElementById("themeToggle").addEventListener("click",async()=>{const e=document.documentElement.dataset.theme==="dark"?"light":"dark";await X("theme",e),Re()});window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change",()=>{l.meta.theme||Re()});document.getElementById("ledgerSwitch").addEventListener("click",()=>{const e=l.ledgers.map(n=>({value:n.id,label:n.name,emoji:n.id===l.meta.currentLedgerId?"✅":"📒",sub:`${l.transactions.filter(a=>a.ledgerId===n.id).length} 笔`})),t=N({title:"切换账本",body:`<div class="set-list">${e.map(n=>`<button type="button" class="set-row" data-id="${n.value}">
          <span class="sr-ico">${n.emoji}</span>
          <span class="sr-main">${u(n.label)}<span class="sr-sub">${n.sub}</span></span>
        </button>`).join("")}</div>
    <p class="muted" style="margin-top:12px">要新建或删除账本，去「设置 → 账本」。</p>`});t.body.addEventListener("click",async n=>{const a=n.target.closest("[data-id]");a&&(await Me(a.dataset.id),t.close(),h("已切换账本"),Oe(),ne())})});document.querySelectorAll(".tab").forEach(e=>{e.addEventListener("click",()=>{const t=e.dataset.tab;t==="list"&&Oe(),t===Te()?(Ae[t]=0,ne()):qe(t)})});Vt(ne);const Gn=!!window.Capacitor?.isNativePlatform?.();"serviceWorker"in navigator&&(Gn?navigator.serviceWorker.getRegistrations?.().then(e=>e.forEach(t=>t.unregister())).catch(()=>{}):window.addEventListener("load",()=>{navigator.serviceWorker.register("./sw.js").catch(()=>{})}));async function Vn(){try{await je()}catch(e){pt.innerHTML=`<div class="empty"><span class="empty-ico">😵</span>
      数据打不开了：${u(e.message)}<br /><br />
      可以试试刷新页面。如果还是不行，可能是浏览器禁用了本地存储。</div>`;return}Re(),Oe(),ne(),window.addEventListener("focus",()=>{Te()==="list"&&ne()})}Vn();export{Ce as E,dt as W,En as b};
